double kiss(unsigned long *);
double gasdev(unsigned long *);
int runiform_n(int,unsigned long *);
void permute_sample(double *,int,unsigned long *); 
void permute_sample_int(int *,int,unsigned long *); 
long rmultinomial(double *,long,unsigned long *);
double runif_atob(unsigned long *,double,double);
double rexp(double,unsigned long *);
double sgamma(double,unsigned long *);
double fsign(double,double);
double snorm(unsigned long *);
double snorm_tmp(unsigned long *);
double snorm2(unsigned long *);
double rnorm(double,double,unsigned long *);
double rgamma(double,double,unsigned long *);
double rinverse_gamma(double,double,unsigned long *);
double fact_ln(int);
int rpois(double,unsigned long *);
double *rdirichlet(double *,int,unsigned long *);
double rbeta(double,double,unsigned long *);
double rchisq(int n, unsigned long* seed);

unsigned long * initial_seed(const char *seedfile);
unsigned long * initial_seed(unsigned long u0,unsigned long u1,unsigned long u2);
void save_seed(unsigned long* seed, const char* filename);

