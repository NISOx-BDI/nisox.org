/*
 *  readImageData.h
 *  PoissonHGamma
 *
 *  Created by Jian Kang on 12/15/10.
 *  Copyright 2010 University of Michigan. All rights reserved.
 *
 */

#ifndef _READ_IMAGE_DATA_H_
#define _READ_IMAGE_DATA_H_

#include<stdio.h>
#include<stdlib.h>
#include"MatVec.h"
#include"Mnormal.h"
#include"nifti1.h"

#define DIM 3
#define MASK_THRESH 200
#define MIN_HEADER_SIZE 348

typedef unsigned char MY_DATATYPE;

typedef struct{
	
	int numOfGroups;
	int* numOfPoints;
	double*** dataGroupPoints;
	int numOfTypes;
	int* numInTypes;
	int* trueTypes;
	int** indicesOfTypes;
	int totalNumOfPoints;
	int* numPtsInTypes;
	
} GroupData;


typedef struct{
	MY_DATATYPE*** brain;
	int* dim;
	double vol;
	
}BrainMask;


GroupData* read_GroupData(const char* filename);
void free_GroupData(GroupData* gdat);

BrainMask* read_BrainMask(const char* filename);
void free_BrainMask(BrainMask* brain);


double** read_dataPoints(int &numOfPoints, const char* filename);
void free_dataPoints(double** dataPoints, int numOfPoints);
int* read_numOfPiontsWithinGroup(int& numOfGroup, int& totalNumOfPoints, const char* filename);
void free_numOfPoints(int* numOfPoints);
double*** read_dataGroupPoints(int* numOfPoints, int numOfGroup, const char* filename);
void free_dataGroupPoints(double*** dataGroupPoints, int* numOfPoints, int numOfGroup);
int* read_trueTypes(int &numOfTypes,int numOfGroup, const char* filename);
void free_trueTypes(int* trueTypes);
int* compute_numInTypes(int* trueType, int numOfTypes, int numOfGroup);
int* compute_numPtsInTypes(int* trueType, int numOfTypes, int numOfGroup, int* numOfPoints);
void free_numInTypes(int* numInTypes);
int** compute_indicesOfTypes(int* trueType, int* numInTypes, int numOfTypes, int numOfGroup);
void free_indicesOfTypes(int** indicesOfTypes, int numInTypes);


MY_DATATYPE* read_nii(const char* data_file, int* dim);
MY_DATATYPE*** read_mask(const char* maskfile, int* dim, double* vol);
void free_mask(MY_DATATYPE*** brain_mask, int* dim);

void print_groupData(GroupData* gdat);

#endif //_READ_IMAGE_DATA_H_
