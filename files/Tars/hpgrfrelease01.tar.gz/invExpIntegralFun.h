/*
 *  invExpIntegralFun.h
 *  ClusterProcess
 *
 *  Created by Jian Kang on 9/27/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#include <stdio.h>
#include "exponential_integral_Ei.h"
#include <math.h>


#define NUMERATOR(dab,dcb,fa,fb,fc) fb*(dab*fc*(fc-fb)-fa*dcb*(fa-fb))
#define DENOMINATOR(fa,fb,fc) (fc-fb)*(fa-fb)*(fa-fc)



double Ei_fun(double x,double p);
double invExpIntegralFun(double p);
double expIntegralFun(double x);
double Secant_Method( double (*f)(double,double),double p, double a, double b, 
					 double tolerance, int max_iteration_count, int *err);
double Amsterdam_Method( double (*f)(double,double),double p, double a, double c, 
						double tolerance, int max_iterations, int *err);