/*
 *  invExpIntegralFun.cpp
 *  ClusterProcess
 *
 *  Created by Jian Kang on 9/27/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#include "invExpIntegralFun.h"

double Ei_fun(double x,double p)
{
	return Exponential_Integral_Ei(x)+p;
}


double expIntegralFun(double x)
{
	return -Exponential_Integral_Ei(-x);
}


double invExpIntegralFun(double p)
{
	int err;
	if (p>44.0 || p<=0)
		return 0.0;
	double x = Amsterdam_Method(Ei_fun, p, -1e10, -1e-20, 1e-7, 1000, &err);
	if (err==-1) {
		printf("Warning: invEi does not have root between 1e-20 and 1e10. \n");
	}
	else if(err==-2)
	{
		printf("Warning: invEi does not converge \n");
	}
	return -x;
}

double Secant_Method( double (*f)(double,double),double p, double a, double b, 
					double tolerance, int max_iteration_count, int *err) {
	
	double fa = (*f)(a,p), fb = (*f)(b,p), delta;
	int i;
	
	*err = 0;
	for (i = 0; i < max_iteration_count; i++) {
		
		// Insure that the f(b) has smaller magnitude than f(a). //
		
		if ( fabs(fa) < fabs(fb) ) {
			delta = a; a = b; b = delta; delta = fa; fa = fb; fb = delta;
		}
		
		// If an attempt to divide by zero, return with an error code -2. //
		
		if ( fb == fa ) { *err = -2; return 0.0; }
		
		// Estimate the location of the root relative to b. //
		
		delta = fb * (a - b) / (fb - fa);
		
		// If the location of the root relative to b is less than //
		// the tolerance, return the estimate of the root.        //
		
		if ( delta == 0.0 ) return b;
		
		
		printf("delta = %g\n",delta);
		
		

		if ( fabs(delta) < tolerance ) return b + delta;
		
		// Otherwise, update the estimate of the root. //
		
		a = b + delta;
		fa = (*f)(a,p);
	}
	
	*err = -1;
	return a;   
}


double Amsterdam_Method( double (*f)(double,double),double p, double a, double c, 
						double tolerance, int max_iterations, int *err) {
	
	double fa = (*f)(a,p), b = 0.5 * ( a + c ), fc = (*f)(c,p), fb = fa * fc;
	double delta, dab, dcb;
	int i;
	
	// If the initial estimates do not bracket a root, set the err flag and //
	// return.  If an initial estimate is a root, then return the root.     //
	
	*err = 0;
	if ( fb >= 0.0 )
		if ( fb > 0.0 )  { *err = -1; return 0.0; }
		else return ( fa == 0.0 ) ? a : c;
	
	// Insure that the initial estimate a < c. //
	
	if ( a > c ) {
		delta = a; a = c; c = delta; delta = fa; fa = fc; fc = delta;
	}
	
	// If the function at the left endpoint is positive, and the function //
	// at the right endpoint is negative.  Iterate reducing the length    //
	// of the interval by either bisection or quadratic inverse           //
	// interpolation.  Note that the function at the left endpoint        //
	// remains nonnegative and the function at the right endpoint remains //
	// nonpositive.                                                       //
	
	if ( fa > 0.0 ) 
		for ( i = 0; i < max_iterations; i++) {
			
            // Are the two endpoints within the user specified tolerance ?
			
			if ( ( c - a ) < tolerance ) return 0.5 * ( a + c);
			
            // No, Continue iteration.
			
			fb = (*f)(b,p);
			
            // Check that we are converging or that we have converged near //
            // the left endpoint of the inverval.  If it appears that the  //
            // interval is not decreasing fast enough, use bisection.      //
			if ( ( c - a ) < tolerance ) return 0.5 * ( a + c);
			if ( ( b - a ) < tolerance ) 
				if ( fb > 0 ) {
					a = b; fa = fb; b = 0.5 * ( a + c ); continue;
				}
				else return b;
			
            // Check that we are converging or that we have converged near //
            // the right endpoint of the inverval.  If it appears that the //
            // interval is not decreasing fast enough, use bisection.      //
			
			if ( ( c - b ) < tolerance )
				if ( fb < 0 ) {
					c = b; fc = fb; b = 0.5 * ( a + c ); continue;
				}
				else return b;
			
            // If quadratic inverse interpolation is feasible, try it. //
			
			if (  ( fa > fb ) && ( fb > fc ) ) {
				delta = DENOMINATOR(fa,fb,fc);
				if ( delta != 0.0 ) {
					dab = a - b;
					dcb = c - b;
					delta = NUMERATOR(dab,dcb,fa,fb,fc) / delta;
					
					// Will the new estimate of the root be within the   //
					// interval?  If yes, use it and update interval.    //
					// If no, use the bisection method.                  //
					
					if ( delta > dab && delta < dcb ) {
						if ( fb > 0.0 ) { a = b; fa = fb; }
						else if ( fb < 0.0 )  { c = b; fc = fb; } 
						else return b;
						b += delta;
						continue;
					}
				}   
			}
			
            // If not, use the bisection method. //
			
			fb > 0 ? ( a = b, fa = fb ) : ( c = b, fc = fb );
			b = 0.5 * ( a + c );
		}
	else 
		
		// If the function at the left endpoint is negative, and the function //
		// at the right endpoint is positive.  Iterate reducing the length    //
		// of the interval by either bisection or quadratic inverse           //
		// interpolation.  Note that the function at the left endpoint        //
		// remains nonpositive and the function at the right endpoint remains //
		// nonnegative.                                                       //
		
		for ( i = 0; i < max_iterations; i++) {
			
			if ( ( c - a ) < tolerance ) return 0.5 * ( a + c);
			
			fb = (*f)(b,p);
			
			if ( ( b - a ) < tolerance ) 
				if ( fb < 0 ) {
					a = b; fa = fb; b = 0.5 * ( a + c ); continue;
				}
				else return b;
			
			if ( ( c - b ) < tolerance )
				if ( fb > 0 ) {
					c = b; fc = fb; b = 0.5 * ( a + c ); continue;
				}
				else return b;
			
			if (  ( fa < fb ) && ( fb < fc ) ) {
				delta = DENOMINATOR(fa,fb,fc);
				if ( delta != 0.0 ) {
					dab = a - b;
					dcb = c - b;
					delta = NUMERATOR(dab,dcb,fa,fb,fc) / delta;
					if ( delta > dab && delta < dcb ) {
						if ( fb < 0.0 ) { a = b; fa = fb; }
						else if ( fb > 0.0 )  { c = b; fc = fb; } 
						else return b;
						b += delta;
						continue;
					}
				}   
			}
			fb < 0 ? ( a = b, fa = fb ) : ( c = b, fc = fb );
			b = 0.5 * ( a + c );
		}
	*err = -2;
	return  b;
}

