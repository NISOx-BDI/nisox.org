#ifndef _MAT_VEC_H_
#define _MAT_VEC_H_


#include <stdio.h>
#include <stdlib.h>
#include "cholesky.h"

#define V_PF "%.4lf "
#define DIM 3

int comp(double *c1,double *c2);


void q_sort(int *v,double *c,int left,int right,
			int (*comp)(double *,double *));


//Matrix allocation (default is I)
double **mat_alloc(int size_A);

//Matrix List alloction
double ***mat_list_alloc(int size_A,const int M);

//Matrix mat allocation M*
double ****mat_mat_alloc(int size_A, const int M, const int L);

//Array allocation
double ***Array_alloc(int size,int M,int N);

//Array free
void Array_free(double ***A,int size,int M, int N);
void Array_free(unsigned char***A, int size, int M, int N);

// matrix list destruction
void mat_list_free(double ***A,int size_A,const int M);

double **mat_copy(double ** A, int size_A);

void mat_copyval(double **A, double **B,int size);

//matrix times a number
void mat_times_k(double **A, int size,double k);

//vector allocation (default with all zero)
double *vec_alloc(int size_x);

//vector copy 
double *vec_copy(double *x, int size_x);

//vector List allocation;
double **vec_list_alloc(int size_x,const int M);

//vector List allocation
double **vec_list_alloc_long(int size_x,const long M);

int mat_positive(double**a);

//vector list copy
double **vec_list_copy(double **X,int size,int n);


void vec_copyval(double*v1, double* v2, int size);


void vec_exchange(double* v1, double *v2, int size);

//Matrix destruction
void mat_free(double **A,int size_A);

//Matrix Matrix destruction
void mat_mat_free(double ****A, int size_A, int M, int L);


void mat_exchange(double ** m1, double ** m2, int size);


//Matrix list copy
double ***mat_list_copy(double*** SigmaList,int size,int n);


//vector list add one
void vec_list_add(double **X,int size,int n,double *xi);


//vector List delete one
void vec_list_delete_i(double **X,int size,int n, int i);


//Matrix List delete one
void mat_list_delete_i(double ***SigmaList,int size,int n, int i);


//Matrix List Add One
void mat_list_add(double ***SigmaList,int size, int n, double **S);



//vector List free
void vec_list_free(double **A, int M);
void vec_list_free(unsigned char**A, int M);


void vec_list_free(int **A, int M);


//vector List free
void vec_list_free_long(double **A, long M);



//vector print
void vec_print(double *x,int size_x,const char* _format);


void vec_print(int *x,int size_x,const char* _format);




//Matrix print
void mat_print(double **S,int size_S, const char * _format);

//Matrix assign
void mat_assign(double **S, int size_S);

//Vector statistiscs
//Updated mean Vector
//M_n = ((n-1) M_(n-1) + X_n)/n
int vec_upd_mean(double *mean, double *x, const int size, int n);

void exchange(double &a, double &b);

//Vector Distance
double vec_dist(double* v1, double* v2, int size);

void vec_add(double* result, double* v1, double* v2, int size);

void vec_substract(double* result, double* v1, double* v2, int size);

void vec_divide_k(double* results, double* v, double k, int size);

void vec_times_k(double* results, double* v, double k, int size);

double mat_det(double ** X, int size);

double mat_det3(double** a);

void mat_inv3(double**invA,double** a);

double** mat_inv(double** X, int size);

double mat_trace(double** X, int size);

void mat_k(double **X, double k);

void mat_plus(double**results, double**A, double**B, int size);

double** mat_multiply(double ** X, double ** Y, int size);

void mat_mul(double** result, double** X, double ** Y, int size);

void mat_t_vec(double* v1, double**A, double*v);

void mat_times_vec(double* res, double** mat, double*vec, int size);

void mat_inverse(double** result, double**X, int size);

void mat_minus(double**results, double**A, double**B, int size);

void vec_switch(double *&a, double *&b);

void mat_switch(double **&a ,double **&b);

void veclist_print(double**list, int idx, int len, const char* _format);


int** vec_int_list_alloc(int len, int N);
void vec_int_list_free(int** intlist, int N);

double**** Array_list_alloc(int n1, int n2, int n3, int n4);
void Array_list_free(double**** alist, int n1, int n2, int n3, int n4);

double abs_fun(double x);
double vec_abs_dist(double* x1, double* x2, int size);

#endif //_MAT_VEC_H_
