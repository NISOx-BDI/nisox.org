/*
 *  chiSqauredDist.h
 *  ClusterProcess
 *
 *  Created by Jian Kang on 9/27/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */


#ifndef _CHISQAURED_DIST_H_
#define _CHISQAURED_DIST_H_

#include "math.h"
#include "float.h"

double lgfun (double v);

//chisqaure quantiles
double qchisq(double p, double v);

//normal variates
double qnorm(double p);


#endif //_CHISQAURED_DIST_H_