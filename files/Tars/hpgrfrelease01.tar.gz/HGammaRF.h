/*
 *  HGammaRF.h
 *  PoissonHGamma
 *
 *  Created by Jian Kang on 12/15/10.
 *  Copyright 2010 University of Michigan. All rights reserved.
 *
 */


#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include "Mnormal.h"
#include "MatVec.h"
#include "cholesky.h"
#include "randgen.h"
#include "readImageData.h"
#include "invExpIntegralFun.h"
#include "arms.h"


typedef struct{
	char dataname[1000];
	char preddataname[1000];
	char savename[1000];
	int numOfJumps;
	int totalIters;
	int burnin;
	int recStep;
	double aParJumpHeight;
	double bParJumpHeight;
	double aParPopJumpHeight;
	double bParPopJumpHeight;
	double aParKernel;
	double bParKernel;	
	double updSdParKernel;
	double updSdParPopJumpHeights;
	int adjustStep;
	int randInitial;
	int predict;
	double updSdJump;

} ModelArgs;


typedef struct{
	GroupData* gdat;
	GroupData* pdat;
	BrainMask* bmask;
	BrainMask** bsubmask;
	int numOfbsubmask;
	
	ModelArgs* margs;
	
	double*** auxiliaryPoints;
	int** indicesAuxPoints;
	
	int numOfDistinctPoints;
	int** numOfTies;
	int* newJumpIndicators;

	
	double** jumpLocations;
	double* popJumpHeights;
	double** jumpHeights;
	
	int* traceidx;

	
	double** kernelOverBrain;

	
	
	double parJumpHeight;
	double parPopJumpHeight;	
	double* parKernel;
	
	

	double updSdParPopJumpHeights;
	
	double acptUpdParPopJumpHeights;

	double* updSdParKernel;
	double* acptUpdParKernel;

	
	FILE* traceFid;
	FILE* jumpTraceFid;
	
	
	double**** typeIntensity;
	double*** popIntensity;
	
	double**** meanTypeIntensity;
	double*** meanPopIntensity;
	
	double**** sdTypeIntensity;
	double*** sdPopIntensity;
	
	int iter;
	int recIntCount;
	int recDenCount;
	
	int recDenCountPred;
	
	double** logDensitiesForData;
	double** densityRatio;
	double** meanDensityRatio;
	double** sdDensityRatio;
	double** loocvPredProb;
	int* loocvPredType;
	double** confusionMatrix;
	double overallCrate;
	double averageCrate;
	
	double** logDensitiesForDataPred;
	double** meanDensityPred;
	double** sdDensityPred;
	double** predProb;
	int* predType;
	double** confusionMatrixPred;
	double overallCratePred;
	double averageCratePred;
	
	double* maxDensityPred;
	
	int** sigmai;
	int** sigmaj;
	int* sigmaNum;
	
	
	double** intensityCov0;
	double** intensityCov1;
	double** intensityCov01;
	
	double** subIntensity;
	double** subIntCrossProduct0;
	double** subIntCrossProduct1;
	double** subIntCrossProduct01;
	double** subIntSum;
	
	

	unsigned long* seed;

} HGammaRF;





double*** alloc_listPoints(int* numOfPoints, int numOfLists);
void free_listPoints(double*** listPoints, int* numOfPoints, int numOfLists);

int** alloc_listIndices(int* numOfPoints, int numOfLists);
void free_listIndices(int** listIndices,int numOfLists);





void update_auxiliaryPoints(HGammaRF* model);
void update_jumpLocations(HGammaRF* model);
void update_jumpHeights(HGammaRF* model);
void update_popJumpHeights(HGammaRF* model);

double log_kernel(double* x, double *y, double theta);
double kernel(double*x, double *y, double theta);
void initial_values(HGammaRF* model);

void update_auxiliaryPoints(HGammaRF* model);
void update_kernelOverBrain(HGammaRF* model);


double compute_kernelOverBrain(double*x, double theta, BrainMask* bmask, unsigned long* seed);

double log_mDensityOfpopJumps(double x, void*dat);

double log_MDensityOfpopJumps(double x, void*dat);

double draw_mPopJumpHeights(double logcm,unsigned long*);

double draw_mPopJumpHeights_MH(double xprev, double logcm, unsigned long* seed);

double draw_MPopJumpHeights(double logcm, double beta,unsigned long*);

void update_parKernel(HGammaRF* model);
void update_parJumpHeights(HGammaRF* model);
void update_parPopJumpHeights(HGammaRF* model);
void update_parPopJumpHeights_MH(HGammaRF* model);

double compute_intensity(double* pt, double** jumpLocations, double* jumpHeights, int numOfJumps,  double theta);
void compute_allIntensities(double*allIntensities, double* pt, double** jumpLocations, double** jumpHeights, 
							double* popJumpHeights, int numOfJumps, int numOfTypes, double theta);

void update_intensities(HGammaRF* model);


void posterior_inference(HGammaRF* model);

void draw_pointsOnBrain(double* pt, BrainMask* bmask, unsigned long* seed);


void compute_allIntensities(double*allIntensities, double* pt, double** jumpLocations, double** jumpHeights, 
							double* popJumpHeights, int numOfJumps, int numOfTypes, double* theta);

void update_intensities(HGammaRF* model);
void add_intensity(double*** results, double*** intensity, BrainMask* bmask);
void add_intensity_sq(double*** results, double*** intensity, BrainMask* bmask);
void update_sumIntensities(HGammaRF* model);

void summary_intensities(HGammaRF* model);

double compute_intMeasure(double* kernelOverBrain, double* jumpHeights, int numOfJumps, int theta);
double compute_logDensity(double** pts, int numOfPts, double** jumpLocations, double* jumpHeights, 
						  int numOfJumps, double theta, double intMeasure);

void update_logDensities(HGammaRF* model);
void update_densityRatio(HGammaRF* model);
void update_sumDensityRatio(HGammaRF* model);
void summary_densityRatio(HGammaRF* model);
void compute_loocvPredProb(HGammaRF* model);

void update_logDensityPred(HGammaRF* model);
void update_sumDensityPred(HGammaRF* model);
void summary_densityPred(HGammaRF* model);
void compute_predProb(HGammaRF* model);

void update_numOfDistinctPoints(HGammaRF* model);
void trace_pars(HGammaRF* model);
void trace_jumps(HGammaRF* model);
void save_loocvPredProb(HGammaRF* model);
void save_predProb(HGammaRF* model);


void compute_confustionMatrix(HGammaRF* model);
void compute_confustionMatrixPred(HGammaRF* model);
void save_confusionMatrix(HGammaRF* model);
void save_intensity(HGammaRF* model);

void adjust_acceptance(double accept,double &sgm);
void posterior_inference(HGammaRF* model);
void run_HGammaRF(int argc, char * const argv[]);
void save_jumps(HGammaRF* model);
void show_jumps(HGammaRF* model);

void write_vol(const char* filename, double*** intensity, MY_DATATYPE*** brain_mask, int* dim);
