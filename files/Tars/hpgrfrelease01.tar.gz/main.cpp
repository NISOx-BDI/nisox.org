#include "HGammaRF.h"

double M = exp(-64*log(2.0));
int PREC = 64;



int main (int argc, char * const argv[]) {

	run_HGammaRF(argc,  argv);	
	
	/*unsigned long* seed = initial_seed("seed.dat");
	double* x = vec_alloc(1000);
	for(int i=0; i<1000; i++)
		x[i] = rgamma(80, 4, seed);
	
	FILE* fid = fopen("rgamma.num", "wt");
	for(int i=0; i<1000; i++)
	{
		fprintf(fid, "%lf\n",x[i]);
	}
	fclose(fid);
	free(seed);
	free(x);*/
    return 0;
}
