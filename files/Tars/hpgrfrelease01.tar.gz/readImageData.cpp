/*
 *  readImageData.cpp
 *  PoissonHGamma
 *
 *  Created by Jian Kang on 12/15/10.
 *  Copyright 2010 University of Michigan. All rights reserved.
 *
 */

#include "readImageData.h"



GroupData* read_GroupData(const char* filename)
{
	GroupData* gdat = (GroupData*)malloc(sizeof(GroupData));
	
	gdat->numOfPoints = read_numOfPiontsWithinGroup(gdat->numOfGroups, gdat->totalNumOfPoints, filename);
	gdat->dataGroupPoints = read_dataGroupPoints(gdat->numOfPoints, gdat->numOfGroups, filename);
	
	gdat->trueTypes = read_trueTypes(gdat->numOfTypes, gdat->numOfGroups, filename);
	
	gdat->numInTypes = compute_numInTypes(gdat->trueTypes, gdat->numOfTypes, gdat->numOfGroups);
	gdat->numPtsInTypes = compute_numPtsInTypes(gdat->trueTypes, gdat->numOfTypes, gdat->numOfGroups, gdat->numOfPoints);
	
	gdat->indicesOfTypes = compute_indicesOfTypes(gdat->trueTypes, gdat->numInTypes, gdat->numOfTypes, gdat->numOfGroups);
	
	
	return gdat;
}



void free_GroupData(GroupData* gdat)
{
	
	free_dataGroupPoints(gdat->dataGroupPoints, gdat->numOfPoints, gdat->numOfGroups);
	free_indicesOfTypes(gdat->indicesOfTypes, gdat->numOfTypes);
	free_numOfPoints(gdat->numOfPoints);
	free_numInTypes(gdat->numInTypes);
	free_trueTypes(gdat->trueTypes);
	
	free(gdat);
	
}


BrainMask* read_BrainMask(const char* filename)
{
	BrainMask* bmask = (BrainMask*)malloc(sizeof(BrainMask));
	
	bmask->dim = (int*)malloc(DIM*sizeof(int));
	bmask->brain = read_mask(filename, bmask->dim, &(bmask->vol));
	
	return bmask;
}


void free_BrainMask(BrainMask* bmask)
{
	free_mask(bmask->brain, bmask->dim);
	free(bmask->dim);
}

double** read_dataPoints(int &numOfPoints, const char* filename)
{
	FILE* f;
	double tp1,tp2,tp3;
	double** dataPoints;
	
	numOfPoints= 0;
	f = fopen(filename,"rt");
	
	while (!feof(f) && fscanf(f, "%lf %lf %lf\n",&tp1,&tp2,&tp3) == 3)
		numOfPoints++;
	rewind(f);
	
	dataPoints = vec_list_alloc(DIM, numOfPoints);
	
	for(int i=0; i<numOfPoints; i++)
	{
		fscanf(f,"%lf %lf %lf\n", &(dataPoints[i][0]),&(dataPoints[i][1]),
			   &(dataPoints[i][2]));
	}
	
	fclose(f);
	
	return dataPoints;
}

void free_dataPoints(double** dataPoints, int numOfPoints)
{
	for(int k=0; k<numOfPoints; k++)
	{
		free(dataPoints[k]);
	}
	free(dataPoints);
}



int* read_numOfPiontsWithinGroup(int& numOfGroup, int& totalNumOfPoints, const char* filename)
{
	int* numOfPoints, group0,group;
	double tp1, tp2, tp3;
	int type;
	
	FILE* f;
	f = fopen(filename,"rt");
	
	numOfGroup = 1;
	fscanf(f, "%d %lf %lf %lf %d\n",&group0, &tp1,&tp2,&tp3, &type);
	while (!feof(f) && fscanf(f, "%d %lf %lf %lf %d\n",&group, &tp1,&tp2,&tp3, &type) == 5)
	{
		if (group!=group0) {
			numOfGroup++;
		}
		group0 = group;
	}
	rewind(f);
	
	numOfPoints = (int*)calloc(numOfGroup, sizeof(int));
	
	
	for (int i=0; i<numOfGroup; i++) {
		numOfPoints[i] = 1;
	}
	
	
	numOfGroup=0;
	fscanf(f, "%d %lf %lf %lf %d\n",&group0, &tp1,&tp2,&tp3,&type);
	while (!feof(f) && fscanf(f, "%d %lf %lf %lf %d\n",&group, &tp1,&tp2,&tp3,&type) == 5)
	{
		if (group ==group0) {
			numOfPoints[numOfGroup]++;		
		}
		else {
			numOfGroup++;
		}
		
		group0 = group;
	}
	rewind(f);
	numOfGroup++;
	
	printf("numOfStudies = %d\n",numOfGroup);
	
	totalNumOfPoints = 0.0;
	for(int i=0; i<numOfGroup; i++){
		totalNumOfPoints += numOfPoints[i];
	}
	
	return numOfPoints;
}




void free_numOfPoints(int* numOfPoints)
{
	free(numOfPoints);
}


double*** read_dataGroupPoints(int* numOfPoints, int numOfGroup, const char* filename)
{
	FILE* f;
	double*** dataPoints;
	int group;
	int type;
	
	f = fopen(filename,"rt");
	
	
	dataPoints = (double***)calloc(numOfGroup, sizeof(double**));
	for(int k=0; k<numOfGroup; k++)
	{
		dataPoints[k] = vec_list_alloc(DIM, numOfPoints[k]);
		for(int i=0; i<numOfPoints[k]; i++)
		{
			fscanf(f,"%d %lf %lf %lf %d\n",&group, &(dataPoints[k][i][0]),&(dataPoints[k][i][1]),
				   &(dataPoints[k][i][2]),&type);
		}
		
	}
	fclose(f);
	
	return dataPoints;
}


void free_dataGroupPoints(double*** dataGroupPoints, int* numOfPoints, int numOfGroup)
{
	for(int k =0; k<numOfGroup; k++)
	{
		for(int i=0; i<numOfPoints[k]; i++)
		{
			free(dataGroupPoints[k][i]);
		}
		free(dataGroupPoints[k]);
	}
	free(dataGroupPoints);
}

int* read_trueTypes(int &numOfTypes,int numOfGroup, const char* filename)
{
	int* trueTypes, group0,group;
	double tp1, tp2, tp3;
	int type;
	
	FILE* f;
	f = fopen(filename,"rt");
	
	
	trueTypes = (int*)calloc(numOfGroup, sizeof(int));
	
	
	
	numOfGroup=0;
	fscanf(f, "%d %lf %lf %lf %d\n",&group0, &tp1,&tp2,&tp3,&type);
	trueTypes[numOfGroup] = type;	
	
	printf("trueType[0] = %d\n",type);
	while (!feof(f) && fscanf(f, "%d %lf %lf %lf %d\n",&group, &tp1,&tp2,&tp3,&type) == 5)
	{
		if(group!=group0){
			numOfGroup++;
			trueTypes[numOfGroup] = type;		
			
		}
		
		group0 = group;
	}
	rewind(f);
	numOfGroup++;
	
	numOfTypes = 0;
	for(int i=0; i<numOfGroup; i++)
	{
		if(numOfTypes<trueTypes[i])
			numOfTypes = trueTypes[i];
	}
	numOfTypes++;
	
	return trueTypes;
	
}

void free_trueTypes(int* trueTypes)
{
	free(trueTypes);
}


int* compute_numInTypes(int* trueType, int numOfTypes, int numOfGroup)
{
	int* numInTypes = (int*)calloc(numOfTypes, sizeof(int));
	
	
	for(int i =0; i<numOfGroup; i++)
	{
		numInTypes[trueType[i]]++;
	}
	
	return numInTypes;
}


int* compute_numPtsInTypes(int* trueType, int numOfTypes, int numOfGroup, int* numOfPoints)
{
	int* numPtsInTypes = (int*)calloc(numOfTypes, sizeof(int));
	
	for(int i=0; i<numOfGroup; i++)
	{
		numPtsInTypes[trueType[i]] += numOfPoints[i];
	}
	
	
	return numPtsInTypes;
}


void free_numInTypes(int* numInTypes)
{
	free(numInTypes);
}


int** compute_indicesOfTypes(int* trueType, int* numInTypes, int numOfTypes, int numOfGroup)
{
	int** indicesOfTypes = (int**)calloc(numOfTypes, sizeof(int*));
	for(int i=0; i<numOfTypes; i++)
	{
		indicesOfTypes[i] = (int*)calloc(numInTypes[i],sizeof(int));
		numInTypes[i] = 0;
	}
	
	for(int j=0; j<numOfGroup; j++)
	{
		indicesOfTypes[trueType[j]][numInTypes[trueType[j]]] = j;
		numInTypes[trueType[j]]++;
	}
	return indicesOfTypes;
}

void free_indicesOfTypes(int** indicesOfTypes, int numInTypes)
{
	for(int i=0; i<numInTypes; i++)
		free(indicesOfTypes[i]);
	
	free(indicesOfTypes);
}



MY_DATATYPE* read_nii(const char* data_file, int* dim)
{
	nifti_1_header hdr;
	int ret;
	FILE* fp;
	MY_DATATYPE* data = NULL;
	
	/********** open and read header */
	fp = fopen(data_file,"rb");
	if (fp == NULL) {
		fprintf(stderr, "\nError opening header file %s\n",data_file);
		exit(1);
	}
	ret = fread(&hdr, MIN_HEADER_SIZE, 1, fp);
	if (ret != 1) {
		fprintf(stderr, "\nError reading header file %s\n",data_file);
		exit(1);
	}
	fclose(fp);
	
	dim[0] = hdr.dim[1];
	dim[1] = hdr.dim[2];
	dim[2] = hdr.dim[3];
	
	
	/********** print a little header information */
	fprintf(stdout, "\n%s header information:",data_file);
	fprintf(stdout, "\nXYZT dimensions: %d %d %d %d",hdr.dim[1],hdr.dim[2],hdr.dim[3],hdr.dim[4]);
	fprintf(stdout, "\nDatatype code and bits/pixel: %d %d",hdr.datatype,hdr.bitpix);
	fprintf(stdout, "\nScaling slope and intercept: %.6f %.6f",hdr.scl_slope,hdr.scl_inter);
	fprintf(stdout, "\nByte offset to data in datafile: %ld",(long)(hdr.vox_offset));
	fprintf(stdout, "\n");
	
	/********** open the datafile, jump to data offset */
	fp = fopen(data_file,"rb");
	if (fp == NULL) {
		fprintf(stderr, "\nError opening data file %s\n",data_file);
		exit(1);
	}
	
	ret = fseek(fp, (long)(hdr.vox_offset), SEEK_SET);
	if (ret != 0) {
		fprintf(stderr, "\nError doing fseek() to %ld in data file %s\n",(long)(hdr.vox_offset), data_file);
		exit(1);
	}
	
	
	/********** allocate buffer and read first 3D volume from data file */
	data = (MY_DATATYPE *) malloc(sizeof(MY_DATATYPE) * hdr.dim[1]*hdr.dim[2]*hdr.dim[3]);
	if (data == NULL) {
		fprintf(stderr, "\nError allocating data buffer for %s\n",data_file);
		exit(1);
	}
	ret = fread(data, sizeof(MY_DATATYPE), hdr.dim[1]*hdr.dim[2]*hdr.dim[3], fp);
	if (ret != hdr.dim[1]*hdr.dim[2]*hdr.dim[3]) {
		fprintf(stderr, "\nError reading volume 1 from %s (%d)\n",data_file,ret);
		exit(1);
	}
	fclose(fp);
	
	
	/*********** scale the data buffer  */
	/*if (hdr.scl_slope != 0) {
	 for (i=0; i<hdr.dim[1]*hdr.dim[2]*hdr.dim[3]; i++)
	 data[i] = (unsigned char)((data[i] * hdr.scl_slope) + hdr.scl_inter);
	 }*/
	
	return data;
}

MY_DATATYPE*** read_mask(const char* maskfile, int* dim, double* vol)
{
	MY_DATATYPE* data = read_nii(maskfile, dim);
	int t = 0;
	MY_DATATYPE*** brain_mask = (MY_DATATYPE***)malloc(sizeof(MY_DATATYPE**)*dim[0]);
	for(int i=0; i<dim[0]; i++)
	{
		brain_mask[i] = (MY_DATATYPE**)malloc(sizeof(MY_DATATYPE*)*dim[1]);
		for(int j=0; j<dim[1]; j++)
		{
			brain_mask[i][j] = (MY_DATATYPE*)malloc(sizeof(MY_DATATYPE)*dim[2]);
		}
	}
	
	*vol = 0;
	for(int k=0; k<dim[2];k++)
		for(int j=0; j<dim[1]; j++)
			for(int i=0;i<dim[0]; i++)
			{
				if (data[t]>MASK_THRESH)
				{
				    brain_mask[i][j][k] = 1;
					*vol += brain_mask[i][j][k];
				}
				t++;
			}
	free(data);
	
	return brain_mask;
}


void free_mask(MY_DATATYPE*** brain_mask, int* dim)
{
	for(int i=0; i<dim[0]; i++)
	{
		for(int j=0; j<dim[1]; j++)
		{
			free(brain_mask[i][j]);
		}
		free(brain_mask[i]);
	}
	free(brain_mask);
}



void print_groupData(GroupData* gdat)
{
	for(int i=0; i<gdat->numOfGroups; i++)
	{
		for(int j=0; j<gdat->numOfPoints[i]; j++)
			printf("%d %lg %lg %lg %d\n",i+1, gdat->dataGroupPoints[i][j][0],gdat->dataGroupPoints[i][j][1],
			   gdat->dataGroupPoints[i][j][2],gdat->trueTypes[i]);
	}
}