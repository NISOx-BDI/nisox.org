/*
 *  HGammaRF.cpp
 *  PoissonHGamma
 *
 *  Created by Jian Kang on 12/15/10.
 *  Copyright 2010 University of Michigan. All rights reserved.
 *
 */

#include "HGammaRF.h"

ModelArgs* read_ModelArgs(const char* argsname)
{
	ModelArgs* ag = (ModelArgs*)malloc(sizeof(ModelArgs));
	
	FILE* fid = fopen(argsname, "rt");
	char stmp[1000];
	
	fscanf(fid,"%s%s\n",stmp,ag->dataname);
	fscanf(fid, "%s%s\n",stmp, ag->savename);
	fscanf(fid, "%s%d\n",stmp, &(ag->numOfJumps));
	fscanf(fid, "%s%d\n",stmp, &(ag->totalIters));
	fscanf(fid, "%s%d\n",stmp, &(ag->burnin));
	fscanf(fid, "%s%d\n",stmp, &(ag->recStep));
	fscanf(fid, "%s%lf\n",stmp, &(ag->aParJumpHeight));
	fscanf(fid, "%s%lf\n",stmp, &(ag->bParJumpHeight));
	fscanf(fid, "%s%lf\n",stmp, &(ag->aParPopJumpHeight));
	fscanf(fid, "%s%lf\n",stmp, &(ag->bParPopJumpHeight));
	fscanf(fid, "%s%lf\n",stmp, &(ag->aParKernel));
	fscanf(fid, "%s%lf\n",stmp, &(ag->bParKernel));
	fscanf(fid, "%s%lf\n",stmp, &(ag->updSdParKernel));
	fscanf(fid, "%s%d\n",stmp, &(ag->adjustStep));
	fscanf(fid, "%s%d\n",stmp, &(ag->randInitial));
	fscanf(fid, "%s%lf\n",stmp, &(ag->updSdParPopJumpHeights));
	fscanf(fid, "%s%d\n",stmp, &(ag->predict));
	fscanf(fid, "%s%s\n",stmp,ag->preddataname);
	fscanf(fid, "%s%lf\n",stmp,&(ag->updSdJump));

	fclose(fid);
	
	return ag;
}

void free_ModelArgs(ModelArgs* ag)
{
	free(ag);
}

HGammaRF* initial_HGammaRF(const char* maskname, const char* argsname, const char* seedname)
{
	HGammaRF* model = (HGammaRF*)malloc(sizeof(HGammaRF));
	
	model->margs = read_ModelArgs(argsname);
	model->gdat = read_GroupData(model->margs->dataname);
	
	if(model->margs->predict==1)
	{
		model->pdat = read_GroupData(model->margs->preddataname);
	}

	
	
	model->bmask = read_BrainMask(maskname);
	
	model->numOfbsubmask = 2;
	model->bsubmask = (BrainMask**)malloc(sizeof(BrainMask*)*model->numOfbsubmask);
	model->bsubmask[0] = read_BrainMask("Amygdala_L.nii");
	model->bsubmask[1] = read_BrainMask("Amygdala_R.nii");
	
	
	model->intensityCov0 = mat_alloc(model->gdat->numOfTypes);
	model->intensityCov1 = mat_alloc(model->gdat->numOfTypes);
	model->intensityCov01 = mat_alloc(model->gdat->numOfTypes);
	
	
	
	model->subIntensity = vec_list_alloc(model->gdat->numOfTypes, model->numOfbsubmask);
	model->subIntCrossProduct0 = mat_alloc(model->gdat->numOfTypes);
	model->subIntCrossProduct1 = mat_alloc(model->gdat->numOfTypes);
	model->subIntCrossProduct01 = mat_alloc(model->gdat->numOfTypes);
	model->subIntSum = vec_list_alloc(model->gdat->numOfTypes, model->numOfbsubmask);
	
	
	
	model->seed = initial_seed(seedname);
	
	//initial auxilary points
	model->auxiliaryPoints = alloc_listPoints(model->gdat->numOfPoints, model->gdat->numOfGroups);
	model->indicesAuxPoints = alloc_listIndices(model->gdat->numOfPoints, model->gdat->numOfGroups);
	
	
	
	model->numOfDistinctPoints = model->margs->numOfJumps;
	model->numOfTies = vec_int_list_alloc(model->margs->numOfJumps, model->gdat->numOfTypes);
	
	model->jumpLocations = vec_list_alloc(DIM, model->margs->numOfJumps);
	model->jumpHeights = vec_list_alloc(model->margs->numOfJumps,model->gdat->numOfTypes);
	model->popJumpHeights = vec_alloc(model->margs->numOfJumps);
	
	model->newJumpIndicators = (int*)calloc(model->margs->numOfJumps,sizeof(int));
	
	model->kernelOverBrain = vec_list_alloc(model->margs->numOfJumps,model->gdat->numOfTypes);

	model->typeIntensity = Array_list_alloc(model->bmask->dim[2], model->bmask->dim[1], model->bmask->dim[0], model->gdat->numOfTypes);
	
	model->meanTypeIntensity = Array_list_alloc(model->bmask->dim[2], model->bmask->dim[1], model->bmask->dim[0], model->gdat->numOfTypes);
	
	model->sdTypeIntensity = Array_list_alloc(model->bmask->dim[2], model->bmask->dim[1], model->bmask->dim[0], model->gdat->numOfTypes);
	
	model->meanPopIntensity = Array_alloc(model->bmask->dim[2], model->bmask->dim[1], model->bmask->dim[0]);
	model->sdPopIntensity = Array_alloc(model->bmask->dim[2], model->bmask->dim[1], model->bmask->dim[0]);
	model->popIntensity = Array_alloc(model->bmask->dim[2], model->bmask->dim[1], model->bmask->dim[0]);
	
	model->logDensitiesForData = vec_list_alloc(model->gdat->numOfTypes,model->gdat->numOfGroups);
	model->densityRatio = vec_list_alloc(model->gdat->numOfTypes, model->gdat->numOfGroups);
	model->meanDensityRatio = vec_list_alloc(model->gdat->numOfTypes, model->gdat->numOfGroups);
	model->sdDensityRatio = vec_list_alloc(model->gdat->numOfTypes, model->gdat->numOfGroups);
	model->loocvPredProb = vec_list_alloc(model->gdat->numOfTypes,model->gdat->numOfGroups);
	model->loocvPredType = (int*)calloc(model->gdat->numOfGroups,sizeof(int));
	model->confusionMatrix = mat_alloc(model->gdat->numOfTypes);
	
	
	model->updSdParKernel = vec_alloc(model->gdat->numOfTypes);
	model->acptUpdParKernel = vec_alloc(model->gdat->numOfTypes);
	
	
	model->parKernel = vec_alloc(model->gdat->numOfTypes);
	
    if(model->margs->predict==1)
	{
		model->logDensitiesForDataPred = vec_list_alloc(model->gdat->numOfTypes,model->pdat->numOfGroups);

		model->meanDensityPred = vec_list_alloc(model->gdat->numOfTypes, model->pdat->numOfGroups);
		model->sdDensityPred = vec_list_alloc(model->gdat->numOfTypes, model->pdat->numOfGroups);
		model->predProb = vec_list_alloc(model->gdat->numOfTypes,model->pdat->numOfGroups);
		
		model->maxDensityPred = vec_alloc(model->pdat->numOfGroups);
		
		model->predType = (int*)calloc(model->pdat->numOfGroups,sizeof(int));
		model->confusionMatrixPred = vec_list_alloc(model->gdat->numOfTypes, model->pdat->numOfTypes);
	}
		
	
	
	
	
	char command[1000];
	sprintf(command, "mkdir simresults");
	system(command);
	sprintf(command, "mkdir simresults/%s",model->margs->savename);
	system(command);
	


	
	char fileName[1000];
	sprintf(fileName,"simresults/%s/%s.trace",model->margs->savename,model->margs->savename);
	model->traceFid = fopen(fileName, "wt");
	
	
	sprintf(fileName,"simresults/%s/%s.jumpTrace",model->margs->savename,model->margs->savename);
	model->jumpTraceFid = fopen(fileName, "wt");

	
	for(int j=0; j<model->gdat->numOfTypes; j++)
	{
		model->updSdParKernel[j] = model->margs->updSdParKernel;
		model->acptUpdParKernel[j] = 0.0;
	}
	
	
	
	
	model->updSdParPopJumpHeights = model->margs->updSdParPopJumpHeights;
	
	model->acptUpdParPopJumpHeights = 0.0;
	
	model->traceidx = (int*)calloc(10, sizeof(int));
	
	model->sigmai = vec_int_list_alloc(model->gdat->totalNumOfPoints, model->margs->numOfJumps);
	
	
	model->sigmaj = vec_int_list_alloc(model->gdat->totalNumOfPoints, model->margs->numOfJumps);
	
	model->sigmaNum = (int*)calloc(model->margs->numOfJumps,sizeof(int));
	
	return model;
}


void free_HGammaRF(HGammaRF* model)
{
	free(model->sigmaNum);
	vec_int_list_free(model->sigmai, model->margs->numOfJumps);
	vec_int_list_free(model->sigmaj, model->margs->numOfJumps);
	
	free(model->parKernel);
	
	free(model->updSdParKernel);
	free(model->acptUpdParKernel);
	
	free(model->traceidx);
	
	mat_free(model->intensityCov0, model->gdat->numOfTypes);
	mat_free(model->intensityCov1, model->gdat->numOfTypes);	
	mat_free(model->intensityCov01, model->gdat->numOfTypes);	
	vec_list_free(model->subIntensity, model->numOfbsubmask);
	vec_list_free(model->subIntSum, model->numOfbsubmask);
	mat_free(model->subIntCrossProduct0, model->gdat->numOfTypes);
	mat_free(model->subIntCrossProduct1, model->gdat->numOfTypes);
	mat_free(model->subIntCrossProduct01, model->gdat->numOfTypes);
	

	mat_free(model->confusionMatrix,model->gdat->numOfTypes);

	free(model->loocvPredType);
	fclose(model->traceFid);
	fclose(model->jumpTraceFid);
	vec_list_free(model->loocvPredProb, model->gdat->numOfGroups);
	vec_list_free(model->meanDensityRatio,model->gdat->numOfGroups);
	vec_list_free(model->sdDensityRatio,model->gdat->numOfGroups);	
	vec_list_free(model->densityRatio,model->gdat->numOfGroups);
	
	
	if(model->margs->predict==1)
	{
		vec_list_free(model->logDensitiesForDataPred, model->pdat->numOfGroups);
		vec_list_free(model->meanDensityPred, model->pdat->numOfGroups);
		vec_list_free(model->sdDensityPred, model->pdat->numOfGroups);
		vec_list_free(model->predProb, model->pdat->numOfGroups);
		
		free(model->maxDensityPred);

		
		free(model->predType);
		vec_list_free(model->confusionMatrixPred,model->pdat->numOfTypes);		
		
	}
	
	vec_list_free(model->logDensitiesForData, model->gdat->numOfGroups);

	free(model->newJumpIndicators);
	Array_list_free(model->typeIntensity, model->bmask->dim[2],model->bmask->dim[1], model->bmask->dim[0], model->gdat->numOfTypes);
	Array_list_free(model->meanTypeIntensity, model->bmask->dim[2],model->bmask->dim[1], model->bmask->dim[0], model->gdat->numOfTypes);
	Array_list_free(model->sdTypeIntensity, model->bmask->dim[2],model->bmask->dim[1], model->bmask->dim[0], model->gdat->numOfTypes);
	
	Array_free(model->popIntensity,  model->bmask->dim[2],model->bmask->dim[1], model->bmask->dim[0]);
	Array_free(model->meanPopIntensity,  model->bmask->dim[2],model->bmask->dim[1], model->bmask->dim[0]);
	Array_free(model->sdPopIntensity,  model->bmask->dim[2],model->bmask->dim[1], model->bmask->dim[0]);
	
	vec_list_free(model->kernelOverBrain, model->gdat->numOfTypes);
	free(model->popJumpHeights);
	vec_list_free(model->jumpHeights, model->gdat->numOfTypes);
	vec_list_free(model->jumpLocations, model->margs->numOfJumps);
	
	vec_int_list_free(model->numOfTies,model->gdat->numOfTypes);
	free_listIndices(model->indicesAuxPoints, model->gdat->numOfGroups);
	free_listPoints(model->auxiliaryPoints, model->gdat->numOfPoints, model->gdat->numOfGroups);
	free_BrainMask(model->bmask);
	
	for(int i=0; i<model->numOfbsubmask; i++)
		free_BrainMask(model->bsubmask[i]);
	free(model->bsubmask);
	
	if(model->margs->predict==1)
	{
		free_GroupData(model->pdat);
	}
	
	free_GroupData(model->gdat);	
	free_ModelArgs(model->margs);
	free(model->seed);
	free(model);
	
}


double*** alloc_listPoints(int* numOfPoints, int numOfLists)
{
	double*** listPoints = (double***)calloc(numOfLists, sizeof(double**));
	for(int i=0; i<numOfLists; i++)
	{
		listPoints[i] = (double**)calloc(numOfPoints[i],sizeof(double*));
		for(int j=0; j<numOfPoints[i]; j++)
		{
			listPoints[i][j] = (double*)calloc(DIM, sizeof(double));
		}
	}	
	
	return listPoints;
}


void free_listPoints(double*** listPoints, int* numOfPoints, int numOfLists)
{
	for(int i=0; i<numOfLists; i++)
	{
		
		for(int j=0; j<numOfPoints[i]; j++)
		{
			free(listPoints[i][j]);
		}
		free(listPoints[i]);
	}	
	
	free(listPoints);
	
}


int** alloc_listIndices(int* numOfPoints, int numOfLists)
{
	int** listIndices = (int**)calloc(numOfLists, sizeof(int*));
	for(int i=0; i<numOfLists; i++)
	{
		listIndices[i] = (int*)calloc(numOfPoints[i], sizeof(int));
	}
	return listIndices;
}


void free_listIndices(int** listIndices,int numOfLists)
{
	for(int i=0; i<numOfLists; i++)
	{
		free(listIndices[i]);
	}
	free(listIndices);
}


/*double log_kernel(double* x, double *y, double theta)
{
	return 3.0*log(theta)-theta*vec_abs_dist(x, y, DIM)-2.079441541679836;
}*/

double log_kernel(double* x, double *y, double theta)
{
	return 1.5*log(theta)-0.5*theta*vec_dist(x, y, DIM)-2.75681559961402;
}


double kernel(double*x, double *y, double theta)
{
	return exp(log_kernel(x, y, theta));
}

void initial_values(HGammaRF* model)
{
	int gidx, pidx;
	//initialize jump locations
	for(int i=0; i<model->margs->numOfJumps; i++)
	{
		//draw_pointsOnBrain(model->jumpLocations[i], model->bmask, model->seed);
		//vec_print(model->jumpLocations[i], DIM, " %lf");
		
		gidx = floor(kiss(model->seed)*model->gdat->numOfGroups);
		pidx = floor(kiss(model->seed)*model->gdat->numOfPoints[gidx]);
		
		//printf("gidx = %d, pidx = %d\n",gidx, pidx);
		
		vec_copyval(model->jumpLocations[i], model->gdat->dataGroupPoints[gidx][pidx], DIM);
		
	}
	
	//iniitalize jump height
	
	if(model->margs->randInitial==1)
	{
		model->parPopJumpHeight = rgamma(model->margs->aParPopJumpHeight, model->margs->bParPopJumpHeight, model->seed);
		model->parJumpHeight = rgamma(model->margs->aParJumpHeight, model->margs->bParJumpHeight, model->seed);
		
		if(model->margs->bParKernel!=0.0)
		{
			for (int j=0; j<model->gdat->numOfTypes; j++) {
				model->parKernel[j] = rgamma(model->margs->aParKernel, model->margs->bParKernel, model->seed);
			}
		}
		else
		{
			for (int j=0; j<model->gdat->numOfTypes; j++) {
				model->parKernel[j] = 2.9*kiss(model->seed) + 0.1;
			}
						
		}
		 
	}
	else
	{
		model->parPopJumpHeight = model->margs->aParPopJumpHeight/model->margs->bParPopJumpHeight;
		model->parJumpHeight = model->margs->aParJumpHeight/model->margs->bParJumpHeight;
		
		if(model->margs->bParKernel!=0.0)
		{
			for(int j=0; j<model->gdat->numOfTypes; j++){
				model->parKernel[j] = model->margs->aParKernel/model->margs->bParKernel;
			}
		}
		else
		{
			for(int j=0; j<model->gdat->numOfTypes; j++){
				model->parKernel[j] = 1.0;
			}			
			
		}
				
		
	}
	
	double* jumpTimes = vec_alloc(model->margs->numOfJumps);
	jumpTimes[0] = rexp(1,model->seed);
	for(int i=1; i<model->margs->numOfJumps; i++)
	{
		jumpTimes[i] = jumpTimes[i-1] + rexp(1, model->seed);
		model->popJumpHeights[i] = invExpIntegralFun(jumpTimes[i])/model->parPopJumpHeight;		
		
		//printf("%lf",model->popJumpHeights[i]);
		
		for(int j=0; j<model->gdat->numOfTypes; j++)
		{
			if(model->popJumpHeights[i]>0.0)
			{
				if(model->margs->randInitial==1)
				{
					model->jumpHeights[j][i] = rgamma(model->popJumpHeights[i], model->parJumpHeight, model->seed);
					while (model->jumpHeights[j][i]==0.0) {
						model->jumpHeights[j][i] = rgamma(model->popJumpHeights[i], model->parJumpHeight, model->seed);
					}
				}
				else
				{
					model->jumpHeights[j][i] = model->popJumpHeights[i]/model->parJumpHeight;
				}
			}
			else 
			{
				model->jumpHeights[j][i] = 0.0;
			}

			//printf(" %lf",model->jumpHeights[j][i]);
		}
		//printf("\n");
	}
	

	update_kernelOverBrain(model);
	
	
	
	
	
	model->recIntCount = 0;
	model->recDenCount = 0;
	
	model->recDenCountPred = 0;

	
	free(jumpTimes);
}


void update_auxiliaryPoints(HGammaRF* model)
{
	double* prob = vec_alloc(model->margs->numOfJumps);
	double maxprob=-1e200;
	
	
	for(int j=0; j<model->gdat->numOfTypes; j++)
		for(int m=0; m<model->margs->numOfJumps; m++)
			model->numOfTies[j][m] = 0;
	
	
	for(int k=0; k<model->margs->numOfJumps; k++)
	{						
		model->newJumpIndicators[k] = 0;
		model->sigmaNum[k] = 0;
	}
	

	for(int i=0; i<model->gdat->numOfGroups; i++)
	{
		for(int j=0; j<model->gdat->numOfPoints[i]; j++)
		{
			//compute log unormalized probabilities
			maxprob = -1e200;
			for(int k=0; k<model->margs->numOfJumps; k++)
			{				
				prob[k] = log(model->jumpHeights[model->gdat->trueTypes[i]][k]+1e-300)
				+log_kernel(model->jumpLocations[k], model->gdat->dataGroupPoints[i][j], model->parKernel[model->gdat->trueTypes[i]]);
				if(prob[k]>maxprob)
					maxprob = prob[k];
			}
			
			//compute unormalized probabilities
			for(int k=0; k<model->margs->numOfJumps; k++)
				prob[k] = exp(prob[k]-maxprob);
			
			//compute cumulative unormalized probailities
			for(int k=1; k<model->margs->numOfJumps; k++)
				prob[k] += prob[k-1];
			
			
			//compute cumulative probabilities
			for(int k=0; k<model->margs->numOfJumps; k++)
				prob[k] /= prob[model->margs->numOfJumps-1];
			
			//update indices
			
			//vec_print(prob, model->margs->numOfJumps, " %lg");
			
			model->indicesAuxPoints[i][j] = rmultinomial(prob, model->margs->numOfJumps, model->seed);
			
			model->sigmai[model->indicesAuxPoints[i][j]][model->sigmaNum[model->indicesAuxPoints[i][j]]] = i;
			model->sigmaj[model->indicesAuxPoints[i][j]][model->sigmaNum[model->indicesAuxPoints[i][j]]] = j;
			
			model->sigmaNum[model->indicesAuxPoints[i][j]]++;
			
			
			//printf("%d\n",model->indicesAuxPoints[i][j]);
			
			model->numOfTies[model->gdat->trueTypes[i]][model->indicesAuxPoints[i][j]]++;
			
			model->newJumpIndicators[model->indicesAuxPoints[i][j]] = 1;
			
			
			//update auxiliary points
			//vec_copyval(model->auxiliaryPoints[i][j], model->jumpLocations[model->indicesAuxPoints[i][j]], DIM);
			
			/*for(int k=0; k<3; k++)
			{
				model->auxiliaryPoints[i][j][k] = rnorm(model->jumpLocations[model->indicesAuxPoints[i][j]][k], 0.0001, model->seed);
			}*/
			
			//vec_copyval(model->jumpLocations[model->indicesAuxPoints[i][j]],model->auxiliaryPoints[i][j], DIM);
			
			/*printf("y = \n");
			vec_print(model->gdat->dataGroupPoints[i][j], DIM, " %lg");
			printf("x = \n");
			vec_print(model->auxiliaryPoints[i][j], DIM, " %lg");*/
			
			
		}
		
		
	}
	
	
	
	free(prob);
}



void update_auxiliaryPoints_MH(HGammaRF* model)
{
	double* temp = vec_alloc(DIM);
	double acpt = 0.0;
	for(int i=0; i<model->gdat->numOfGroups; i++)
	{
		for(int j=0; j<model->gdat->numOfPoints[i]; j++)
		{
			for(int k=0; k<DIM; k++)
			{
				temp[k] = rnorm(model->auxiliaryPoints[i][j][k], 0.1, model->seed);
			}
			acpt = log_kernel(temp, model->gdat->dataGroupPoints[i][j], model->parKernel[model->gdat->trueTypes[i]]) 
			- log_kernel(model->auxiliaryPoints[i][j], model->gdat->dataGroupPoints[i][j], model->parKernel[model->gdat->trueTypes[i]]);
			if(log(kiss(model->seed)<acpt))
			{
				vec_copyval(model->auxiliaryPoints[i][j], temp, DIM);
				vec_copyval(model->jumpLocations[model->indicesAuxPoints[i][j]], temp, DIM);
			}
			
		}
	}
	
	free(temp);
}

void update_kernelOverBrain(HGammaRF* model)
{
	for(int j=0; j<model->gdat->numOfTypes; j++)
	{
		for(int i=0; i<model->margs->numOfJumps; i++)
		{
			model->kernelOverBrain[j][i] = compute_kernelOverBrain(model->jumpLocations[i], model->parKernel[j], model->bmask, model->seed);
		}
	}
}



void update_jumpLocations(HGammaRF* model)
{
	double* newlocation = vec_alloc(DIM);
	double* newKernelOverBrain = vec_alloc(model->gdat->numOfTypes);
	double acpt = 0.0;
	int ii, jj;
	
	for(int k=0; k<model->margs->numOfJumps; k++)
	{
		if(model->newJumpIndicators[k]==0)
		{
			draw_pointsOnBrain(newlocation, model->bmask, model->seed);
			
			acpt = 0.0;
			for(int j=0; j<model->gdat->numOfTypes; j++)
			{
				newKernelOverBrain[j] = compute_kernelOverBrain(newlocation, model->parKernel[j], model->bmask, model->seed);
				acpt += (model->kernelOverBrain[j][k]-newKernelOverBrain[j])*model->jumpHeights[j][k]*model->gdat->numInTypes[j];
			}
			
			if(log(kiss(model->seed))<acpt)
			{
				vec_copyval(model->jumpLocations[k], newlocation, DIM);
				for(int j=0; j<model->gdat->numOfTypes; j++)
					model->kernelOverBrain[j][k] = newKernelOverBrain[j];
				//printf("accept!\n");
			}
			
			
		}
		else
		{
			for(int l=0; l<DIM; l++)
			{
				newlocation[l] = rnorm(model->jumpLocations[k][l], model->margs->updSdJump, model->seed);
			}
			
			acpt = 0.0;
			for(int j=0; j<model->gdat->numOfTypes; j++)
			{
				newKernelOverBrain[j] = compute_kernelOverBrain(newlocation, model->parKernel[j], model->bmask, model->seed);
				acpt += (model->kernelOverBrain[j][k]-newKernelOverBrain[j])*model->jumpHeights[j][k]*model->gdat->numInTypes[j];
			}
			
			for(int i=0; i<model->sigmaNum[k]; i++)
			{
				ii = model->sigmai[k][i];
				jj = model->sigmaj[k][i];
				acpt += (log_kernel(newlocation, model->gdat->dataGroupPoints[ii][jj], model->parKernel[model->gdat->trueTypes[ii]]) 
				- log_kernel(model->jumpLocations[k], model->gdat->dataGroupPoints[ii][jj], model->parKernel[model->gdat->trueTypes[ii]]));
			}
			
			
			if(log(kiss(model->seed))<acpt)
			{
				vec_copyval(model->jumpLocations[k], newlocation, DIM);
				for(int j=0; j<model->gdat->numOfTypes; j++)
					model->kernelOverBrain[j][k] = newKernelOverBrain[j];
				//printf("accept!\n");
			}
			

			
		}
	}
	
	free(newlocation);
	free(newKernelOverBrain);
}



void update_jumpHeights(HGammaRF* model)
{
	double a, b;
	
	for(int m=0; m<model->margs->numOfJumps;m++)
	{

		for(int j=0; j<model->gdat->numOfTypes; j++)		
		{
			a = model->popJumpHeights[m] + model->numOfTies[j][m];
			b = model->gdat->numInTypes[j]*model->kernelOverBrain[j][m]+model->parJumpHeight;
			
			

			model->jumpHeights[j][m] = rgamma(a, b, model->seed);
			while (model->jumpHeights[j][m]==0.0) {
				model->jumpHeights[j][m] = rgamma(a, b, model->seed);
			}
			
			//if(model->numOfTies[j][m]>0)
			//{
			//	printf("m = %d, a = %lg, b = %lg, nt = %d, n = %d, kB = %lg, jh = %lg, tau = %lg\n",m,a, b,model->numOfTies[j][m], model->gdat->numInTypes[j], model->kernelOverBrain[m],model->jumpHeights[j][m],
			//		   model->parJumpHeight);			
			//}
			
		}

		
	}
}


double log_mDensityOfpopJumps(double x, void*dat)
{
	double* logc = (double*)dat;
	return(x**logc-lgamma(x+1.0));
}


double log_MDensityOfpopJumps(double x, void*dat)
{
	double* ddat = (double*)dat;
	double logc = ddat[0];
	double beta = ddat[1];
	
	return(-expIntegralFun(beta*x) + x*logc-lgamma(x+1.0));
}


double draw_mPopJumpHeights(double logcm, unsigned long* seed)
{
	
	double newPopJumpHeights;
	
	int err, ninit=100, npoint=500, nsamp=1, ncent=0, neval, dometrop = 0; 
	double xinit[ninit], convex=1.0, qcent, xcent, *xl, *xr, *xprev;
	
	
	
	xl = (double*)malloc(sizeof(double));
	xr = (double*)malloc(sizeof(double));
	xprev = (double*)malloc(sizeof(double));
	
	
	*xl = 1e-300;
	/*if(logcm<0.0)
	{
		*xr = 1.0;
	}
	else
	{
		*xr = 5.0*sqrt(exp(logcm));
	}*/
	
	*xr = 5.0;
	
	

	
	
	/* set up starting values */
	for(int i=0; i<ninit; i++){
		xinit[i] = *xl + (i + 1.0) * (*xr - *xl)/(ninit + 1.0);
	}
	//vec_print(xinit, ninit, "%10.3lf");
	*xprev = 1e-10;
	
	err = arms_kiss(xinit,ninit,xl,xr,log_mDensityOfpopJumps,&logcm,&convex,npoint,dometrop,xprev,&newPopJumpHeights,
			   nsamp,&qcent,&xcent,ncent,&neval, seed);
	
	
	if(err!=0)
		printf("error %d in updating m popJumpHeights\n", err);
	
	free(xl);
	free(xr);
	free(xprev);
	
	
	//newPopJumpHeights = exp(logcm);
	
	//printf("v = %lf, cm = %lf\n",newPopJumpHeights,exp(logcm));

	return newPopJumpHeights;
}


double draw_mPopJumpHeights_MH(double xprev, double logcm, unsigned long* seed)
{
	double xnew;
	double cm = exp(logcm);
	double rate,mu,sigma,acpt;
	
	if(cm<0.5)
	{
		rate = -logcm;
		xnew = rexp(rate, seed);
		
		acpt = lgamma(xprev)-lgamma(xnew)+log(xprev)-log(xnew);
		
		if(log(kiss(seed))<acpt)
		{
			return xnew;
		}
		else {
			return xprev;
		}
		
	}
	else
	{
		
		mu = cm;
		sigma = sqrt(cm);

		xnew = rnorm(mu, sigma, seed);
		
		if(xnew>0.0)
		{
			acpt = (xnew-xprev)*(logcm - 1.0)+lgamma(xprev)-lgamma(xnew)+log(xprev)-log(xnew) + 0.5*(xnew*xnew-xprev*xprev)/cm;
			if(log(kiss(seed))<acpt)
			{
				return xnew;
			}
			else {
				return xprev;
			}
		}
		else
		{
			return xprev;
		}
		
		
	}
	
	
	
}



double draw_MPopJumpHeights(double logcm, double beta, unsigned long* seed)
{
	
	double newPopJumpHeights;
	
	int err, ninit=100, npoint=500, nsamp=1, ncent=0, neval, dometrop = 0; 
	double xinit[ninit], convex=1.0, qcent, xcent, *xl, *xr, *xprev;
	
	double* dat = vec_alloc(2);
	dat[0] = logcm;
	dat[1] = beta;
	
	
	xl = (double*)malloc(sizeof(double));
	xr = (double*)malloc(sizeof(double));
	xprev = (double*)malloc(sizeof(double));
	
	
	*xl = 1e-300;
	
	/*if(logcm<0.0)
	{
		*xr = 1.0;
	}
	else
	{
		*xr = 5.0*sqrt(exp(logcm));
	}*/
	
	*xr = 10.0;
	
	/* set up starting values */
	for(int i=0; i<ninit; i++){
		xinit[i] = *xl + (i + 1.0) * (*xr - *xl)/(ninit + 1.0);
	}
	//vec_print(xinit, ninit, "%10.3lf");
	*xprev = 1e-10;
	
	err = arms_kiss(xinit,ninit,xl,xr,log_MDensityOfpopJumps,&dat,&convex,npoint,dometrop,xprev,&newPopJumpHeights,
			   nsamp,&qcent,&xcent,ncent,&neval,seed);
	
	
	if(err!=0)
		printf("error %d in updating M popJumpHeights\n", err);
	
	free(xl);
	free(xr);
	free(xprev);
	free(dat);
	
	
	//newPopJumpHeights = exp(logcm);
	
	return newPopJumpHeights;
}


/*double draw_MPopJumpHeights_MH(double logcm, double beta, unsigned long* seed)
{
	double newPopJumpHeights;
	
	
	return newPopJumpHeights;
}*/



void update_popJumpHeights(HGammaRF* model)
{
	double logcm;
	for(int m=0; m<model->margs->numOfJumps; m++)
	{
		logcm = model->gdat->numOfTypes*log(model->parJumpHeight)-model->parPopJumpHeight;
		
		for(int j=0; j<model->gdat->numOfTypes; j++)
		{
			logcm += log(model->jumpHeights[j][m]);
		}
		
		if(m<model->margs->numOfJumps-1)
		{

			model->popJumpHeights[m] = draw_mPopJumpHeights(logcm,model->seed);
			//model->popJumpHeights[m] = draw_mPopJumpHeights_MH(model->popJumpHeights[m], logcm, model->seed);
			

		}
		else
		{
			//printf("p = %lg\n",model->parPopJumpHeight);
			//model->popJumpHeights[m] = draw_MPopJumpHeights(logcm, model->parPopJumpHeight, model->seed);
			model->popJumpHeights[m] = draw_mPopJumpHeights(logcm,model->seed);
			//model->popJumpHeights[m] = draw_mPopJumpHeights_MH(model->popJumpHeights[m],logcm,model->seed);
			//printf("m = %d, pjh =  %lg\n", m, model->popJumpHeights[m]);

		}
		
	    /*if(model->popJumpHeights[m]>0.2 || m==model->margs->numOfJumps-1)
		{
		printf("m = %d, ntype = %d, tau = %lg, beta = %lg, logcm = %lg, nu = %lg, ",m, model->gdat->numOfTypes,model->parJumpHeight, model->parPopJumpHeight, logcm,
			   model->popJumpHeights[m]);
			for(int j=0;j<model->gdat->numOfTypes; j++)
			{
				printf("mu[%d] = %lg, n[%d]= %d, ", j, model->jumpHeights[j][m],j, model->numOfTies[j][m]);
			}
			printf("\n");
			
		}*/
		
	}
}

double compute_kernelOverBrain(double*x, double theta, BrainMask* bmask, unsigned long* seed)
{
	double kernelOverBrain = 0.0;
	double sd = sqrt(1.0/theta);
	double scale = 3.0;
	double*** pts = Array_alloc(DIM, 2, DIM);
	double* pt = vec_alloc(DIM);
	int totalSim = 500;
	
	int inFlag = 1;
	
	for(int i=0; i<DIM; i++){
		
		for(int j=0; j<DIM; j++){
			
			if (i==j) {
				pts[i][0][j] = x[i]-scale*sd;
				pts[i][1][j] = x[i]+scale*sd;
			}
			else
			{
				pts[i][0][j] = x[j];
				pts[i][1][j] = x[j];
			}			
		}
		
		for (int j=0; j<2; j++) {
			inFlag *= inRange(pts[i][j], DIM, bmask->brain, bmask->dim);
		}
				
		if(!inFlag)
		  break;
	}
	
	if (inFlag) {
		kernelOverBrain = 0.999;
	}
	else
	{
		kernelOverBrain = 0.0;
		for(int i=0; i<totalSim; i++)
		{
			for(int j=0; j<DIM; j++)
				pt[j] = rnorm(x[j], sd, seed);
			
			if(inRange(pt, DIM, bmask->brain, bmask->dim))
			{
				kernelOverBrain++;
			}
		}
		kernelOverBrain /= totalSim;
		
/*		if (kernelOverBrain==0.0) {
			printf("kernelOverBrain = %lf\n",kernelOverBrain);
			vec_print(x, DIM, " %lf");
			printf("sd = %lf\n",sd);
		}
*/
	}
	
	free(pt);
	Array_free(pts,DIM,2,DIM);
	return kernelOverBrain;
}


void update_parKernel_MH(HGammaRF* model)
{
	double* newKernelOverBrain = vec_alloc(model->margs->numOfJumps);
	
	double newtheta;
	double acpt;
	double* S2 = vec_alloc(model->margs->numOfJumps);
	
			
		

	for(int i=0; i<model->gdat->numOfGroups; i++)
	{
		for (int l=0; l<model->gdat->numOfPoints[i]; l++) {
			S2[model->gdat->trueTypes[i]] += vec_abs_dist(model->gdat->dataGroupPoints[i][l],
														  model->jumpLocations[model->indicesAuxPoints[i][l]], DIM);
		}
        
	}
	
	
	
	for(int j=0; j<model->gdat->numOfTypes; j++)
	{		
		newtheta = rnorm(model->parKernel[j],model->updSdParKernel[j], model->seed);
		
		if(newtheta>0.0 && newtheta<10.0)
		{
			
			acpt = 0.0;
			for(int m=0; m<model->margs->numOfJumps; m++){
								
				newKernelOverBrain[m] = compute_kernelOverBrain(model->jumpLocations[m], newtheta, model->bmask, model->seed);
				acpt += (model->kernelOverBrain[j][m] - newKernelOverBrain[m])*model->jumpHeights[j][m]*model->gdat->numInTypes[j];
				
			}
			
			
			acpt += (model->margs->aParKernel + DIM*model->gdat->numPtsInTypes[j]*0.5 - 1.0)*(log(newtheta)-log(model->parKernel[j]));
			acpt += (model->margs->bParKernel + 0.5*S2[j])*(model->parKernel[j] - newtheta);
			

			//printf("S2 = %lf, newtheta = %lf, acpt = %lf\n",S2, newtheta,acpt);
			//vec_print(model->kernelOverBrain,model->margs->numOfJumps," %lf");
			
			
			if(log(kiss(model->seed)) < acpt)
			{
				model->parKernel[j] = newtheta;
				vec_copyval(model->kernelOverBrain[j],newKernelOverBrain,model->margs->numOfJumps);
				model->acptUpdParKernel[j]++;
				
			}
		}
		
	}	
	free(newKernelOverBrain);	
	
	free(S2);
	
}


void update_parJumpHeights(HGammaRF* model)
{
	double a,b;
	
	a = 0.0;
	for(int m=0; m<model->margs->numOfJumps; m++)
	{
		a += model->popJumpHeights[m];
		//if(model->popJumpHeights[m]>1.0)
		//	printf("[%d] = %lg\n",m, model->popJumpHeights[m]);
	}

//s	printf("a = %lg\n",a);
	a *= model->gdat->numOfTypes;
	a += model->margs->aParJumpHeight; 
	
	b = model->margs->bParJumpHeight;
	for(int j=0; j<model->gdat->numOfTypes; j++)
	{
		for(int m=0; m<model->margs->numOfJumps; m++)
		{
			b += model->jumpHeights[j][m];
		}
	}
	
	model->parJumpHeight = rgamma(a, b, model->seed);
	printf("a = %lg, b = %lg , r = %lg\n",a ,b, model->parJumpHeight);
	
	
}


double logDenOfBeta(double beta, void* dat)
{
	double* ddat = (double*)(dat);	

	return ddat[0]*log(beta)-ddat[1]*beta - expIntegralFun(ddat[2]*beta);
}

void update_parPopJumpHeights(HGammaRF* model)
{
	int err, ninit=100, npoint=500, nsamp=1, ncent=0, neval, dometrop = 0; 
	double xinit[ninit], convex=1.0, qcent, xcent, *xl, *xr, *xprev;
	double newParPopJumpHeights;
	
	double* dat = vec_alloc(3);
	dat[0] = model->margs->aParPopJumpHeight - 1.0;
	dat[1] = model->margs->bParPopJumpHeight;
	
	for(int m=0; m<model->margs->numOfJumps; m++)
	{
		dat[1] += model->popJumpHeights[m];
	}
	
	dat[2] = model->popJumpHeights[model->margs->numOfJumps - 1];
	printf("d0 = %lg, d1 = %lg, d2 = %lg\n",dat[0],dat[1],dat[2]);
	
	
	
	xl = (double*)malloc(sizeof(double));
	xr = (double*)malloc(sizeof(double));
	xprev = (double*)malloc(sizeof(double));
	
	
	*xl = 1e-100;
	*xr = 10.0;
	
	//if(*xr<*xl)
	//	*xl = *xr/10.0;
	
	
	/* set up starting values */
	for(int i=0; i<ninit; i++){
		xinit[i] = *xl + (i + 1.0) * (*xr - *xl)/(ninit + 1.0);
	}
	//vec_print(xinit, ninit, "%10.3lf");
	*xprev = 1e-10;
	
	
		printf("beta = %lg\n",newParPopJumpHeights);
	
	err = arms_kiss(xinit,ninit,xl,xr,logDenOfBeta,&dat,&convex,npoint,dometrop,xprev,&(newParPopJumpHeights),
			   nsamp,&qcent,&xcent,ncent,&neval,model->seed);
	
	
	model->parPopJumpHeight = newParPopJumpHeights;
	printf("beta = %lg\n",newParPopJumpHeights);
	
	if(err!=0)
		printf("error %d in updating beta\n",err);
	
	free(xl);
	free(xr);
	free(xprev);
	free(dat);
	
}


void update_parPopJumpHeights_MH(HGammaRF* model)
{
	double newParPopJumpHeights = rnorm(model->parPopJumpHeight, model->updSdParPopJumpHeights, model->seed);
	double acpt;
	double sumnu;
	
	if(newParPopJumpHeights>0.0)
	{
	
	sumnu = 0.0;
	for(int i=0; i<model->margs->numOfJumps; i++)
		sumnu += model->popJumpHeights[i];
	
	
	
	acpt = (model->margs->aParPopJumpHeight-1.0)*(log(newParPopJumpHeights)-log(model->parPopJumpHeight));
	acpt += (model->margs->bParPopJumpHeight + sumnu)*(model->parPopJumpHeight - newParPopJumpHeights);
	acpt += expIntegralFun(model->parPopJumpHeight*model->popJumpHeights[model->margs->numOfJumps-1]);
	acpt -= expIntegralFun(newParPopJumpHeights*model->popJumpHeights[model->margs->numOfJumps-1]);
	
	if(log(kiss(model->seed))<acpt)
	{
		model->parPopJumpHeight = newParPopJumpHeights;
		model->acptUpdParPopJumpHeights ++;
	}
	}
	
	
}


//sampling
void draw_pointsOnBrain(double* pt, BrainMask* bmask, unsigned long* seed)
{
	for(int i=0; i<DIM; i++)
		pt[i] = kiss(seed)*bmask->dim[i];
	
	while (!inRange(pt, DIM, bmask->brain, bmask->dim)) {
		for(int i=0; i<DIM; i++)
			pt[i] = kiss(seed)*bmask->dim[i];
	}
}


double compute_intensity(double* pt, double** jumpLocations, double* jumpHeights, int numOfJumps,  double theta)
{
	double intensity = 0.0;
	for(int m=0; m<numOfJumps; m++)
	{
		intensity += jumpHeights[m]*kernel(pt, jumpLocations[m], theta);
	}
	
	return intensity;
}


void compute_allIntensities(double*allIntensities, double* pt, double** jumpLocations, double** jumpHeights, 
							double* popJumpHeights, int numOfJumps, int numOfTypes, double* theta)
{
//	double WWW=0;
	double weight = 0,mean_weight=0;
	for(int j=0; j<numOfTypes+1; j++)
	{
		allIntensities[j] = 0.0;
	}
	for(int m=0; m<numOfJumps; m++)
	{
		mean_weight = 0;
		for(int j=0; j<numOfTypes; j++)
		{
			weight = kernel(pt, jumpLocations[m], theta[j]);
//			if ((j==0)  && ((int)pt[0] == 31) && ((int)pt[1] == 41) && ((int)pt[2] == 47))
//				WWW += weight;
//				WWW += jumpHeights[j][m];
			mean_weight += weight;
			allIntensities[j] += jumpHeights[j][m]*weight;
		}
		allIntensities[numOfTypes] += popJumpHeights[m]*mean_weight/numOfTypes;
	}
//	if (((int)pt[0] == 31) && ((int)pt[1] == 41) && ((int)pt[2] == 47))
//		printf("WWW = %lf\n",WWW);
}
/*void compute_allIntensities(double*allIntensities, double* pt, double** jumpLocations, double** jumpHeights, 
							double* popJumpHeights, int numOfJumps, int numOfTypes, double* theta)
{
	
	double weight = 0.0;
	for(int j=0; j<numOfTypes+1; j++)
	{
		allIntensities[j] = 0.0;
	}
	for(int m=0; m<numOfJumps; m++)
	{
		
		for(int j=0; j<numOfTypes; j++)
		{
			weight = kernel(pt, jumpLocations[m], theta[j]);
			allIntensities[j] += jumpHeights[j][m]*weight;
		}
		allIntensities[numOfTypes] += popJumpHeights[m]*weight;
	}
}*/


void compute_subintensity(HGammaRF* model)
{
	double* pt = vec_alloc(DIM);

	for (int a=0; a<model->numOfbsubmask; a++) {
		for(int b=0;b<model->gdat->numOfTypes;b++)
			model->subIntensity[a][b] = 0;
	}
	for(int i=0; i<model->bmask->dim[0]; i++)
	{
		pt[0] = i;
		for(int j=0; j<model->bmask->dim[1]; j++)
		{
			pt[1] = j;
			for(int k=0; k<model->bmask->dim[2]; k++)
			{
				pt[2] = k;
				
				for(int a = 0; a<model->numOfbsubmask; a++)
				{
				if (inRange(pt, DIM, model->bsubmask[a]->brain, model->bsubmask[a]->dim)) {
					
					
					for(int t=0; t<model->gdat->numOfTypes; t++)
					{
						model->subIntensity[a][t]+= model->typeIntensity[t][i][j][k];
					}
				}
				}
			}
		}
	}
	

	free(pt);
	
}

void update_subintensity(HGammaRF* model)
{
	for (int a=0; a<model->numOfbsubmask; a++) {
		for(int t=0; t<model->gdat->numOfTypes; t++)
			model->subIntSum[a][t]+=model->subIntensity[a][t];
	}
	
	for(int t=0; t<model->gdat->numOfTypes; t++)
	{
		for (int s=t; s<model->gdat->numOfTypes; s++) {
				model->subIntCrossProduct0[t][s] += model->subIntensity[0][t]*model->subIntensity[0][s];
				model->subIntCrossProduct1[t][s] += model->subIntensity[1][t]*model->subIntensity[1][s];
				model->subIntCrossProduct01[t][s] += model->subIntensity[0][t]*model->subIntensity[1][s];
			
		}
	}
}


void compute_subintcov(HGammaRF* model)
{
	for(int t=0; t<model->gdat->numOfTypes; t++)
	{
		for (int s=t; s<model->gdat->numOfTypes; s++) {

				model->intensityCov0[t][s] = (model->subIntCrossProduct0[t][s]- model->subIntSum[0][t]*model->subIntSum[0][s]/model->recIntCount)/(model->recDenCount-1.0);
				model->intensityCov1[t][s] = (model->subIntCrossProduct1[t][s]- model->subIntSum[1][t]*model->subIntSum[1][s]/model->recIntCount)/(model->recDenCount-1.0);
				model->intensityCov01[t][s] = (model->subIntCrossProduct01[t][s]- model->subIntSum[0][t]*model->subIntSum[1][s]/model->recIntCount)/(model->recDenCount-1.0);

		}
	}
	for (int t=0; t<model->gdat->numOfTypes; t++) {
		for (int s=t+1; s<model->gdat->numOfTypes; s++) {
			model->intensityCov0[s][t] = model->intensityCov0[t][s];
			model->intensityCov1[s][t] = model->intensityCov1[t][s];
			model->intensityCov01[s][t] = model->intensityCov01[t][s];
		}
	}
}



void update_intensities(HGammaRF* model)
{
	double* pt = vec_alloc(DIM);
	double* allInt = vec_alloc(model->gdat->numOfTypes+1);
	for(int i=0; i<model->bmask->dim[0]; i++)
	{
		pt[0] = i;
		for(int j=0; j<model->bmask->dim[1]; j++)
		{
			pt[1] = j;
			for(int k=0; k<model->bmask->dim[2]; k++)
			{
				pt[2] = k;
				if (inRange(pt, DIM, model->bmask->brain, model->bmask->dim)) {
					
					compute_allIntensities(allInt, pt, model->jumpLocations, model->jumpHeights,
										   model->popJumpHeights, model->margs->numOfJumps,
										   model->gdat->numOfTypes, model->parKernel);
					
					model->popIntensity[i][j][k] = allInt[model->gdat->numOfTypes]/model->parJumpHeight;
										
					for(int t=0; t<model->gdat->numOfTypes; t++)
					{
						model->typeIntensity[t][i][j][k] = allInt[t];
					}
				}				
			}
		}
	}
	
	free(allInt);
	free(pt);
}

void add_intensity(double*** results, double*** intensity, BrainMask* bmask)
{
	double* pt = vec_alloc(DIM);
	for(int a=0; a<bmask->dim[0]; a++)
	{
		pt[0] = a;
		for(int b=0; b<bmask->dim[1]; b++)
		{
			pt[1] = b;
			for(int c=0; c<bmask->dim[2]; c++)
			{
				pt[2] = c;
				if(inRange(pt, DIM, bmask->brain, bmask->dim))
					results[a][b][c]+= intensity[a][b][c];
			}
		}
	}
	free(pt);
}

void add_intensity_sq(double*** results, double*** intensity, BrainMask* bmask)
{
	double* pt = vec_alloc(DIM);
	for(int a=0; a<bmask->dim[0]; a++)
	{
		pt[0] = a;
		for(int b=0; b<bmask->dim[1]; b++)
		{
			pt[1] = b;
			for(int c=0; c<bmask->dim[2]; c++)
			{
				pt[2] = c;
				if(inRange(pt, DIM, bmask->brain, bmask->dim))
					results[a][b][c]+= intensity[a][b][c]*intensity[a][b][c];
			}
		}
	}
	free(pt);
}





void update_sumIntensities(HGammaRF* model)
{
		for(int j=0; j<model->gdat->numOfTypes; j++)
		{
			add_intensity(model->meanTypeIntensity[j],model->typeIntensity[j],model->bmask);
			add_intensity_sq(model->sdTypeIntensity[j], model->typeIntensity[j], model->bmask);
		}
		
		add_intensity(model->meanPopIntensity, model->popIntensity, model->bmask);
		add_intensity_sq(model->sdPopIntensity, model->sdPopIntensity, model->bmask);
	
		model->recIntCount++;		
}


void summary_intensities(HGammaRF* model)
{
	double* pt = vec_alloc(DIM);
	for(int a=0; a<model->bmask->dim[0]; a++)
	{
		pt[0] = a;
		for(int b=0; b<model->bmask->dim[1]; b++)
		{
			pt[1] = b;
			for(int c=0; c<model->bmask->dim[2]; c++)
			{
				pt[2] = c;
				if(inRange(pt, DIM, model->bmask->brain, model->bmask->dim))
				{
					for(int j=0; j<model->gdat->numOfTypes; j++)
					{
						model->meanTypeIntensity[j][a][b][c] /= model->recIntCount;
						model->sdTypeIntensity[j][a][b][c] = sqrt((model->sdTypeIntensity[j][a][b][c]
																   - model->recIntCount*model->meanTypeIntensity[j][a][b][c]*
																   model->meanTypeIntensity[j][a][b][c])/(model->recIntCount-1.0));
						
					}
					
					
					model->meanPopIntensity[a][b][c] /= model->recIntCount;
					model->sdPopIntensity[a][b][c] = sqrt((model->sdPopIntensity[a][b][c]
														   -model->recIntCount*model->meanPopIntensity[a][b][c]
														   *model->meanPopIntensity[a][b][c])/(model->recIntCount-1.0));
				}
				
			}
		}
	}
	free(pt);
	
}


double compute_intMeasure(double* kernelOverBrain, double* jumpHeights, int numOfJumps, int theta)
{
	double intMeasure = 0.0;
	for(int i=0; i<numOfJumps; i++)
	{
		intMeasure += kernelOverBrain[i]*jumpHeights[i];
	}
	
	return intMeasure;
	
}

double compute_logDensity(double** pts, int numOfPts, double** jumpLocations, double* jumpHeights, 
						  int numOfJumps, double theta, double intMeasure)
{
	double logDen = -intMeasure;
	for(int i=0; i<numOfPts; i++)
	{
		logDen += log(compute_intensity(pts[i], jumpLocations, jumpHeights, numOfJumps, theta));
	}
	return logDen;
}


void update_logDensities(HGammaRF* model)
{
	double intMeasure = 0.0;
	for(int i=0; i<model->gdat->numOfGroups; i++)
	{
		for(int j=0; j<model->gdat->numOfTypes; j++)
		{
			intMeasure = compute_intMeasure(model->kernelOverBrain[j], model->jumpHeights[j], model->margs->numOfJumps, model->parKernel[j]);
			model->logDensitiesForData[i][j] = compute_logDensity(model->gdat->dataGroupPoints[i], model->gdat->numOfPoints[i], 
																  model->jumpLocations, 
																  model->jumpHeights[j], model->margs->numOfJumps, model->parKernel[j], 
																  intMeasure);
		}
	}
}

void update_logDensityPred(HGammaRF* model)
{
	double intMeasure = 0.0;
	for(int i=0; i<model->pdat->numOfGroups; i++)
	{
		for(int j=0; j<model->gdat->numOfTypes; j++)
		{
			intMeasure = compute_intMeasure(model->kernelOverBrain[j], model->jumpHeights[j], model->margs->numOfJumps, model->parKernel[j]);
			model->logDensitiesForDataPred[i][j] = compute_logDensity(model->pdat->dataGroupPoints[i], model->pdat->numOfPoints[i], 
																  model->jumpLocations, 
																  model->jumpHeights[j], model->margs->numOfJumps, model->parKernel[j], 
																  intMeasure);
		}
		//vec_print(model->logDensitiesForDataPred[i], model->gdat->numOfTypes, " %4.2lf");
	}
	
	if(model->recDenCountPred==0)
	{
		for(int i=0; i<model->pdat->numOfGroups; i++)
		{
			model->maxDensityPred[i] = -1e100;
			for(int j=0; j<model->gdat->numOfTypes; j++)
			{
				if(model->maxDensityPred[i]<model->logDensitiesForDataPred[i][j])
				{
					model->maxDensityPred[i] = model->logDensitiesForDataPred[i][j]; 
				}
			}
		}
		
	}
}

void update_traceIdx(HGammaRF* model)
{
	int* v = (int*)calloc(model->margs->numOfJumps,sizeof(int));
	double* temp = vec_copy(model->popJumpHeights,model->margs->numOfJumps);
	int idx;
	
	for(int i=0; i<model->margs->numOfJumps; i++){
		v[i] = i;
	}
	
	q_sort(v, temp, 0, model->margs->numOfJumps-1, comp);
	
	
	for (int i=0; i<5; i++) {
		model->traceidx[i] = v[model->margs->numOfJumps-1-i];
	}
	
	
	for (int i=0; i<5; i++) {
		idx = runiform_n(model->margs->numOfJumps-5-i, model->seed);
		model->traceidx[i+5]= v[idx];
		v[idx] = v[model->margs->numOfJumps-6-i];
		
	}
	
	free(v);
	free(temp);

}


void update_densityRatio(HGammaRF* model)
{
	for(int i=0; i<model->gdat->numOfGroups; i++)
	{
		for(int j=0; j<model->gdat->numOfTypes; j++)
		{
			model->densityRatio[i][j] = exp(model->logDensitiesForData[i][j] - model->logDensitiesForData[i][model->gdat->trueTypes[i]]);
		}
	}
}

void update_sumDensityRatio(HGammaRF* model)
{
	for(int i=0; i<model->gdat->numOfGroups; i++)
	{
		for(int j=0; j<model->gdat->numOfTypes; j++)
		{
			model->meanDensityRatio[i][j] += model->densityRatio[i][j];
			model->sdDensityRatio[i][j] += model->densityRatio[i][j]*model->densityRatio[i][j];
		}
	}		
	
	model->recDenCount++;
}



void update_sumDensityPred(HGammaRF* model)
{
	double temp;
	for(int i=0; i<model->pdat->numOfGroups; i++)
	{
		for(int j=0; j<model->gdat->numOfTypes; j++)
		{
			temp = exp(model->logDensitiesForDataPred[i][j] - model->maxDensityPred[i]);
			model->meanDensityPred[i][j] += temp;
			model->sdDensityPred[i][j] += temp*temp;
		}
	}
	model->recDenCountPred++;
	
}


void summary_densityRatio(HGammaRF* model)
{
	for(int i=0; i<model->gdat->numOfGroups; i++)
	{
		for(int j=0; j<model->gdat->numOfTypes; j++)
		{
			model->meanDensityRatio[i][j] /= model->recDenCount;
			model->sdDensityRatio[i][j] = sqrt((model->sdDensityRatio[i][j] 
											   - model->recDenCount*model->meanDensityRatio[i][j]
												*model->meanDensityRatio[i][j])/(model->recDenCount-1.0));
		}
	}
}


void summary_densityPred(HGammaRF* model)
{
	for(int i=0; i<model->pdat->numOfGroups; i++)
	{
		for(int j=0; j<model->gdat->numOfTypes; j++)
		{
			model->meanDensityPred[i][j] /= model->recDenCountPred;
			model->sdDensityPred[i][j] = sqrt((model->sdDensityPred[i][j] 
												- model->recDenCountPred*model->meanDensityPred[i][j]
												*model->meanDensityPred[i][j])/(model->recDenCountPred-1.0));
		}
		vec_print(model->meanDensityPred[i], model->gdat->numOfTypes, "%lg ");
	}
	
	
}


void compute_predProb(HGammaRF* model)
{
	double sumDen = 0.0;
	double maxProb = 0.0;
	for(int i=0; i<model->pdat->numOfGroups; i++)
	{
		sumDen = 0.0;
		for(int j=0; j<model->gdat->numOfTypes; j++)
		{
			sumDen += model->meanDensityPred[i][j];
		}
		
		maxProb = 0.0;
		model->predType[i] = 0;
		for(int j=0; j<model->gdat->numOfTypes; j++)
		{
			model->predProb[i][j] = model->meanDensityPred[i][j]/sumDen;
			if(maxProb<model->predProb[i][j])
			{
				maxProb = model->predProb[i][j];
				model->predType[i] = j;
			}
		}
	}
	
}


void compute_loocvPredProb(HGammaRF* model)
{
	double sumDen = 0.0;
	double maxProb = 0.0;
	for(int i=0; i<model->gdat->numOfGroups; i++)
	{
		sumDen = 0.0;
		for(int j=0; j<model->gdat->numOfTypes; j++)
		{
			sumDen += model->meanDensityRatio[i][j];
		}
		
		maxProb = 0.0;
		model->loocvPredType[i] = 0;
		for(int j=0; j<model->gdat->numOfTypes; j++)
		{
			model->loocvPredProb[i][j] = model->meanDensityRatio[i][j]/sumDen;
			if(maxProb<model->loocvPredProb[i][j])
			{
				maxProb = model->loocvPredProb[i][j];
				model->loocvPredType[i] = j;
			}
		}
	}
}


void update_numOfDistinctPoints(HGammaRF* model)
{
	model->numOfDistinctPoints = 0;
	for(int m=0; m<model->margs->numOfJumps; m++)
	{
		model->numOfDistinctPoints += model->newJumpIndicators[m];
	}
	
}


void trace_pars(HGammaRF* model)
{

	fprintf(model->traceFid, "%d %lg %lg %d ",model->iter,model->parJumpHeight,model->parPopJumpHeight,model->numOfDistinctPoints);	
	
	for(int j=0; j<model->gdat->numOfTypes; j++)
	{
		fprintf(model->traceFid, "%lg ", model->parKernel[j]);
	}
	fprintf(model->traceFid, "\n");
	
	fflush(model->traceFid);
}


void trace_jumps(HGammaRF* model)
{
	int idx;
	for (int i=0; i<10; i++) {
		idx = model->traceidx[i];
		fprintf(model->jumpTraceFid, "%d %d %lf %lf %lf %lf\n", model->iter, model->traceidx[i],
				model->jumpLocations[idx][0],model->jumpLocations[idx][1],model->jumpLocations[idx][2],model->popJumpHeights[idx]);
	}
	fflush(model->jumpTraceFid);
}

void save_loocvPredProb(HGammaRF* model)
{
	char filename[1000];
	
	
	sprintf(filename, "simresults/%s/%s_loocv.prob",model->margs->savename,model->margs->savename);
	FILE* fid = fopen(filename, "wt");
	for(int i=0; i<model->gdat->numOfGroups; i++)
	{
		fprintf(fid,"%d", i+1);
		for(int j=0; j<model->gdat->numOfTypes; j++)
			fprintf(fid," %lg",model->loocvPredProb[i][j]);
		fprintf(fid, "\n");
	}
	fclose(fid);
	
}


void save_predProb(HGammaRF* model)
{
	char filename[1000];
	
	
	sprintf(filename, "simresults/%s/%s_pred.prob",model->margs->savename,model->margs->savename);
	FILE* fid = fopen(filename, "wt");
	for(int i=0; i<model->pdat->numOfGroups; i++)
	{
		fprintf(fid,"%d", i+1);
		for(int j=0; j<model->gdat->numOfTypes; j++)
			fprintf(fid," %lg",model->predProb[i][j]);
		fprintf(fid, "\n");
	}
	fclose(fid);
	
}

void compute_confustionMatrix(HGammaRF* model)
{
	for(int i=0; i<model->gdat->numOfTypes; i++)
		for(int j=0; j<model->gdat->numOfTypes; j++)
			model->confusionMatrix[i][j] = 0;	
	
	for(int i=0; i<model->gdat->numOfGroups;i++)
	{
		model->confusionMatrix[model->gdat->trueTypes[i]][model->loocvPredType[i]]++;
	}
	
	model->overallCrate = 0.0;
	
	for(int i=0; i<model->gdat->numOfTypes; i++)
		model->overallCrate += model->confusionMatrix[i][i];
	
	model->overallCrate /= model->gdat->numOfGroups;
	
	for(int j=0; j<model->gdat->numOfTypes; j++)
	{
		for(int jp=0; jp<model->gdat->numOfTypes; jp++)
		{
			model->confusionMatrix[j][jp]/= model->gdat->numInTypes[j];
		}
	}
	
	model->averageCrate = 0.0;
	for(int i=0; i<model->gdat->numOfTypes; i++)
		model->averageCrate += model->confusionMatrix[i][i];
	
	model->averageCrate /= model->gdat->numOfTypes;
	
}


void compute_confustionMatrixPred(HGammaRF* model)
{
	for(int i=0; i<model->pdat->numOfTypes; i++)
		for(int j=0; j<model->gdat->numOfTypes; j++)
			model->confusionMatrixPred[i][j] = 0;	
	
	for(int i=0; i<model->pdat->numOfGroups;i++)
	{
		model->confusionMatrixPred[model->pdat->trueTypes[i]][model->predType[i]]++;
	}
	

	
	
	model->overallCratePred = 0.0;
	
	if(model->gdat->numOfTypes==model->pdat->numOfTypes)
	{
		for(int i=0; i<model->gdat->numOfTypes; i++)
			model->overallCratePred += model->confusionMatrixPred[i][i];
		model->overallCratePred /= model->pdat->numOfGroups;
	}
	
	
	for(int j=0; j<model->pdat->numOfTypes; j++)
	{
		for(int jp=0; jp<model->gdat->numOfTypes; jp++)
		{
			model->confusionMatrixPred[j][jp]/= model->pdat->numInTypes[j];
		}
	}
	
	
	
	model->averageCratePred = 0.0;
	
	if(model->gdat->numOfTypes==model->pdat->numOfTypes)
	{
		for(int i=0; i<model->gdat->numOfTypes; i++)
			model->averageCratePred += model->confusionMatrixPred[i][i];
		model->averageCratePred /= model->gdat->numOfTypes;
	}
	
}

void save_subintcov(HGammaRF* model)
{
	char filename[1000];
	sprintf(filename,"simresults/%s/%s_subint0.cov",model->margs->savename,model->margs->savename);
	FILE * fid = fopen(filename,"wt");
	
	for(int j=0; j<model->gdat->numOfTypes; j++)
	{
		for(int jp=0; jp<model->gdat->numOfTypes; jp++)
		{
			fprintf(fid,"%lg ", model->intensityCov0[j][jp]);
		}
		fprintf(fid,"\n");
	}		
	fclose(fid);
	
	sprintf(filename,"simresults/%s/%s_subint1.cov",model->margs->savename,model->margs->savename);
	fid = fopen(filename,"wt");
	
	for(int j=0; j<model->gdat->numOfTypes; j++)
	{
		for(int jp=0; jp<model->gdat->numOfTypes; jp++)
		{
			fprintf(fid,"%lg ", model->intensityCov1[j][jp]);
		}
		fprintf(fid,"\n");
	}		
	fclose(fid);

	sprintf(filename,"simresults/%s/%s_subint01.cov",model->margs->savename,model->margs->savename);
	fid = fopen(filename,"wt");
	
	for(int j=0; j<model->gdat->numOfTypes; j++)
	{
		for(int jp=0; jp<model->gdat->numOfTypes; jp++)
		{
			fprintf(fid,"%lg ", model->intensityCov01[j][jp]);
		}
		fprintf(fid,"\n");
	}		
	fclose(fid);
	
	
}	


void save_confusionMatrix(HGammaRF* model)
{
	char filename[1000];
	sprintf(filename,"simresults/%s/%s_loocv.cfmat",model->margs->savename,model->margs->savename);
	FILE * fid = fopen(filename,"wt");
	
	for(int j=0; j<model->gdat->numOfTypes; j++)
	{
		for(int jp=0; jp<model->gdat->numOfTypes; jp++)
		{
			fprintf(fid,"%lg ", model->confusionMatrix[j][jp]);
		}
		fprintf(fid,"\n");
	}		
	fclose(fid);
	
	
	sprintf(filename,"simresults/%s/%s_loocv.crate",model->margs->savename,model->margs->savename);
	fid = fopen(filename,"wt");
	fprintf(fid, "%lg %lg\n",model->overallCrate, model->averageCrate);
	fclose(fid);
}
	

void save_confusionMatrixPred(HGammaRF* model)
{
	char filename[1000];
	sprintf(filename,"simresults/%s/%s_pred.cfmat",model->margs->savename,model->margs->savename);
	FILE * fid = fopen(filename,"wt");
	
	for(int j=0; j<model->pdat->numOfTypes; j++)
	{
		for(int jp=0; jp<model->gdat->numOfTypes; jp++)
		{
			fprintf(fid,"%lg ", model->confusionMatrixPred[j][jp]);
		}
		fprintf(fid,"\n");
	}		
	fclose(fid);
	
	
	sprintf(filename,"simresults/%s/%s_pred.crate",model->margs->savename,model->margs->savename);
	fid = fopen(filename,"wt");
	fprintf(fid, "%lg %lg\n",model->overallCratePred, model->averageCratePred);
	fclose(fid);
}

void save_intensity(HGammaRF* model)
{
	char filename[1000];
	for(int j=0;j<model->gdat->numOfTypes; j++)
	{
		sprintf(filename,"simresults/%s/%s_type_%d_mean.intensity",model->margs->savename,model->margs->savename, j);
		write_vol(filename, model->meanTypeIntensity[j], model->bmask->brain, model->bmask->dim);
		
		sprintf(filename,"simresults/%s/%s_type_%d_sd.intensity",model->margs->savename,model->margs->savename, j);
		write_vol(filename, model->sdTypeIntensity[j], model->bmask->brain, model->bmask->dim);

	}
	sprintf(filename,"simresults/%s/%s_shared_mean.intensity",model->margs->savename,model->margs->savename);
	write_vol(filename, model->meanPopIntensity, model->bmask->brain, model->bmask->dim);

	sprintf(filename,"simresults/%s/%s_shared_sd.intensity",model->margs->savename,model->margs->savename);
	write_vol(filename, model->sdPopIntensity, model->bmask->brain, model->bmask->dim);

}

void write_vol(const char* filename, double*** intensity, MY_DATATYPE*** brain_mask, int* dim)
{
	FILE * fvol;
	fvol = fopen(filename,"wt");
	//double* y = vec_alloc(DIM);
	for(int a=0; a<dim[2]; a++)
	{
		for(int b=0; b<dim[1]; b++)
		{
			for(int c=0; c<dim[0]; c++)
			{
				//y[0] = c;
				//y[1] = b;
				//y[2] = a;
				fprintf(fvol,"%g ", intensity[c][b][a]);
				/* if(inRange(y, DIM, brain_mask, dim))
				 fprintf(fvol, "%g ", intensity[c][b][a]);
				 else {
				 fprintf(fvol, "-99999 ");
				 } */
				
			}
			fprintf(fvol,"\n");
		}
		fprintf(fvol,"\n");
	}
	fclose(fvol);
}


void adjust_acceptance(double accept,double &sgm) 
{
	double y;
	double target = .35;
	
	
	y = 1. + 1000.*(accept-target)*(accept-target)*(accept-target);
	if (y < .9)
		y = .9;
	if (y > 1.1)
		y = 1.1;
	
	sgm *= y;
	
	
}


void save_jumps(HGammaRF* model)
{
	char filename[1000];
	sprintf(filename, "simresults/%s/%s.jumps", model->margs->savename,model->margs->savename);
	FILE* fid = fopen(filename, "wt");
	for (int m=0; m<model->margs->numOfJumps; m++) {
		fprintf(fid, "%lg %lg %lg ", model->jumpLocations[m][0],model->jumpLocations[m][1],model->jumpLocations[m][2]);
		for(int j=0; j<model->gdat->numOfTypes; j++)
		{
			fprintf(fid, "%lg ", model->jumpHeights[j][m]);
		}
		fprintf(fid, "%lg\n",model->popJumpHeights[m]);
	}
	fclose(fid);
}

void show_jumps(HGammaRF* model)
{
	for (int m=0; m<model->margs->numOfJumps; m++) {
		printf("%lg %lg %lg ", model->jumpLocations[m][0],model->jumpLocations[m][1],model->jumpLocations[m][2]);
		for(int j=0; j<model->gdat->numOfTypes; j++)
		{
			printf("%lg ", model->jumpHeights[j][m]);
		}
		printf("%lg\n",model->popJumpHeights[m]);
	}
	
	
}


void posterior_inference(HGammaRF* model)
{

	for(model->iter=1; model->iter <=model->margs->totalIters; model->iter++)
	{
		//printf("update auxiliary points ...\n");
		update_auxiliaryPoints(model);
		//update_auxiliaryPoints_MH(model);
		//printf("update jumpLocations ...\n");
		update_jumpLocations(model);
		//printf("update jump Heights ...\n");
		update_jumpHeights(model);
		//printf("update population jump Heights ...\n");
		update_popJumpHeights(model);
		
		//printf("update kernel parameters ...\n");
		
		update_parKernel_MH(model);
		
		if(model->iter==model->margs->burnin)
		{
			update_traceIdx(model);
		}
		
		
		if(model->iter<=model->margs->burnin && (model->iter)% model->margs->adjustStep == 0)
		{


			
			for(int j=0; j<model->gdat->numOfTypes; j++)
			{
				model->acptUpdParKernel[j] /= model->margs->adjustStep;
				adjust_acceptance(model->acptUpdParKernel[j], model->updSdParKernel[j]);
				//printf("accept rate for theta: %lg, sgm = %lg\n", model->acptUpdParKernel[j], model->updSdParKernel[j]);
				model->acptUpdParKernel[j] = 0.0;
			}

			model->acptUpdParPopJumpHeights /= model->margs->adjustStep;
			adjust_acceptance(model->acptUpdParPopJumpHeights, model->updSdParPopJumpHeights);
			//printf("accept rate for beta: %lg, sgm = %lg\n", model->acptUpdParPopJumpHeights, model->updSdParPopJumpHeights);						
			model->acptUpdParPopJumpHeights = 0.0;						
		}
		
		//printf("update jump height parameters ...\n");
		update_parJumpHeights(model);
		//printf("update population jump height parameters ...\n");
		update_parPopJumpHeights_MH(model);
		//update_parPopJumpHeights(model);

		
		update_numOfDistinctPoints(model);
		
		trace_pars(model);
		
		if(model->iter%5==0)
			printf("%d\n",model->iter);
		fflush(stdout);
		
		//printf("%d\n",model->margs->recStep);
		
		if(model->iter>model->margs->burnin && (model->iter)%model->margs->recStep==0)
		{
			
			//printf("update intensity ...\n");
			update_intensities(model);
			//printf("update sum intensity ...\n");
			update_sumIntensities(model);
			
			//printf("update log intensity ...\n");
			update_logDensities(model);
			
			if(model->margs->predict==1)
			{
				update_logDensityPred(model);
				update_sumDensityPred(model);
			}
			
			
			//printf("update density ratio ...\n");
			update_densityRatio(model);
			
			//printf("update sumDensity ratio ...\n");
			update_sumDensityRatio(model);
			
			compute_subintensity(model);
			update_subintensity(model);
			
			
			//printf("trace jumps ...\n");
			trace_jumps(model);
			
		}
		
		
	}
	
	summary_intensities(model);
	summary_densityRatio(model);
	
	compute_loocvPredProb(model);
	compute_confustionMatrix(model);
	
	compute_subintcov(model);
	
	save_intensity(model);
	save_loocvPredProb(model);
	save_confusionMatrix(model);
	
	save_subintcov(model);
	
	save_jumps(model);
	
	if(model->margs->predict==1)
	{
		summary_densityPred(model);
		compute_predProb(model);
		compute_confustionMatrixPred(model);
		save_predProb(model);
		save_confusionMatrixPred(model);

	}
	
	
}


void run_HGammaRF(int argc, char * const argv[])
{	

	char command[1000];
		
	HGammaRF* model = initial_HGammaRF("brainmask.nii", argv[1], "seed.dat");
	
	
	//printf("Print data ...\n");
	//print_groupData(model->gdat);
	
	sprintf(command, "cp %s simresults/%s/%s.args",argv[1],model->margs->savename,model->margs->savename);
	system(command);
	sprintf(command, "cp seed.dat simresults/%s/%s.seed",model->margs->savename,model->margs->savename);
	system(command);
	
	
	printf("Initializing parameters ... \n");
	initial_values(model);
	


	
	

	printf("Posterior Inference ... \n");
	posterior_inference(model);
	
	
	free_HGammaRF(model);
}




