function Opt = APIG_defaults
% set up default parameters

%
%
% _____________________________________
% Habib Ganjgahi
% Statistic Department, The univeristy of Warwick 
% July/2015


%Set the input data
Opt.in           = 'data.txt';           % text file contains address and name for inputdata
Opt.d            = 'design.csv';         % design matrix
Opt.c            = [];                    % contrast file
Opt.kin          = 'chr_1.grm.gz';        % Kinship matrix
Opt.ped          = 'chr_1.grm.id';    % pedigree file for GRM it should be id file
Opt.subjID       = 'Subjid';

Opt.GWA          = '/storage/strmai/MPRC_GWAS/CEUh/TMP/';                    % Adress for the folder that contains GWAS data 
Opt.GWAid        = 'gwaID';                    % Subjects Id in GWAS 

Opt.Method       = 'GWAS';

Opt.o            = 'MPRC_CEU_All_paperDesENIGMAInorm';      % Output string
Opt.nP           =  5;                 % Number of permutations


Opt.Mask         = [];%'mask2M.nii.gz';                    % Mask for image data

Opt.Permout      =  false;                % Write Permutation distribution
Opt.seed         =  100;                  % Seed for random number generator, in case of Meta analysis  
                                          

Opt.Perm.method  = 'Free';

Opt.v.I          = true;                  % Calculate FWE corrected P-value

Opt.clus         = [];%chi2inv(.99,1);
Opt.con          = 26;

Opt.tfce.I       = false;
Opt.tfce.E       = 2;
Opt.tfce.H       = .5;
Opt.tfce.con     = 26;

Opt.PreProcess  = false;



