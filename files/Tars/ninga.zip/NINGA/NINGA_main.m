function [NINGA,Opt] = NINGA_main
% set up default parameters

%
%
% _____________________________________
% Habib Ganjgahi
% Statistic Department, uni of Oxford 
% Dec/2016
%%
Opt             = NINGA_defaults;

%% read the data
if ~Opt.PreProcess
    [Y,ped,M,C,Opt]             = NINGA_PreProcess(Opt);
else
    [Y,readwith,extra,Opt.Mask] = NINGA_read('Prep_Data.txt',Opt.Mask.filename);
    Opt.Mask.readwith           = readwith;
    Opt.Mask.extra              = extra;
    load('Prep_data')      
end

%% Actual analysis starts here
switch Opt.Method
    case 'MLHer'
        %Call NINGA_Her to run ML heritability analysis
        NINGA          = NINGA_Her(Y,M,ped.phi2,Opt);
    case 'REMLHer'
        %Call NINGA_Her to run REML heritability analysis
        NINGA          = NINGA_Her(Y,M,ped.phi2,Opt);
    case 'Cov'
        %Call CovVec to run covariate inference
        NINGA          = CovVec(Y,M,C,ped.phi2,Opt);
    case 'GWAS'
       i          = str2num(getenv('CHR'));
       j          = str2num(getenv('CHUNK'));
       g          = str2num(getenv('SGE_TASK_ID'));
       Opt.kin    = sprintf('chr_%s.grm',num2str(i));  
       Opt.ped    = sprintf('chr_%s.grm.id',num2str(i)); 
        %load pre-porcessed data, design matrix and kinship
       if ~Opt.PreProcess
           NINGA_PreProcess(Opt)
       end 
        load(fullfile('TMP',sprintf('Misc_%s_%s.mat',num2str(i),num2str(j))));       
        if ~isempty(Opt.Mask)
            Opt.Mask=Mask;
        end
        NINGA     = NINGA_GWA(Y ,M       ,i,j,g,Phi2,Opt);
end

%% calculate cluster FWE P-values and save the outputs
if ~strcmp(Opt.Method,'GWAS')
    %Write the outputs
    NINGA.Y.readwith  = Opt.Mask.readwith;
    NINGA.Y.extra     = Opt.Mask.extra;
    NINGA_write(NINGA,Opt);
    save(Opt.o,'NINGA','-v7.3')
else
    atr = strcat(Opt.o,'_',sprintf('chr_%s_%s_%s.mat',num2str(i),num2str(j),num2str(g)));
    save(atr,'NINGA','-v7.3')
    dlmwrite(atr,NINGA.TS,'\t')
end
end

