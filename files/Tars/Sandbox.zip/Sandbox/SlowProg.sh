#!/bin/bash

nSec=60

for (( i=0; i<nSec ; i++ )) ; do
    echo "tick ($i)."
    sleep 1
done
