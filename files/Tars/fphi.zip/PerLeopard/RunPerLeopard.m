function RunPerLeopard(PathY,PathX,PathPed,PathPhi,BaseName,nP,varargin)
% Main script for fitting eigensimplified polygenic model
% FORMAT RunPerLeopard(PathY,PathX,PathPed,PathPhi,BaseName,nP)
% 
% PathY           - Filepath for a csv file that contains the trait values
% PathX           - Filepath for a csv file that contains the fixed effect 
%                   design matrix
% PathPed         - Filepath for pedgree matrix
% PathPhi         - Filepath for kinship matrix
% BaseName        - Base name for the outputs
% nP              - number of permutations
%
% For image-wise traits, additional parameters required:
% FORMAT RunPerLeopard(PathY,PathX,PathPed,PathPhi,BaseName,Dim,thresh,XYZ)
% Dim             - Image dimension, a length-3 vector.
% thresh          - cluster forming threshold for cluster-wise inference
% XYZ             - 3 by nV matrix that contains voxels coordinates
%__________________________________________________________________________
%
% RunPerLeopard performs heritability estimation and inference in terms of 
% eigensimplified polygenic model.
%
% The trait and covariates are centered and whithened, then squared residuals are
% calculated to construct the auxiliary model for regressing squared residuals
% on the kinship matrix eigenvalues. Explained sum
% of squares is used as a test statistic and P-values are calculated using
% the permutation test. 
% 
% For image-wise traits, image dimension, cluster forming threshold and
% voxels coordinates must be provided. 
%
% The format for the pedigree and kinship files is same as SOLAR but need
% to be converted to CSV format with the "ped2csv" shell script.
%
% Output for univariate traits is 'BaseName.csv' that is saved in the current 
% directory contains heirtability estimation, phenotypic variance estimation 
% and permutation p-value
% 
% Outputs for element-wie imaging traits are :
%              - BaseName_h2.csv: heritability estimation for each element
%              - BaseName_TS.csv: test statistic value for each element                     
%              - BaseName_UncorP.csv: Uncorrected P-value for each element                      
%              - BaseName_MaxV.csv: Maximum statistic to calculate corretced 
%                 FWE P-value for each element.                      
%                                    
%
%
%
%For image-wise traits spatial inferences, maximum statistic and maximum
%cluster size inferences are performed based on given cluster forming
%threshold. 
% The ouptputs for clsuter wise inference are:
%siginificant cluster masks: BaseName_MaskCs.nii, 
%voxel-wise heritability estimates in significant clusters: BaseName_SigCh.nii, 
%test statisitc values in significant clusters: BaseName_SigCTS.nii,
% The outputs for voxel-wise inference are
%significant voxel test statsitics that pass the FWE threshold: BaseName_SigVS.nii,  
%heritability estimation in significant voxels: BaseName_SigVh.nii, 
%    
%voxel-wise Uncorrected P-value image: BaseName_UncorP.nii
%__________________________________________________________________________
% Habib Ganjgahi
% Statistic Department, The univeristy of Warwick 
% December/2014



%%%Read the data and demean it
%for strcsvread provide the delimator and end of line charachters
%Y       = strcsvread(PathY,'\t','\n');
Y       = strcsvread(PathY);
hdrY    = Y(1,:);
% Remove the Id column and header row
data    = cell2mat(Y(2:end,2:end));     
[nS nT] = size(data);
data    = data-repmat(mean(data),[nS 1]); % Demean the data
% 
% 
% 
%Read the design matrix (fixed effects) and demean it
if ~isempty(PathX)
    X0    = strcsvread(PathX);
    X     = cell2mat(X0(2:end,2:end));
    meX   = repmat(mean(X),[nS 1]);
    X     = X-meX;               % demean the covariates
    nC    = size(X,2);
else
    X     = [];
end


%Read the kinship matrix and calculate the eigenvectors and eigenvalues
%the kindhip matrix should be in solar format and concerted to csv files by
%ped2csv script
ped             = loadped(PathPed,PathPhi);  %
[vector,value]  = eig(ped.phi2);                               % EVD
Z               = [ones(nS,1) diag(value)];                    % Design matrix for the auxiliary model

%Whitened the data and design matrix
[sy,sx] = whitened(data,X,vector);

if size(sy,2)==1
   [h2,sigmaP,Pval] = PerLeopardUni(sy,sx,Z,nP);
   csvwrite(strcat(BaseName,'.csv'),[h2,sigmaP,Pval])
else
   Dim    = varargin{1};
   thresh = varargin{2};
   XYZ    = varargin{3};
   if ~isempty(XYZ)
       V.dim = Dim;
       V.mat = eye(4);
       %Voxel to image mapping
       e2 = spm_xyz2e(XYZ,V);
   else
       e2 = [];
   end
   [h2,TS,UncorPval,MaxV,MaxC] = PerLeopardImg(sy,sx,Z,nP,Dim,e2,thresh);
   if ~isempty(MaxC)
       %Write voxel and cluster wise results to nifit files
        WriteImg(TS,h2,UncorPval,BaseName,Dim,thresh,e2,MaxV,MaxC); 
   else
       csvwrite(strcat(BaseName,'_h2.csv'),h2);
       csvwrite(strcat(BaseName,'_TS.csv'),TS);
       csvwrite(strcat(BaseName,'_UncorP.csv'),UncorPval);
       csvwrite(strcat(BaseName,'_MaxV.csv'),MaxV);
   end
end
   
end