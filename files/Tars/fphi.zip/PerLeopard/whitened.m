function varargout = whitened(varargin)
% Return eigensimplified polygenic model
%
% Usage [sy,sx] = whitened(Y,vector,X)
% Y      - correlated trait vector
% X      - the fixed effect design matrix
% vector - eigenvectors of kinship matrix
% 
%
% sy     - whitened data
% sx     - transformed covariates
%__________________________________________________________________________
%
% whitened performs whithening the trait and fixed effext desgin matrix with
% the kinship matrix eigenvalues and returns indepenedt trait and
% covariates. If the covariate isn't provided, then empty matrix for
% transformed covariates is returned.
%__________________________________________________________________________
% Habib Ganjgahi
% Statistic Department, The univeristy of Warwick 
% December/2014

fields = {'Y','X','vector'};
for a = 1:nargin,
    eval(sprintf('%s = varargin{a};',fields{a}))
end
%force the eigenvectors to be rotation matrix 
if det(vector)==-1
    vector(:,[1 2])=vector(:,[2 1])
end

[nS,nT] = size(Y);   % number of subjects and traits

if ~isempty(X)
   sy = vector'*Y;
   sx = vector'*X;
else
    sy = vector'*Y;
    sx = [];
end

% Output results
varargout{1} = sy;            
varargout{2} = sx;     
end