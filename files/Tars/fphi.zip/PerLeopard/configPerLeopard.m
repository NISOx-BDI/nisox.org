%
% This is a configuration file to run univariate and image-wise heritability 
% analysis with the algorithm described in Ganjgahi et al., "Fast and
% Powerful Heritability Inference for Family-Based Neuroimaging Studies",
% in submission.
%
%
% Guideline for creating the necessary csv files
% ---------------------------------------------- 
%
% The pedigree and the kinship matrix should be constructed by SOLAR and 
% converted to csv format with the "ped2csv" bash shell script.
%
% For Univariate traits:
%
%   The trait values and the fixed effect design matrix should be
%   provided in separate csv files.  The first row of each CSV file must
%   have the variable name (for either trait or design matrix), and the
%   first column must have the subject ids (identical for both trait and
%   design matrix CSV files).
%
%   Note that the order of subjects in the data, design matrix and
%   kinship files must be same.
%  
%
% For image-wise traits:
%
%   The image wise traits are saved in CSV file like the univariate traits where 
%   the trait file contains nS (number-of-subjects) by nV
%   (number-of-voxels or -elements) matrix where each column corresponds
%   to a voxels
%   
%   
%   Coordinates of voxels for spatial inferences like cluster-wise should be
%   provided in a 3 by nV matrix that is named XYZ and saved in mat format. 
%     
%
%   The image dimension and cluster forming threshold for cluster wise
%   analysis is configured in the 'Dim' and 'thresh' variables. To perform 
%   Voxel wise inference only set thresh to [].  
%   
%
%   For voxel and cluster wise inference SPM package need to be in the MATLAB path.     
%
%
% To run the analysis below variables should be configured:
% For Univariate and element wise imaging traits:  
%
%   1. PathY, PathX, PathPed and PathPhi are the variables corresponding
%      to filepath for data, fixed effect design matrix, pedigree file
%      and the kinship matrix respectively.   
%
%   2. If there is no covaraite in the analysis, set PathX to [].
%
%   3. Number of Permutations set in the "nP" variable. 
%
%   4. The base name for outputs are specified in the "BaseName" varaible.
%
% For performing corrected FWE spatial inference (voxel or cluster) for
% Image-wise traits additional parameters need to be configured:
%
%   5. Coordinates of voxels for spatial inferences like cluster-wise should be
%   provided in a 3 by nV matrix that is named XYZ and saved in mat format.
%
%   6. The image dimension and cluster forming threshold for cluster wise
%   analysis are configured in the "Dim" and "thresh" variables respectively. To perform 
%   Voxel wise inference only set thresh to [].

% The output for univariate analysis is a CSV file that contains 3
% columns, one each for the heritability estimates, phenotypic variance
% and P-values.
% 
% The outputs for element-wise analysis are 4 CSV files corresponded to 
% the heritability estimation, Test statistic, uncorrected Pvalue and Maximum
% statistic to calculate FWE corrected p-values. Note that the order of elements
% in each file are as same as the trait file.
% 
% The output for image-wise traits spatial inferences is a set of NIFTI files corresponding
% to voxel and cluster wise inference.
%
% See RunPerLeopard for more details.  
%
%
%
% _____________________________________
% Habib Ganjgahi
% Statistic Department. The univeristy of Warwick 
% December/2014


% Initialization:

%Addres for the design matrix and data
PathX   = 'evs.csv'; %or, e.g. 'C:\Users\habib\Documents\MATLAB\PerLeopard\evs.csv'; 

PathY   = 'traits.csv';
PathPed = 'pedindex_138.csv';
PathPhi = 'phi2_138.csv';


BaseName= 'TestOut3';

%Set number of permutations
nP=5000;


% Set below varaibles if Spatial statistic inference like voxel or cluster wise are interested
Dim    = []; %or  e.g Dim = [182 218 182]; 
thresh = []; %or, e.g thresh = 0.01;
XYZ    = []; %or, e.g load('XYZ.mat')


RunPerLeopard(PathY,PathX,PathPed,PathPhi,BaseName,nP,Dim,thresh,XYZ);

