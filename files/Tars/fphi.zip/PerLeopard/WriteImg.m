function WriteImg(varargin)
% Write image-wise results to nii file
%
% Usage WriteImg(TS,h2,Dim,thresh,e2,MaxV,MaxC);
% Inputs:
% TS         - Statistic Image.
% h2         - heritability Image
% Dim        - image dimension.
% thresh     - Cluster forming threshold based on p-value, like P=0.05 or 0.01.
% e2         - voxel coordinates in image space . 
% MaxV       - Maximum statistic critical value.
% MaxV       - Maximum cluster size critical value.
% 
%
%
% Outputs:
% MaskCs.nii - Mask of siginificant clusters
% SigCh.nii  - heritabilty estimation in significant clusters
% SigCTS.nii - Test statistic value in significant clusters
% SigVS.nii  - voxels that passed the voxel-wise inference threshold
% SigVh.nii  - heritability estimation in significant voxels
%
%__________________________________________________________________________
% this function uses spm functions to write cluster and voxel wise results
% to nifti files. 
% 
%_______________________________________________________________
% Habib Ganjgahi
% Statistic Department, The univeristy of Warwick 
% December/2014




fields = {'TS','h2','UncorPval','BaseName','Dim','thresh','e2','MaxV','MaxC'};
for a = 1:nargin,
eval(sprintf('%s = varargin{a};',fields{a}))
end


TsImg=zeros(Dim);
TsImg(e2)=TS;
%Cluster forming threshold
chi   = 2*((1-thresh)-.5);
th    = chi2inv(chi,1);
%Find clusters 
b     = double(TsImg>th); 
[c,v] = spm_bwlabel(b,18);
%Find significant clusters
k=0;
for l=1:v
    cls=length(find(c==l));
    if cls<MaxC  
        c(c==l)=0;
    else
        k=k+1;
        c(c==l)=k;
    end
end
%Write the binary mask of significant clusters
V.dt=[spm_type('float32') spm_platform('bigend')];
V.mat = [1 0 0 -91; 0 1 0 -172; 0 0 1 -73; 0 0 0 1];
V.pinfo = [1 0 0 ]';
V.n = 1;
V.fname=strcat(BaseName,'_MaskCs.nii');
spm_write_vol(V,c);

c(c>0)=1;

TsImg(e2)=h2; SigCh=c.*TsImg;
V.fname=strcat(BaseName,'_SigCh.nii');
spm_write_vol(V,SigCh);


TsImg(e2)=TS; SigCTS=c.*TsImg;
V.fname=strcat(BaseName,'_SigCTS.nii');
spm_write_vol(V,SigCTS);
%write voxel-wise reults
TsImg(e2)=TS(TS>MaxV);
V.fname=strcat(BaseName,'_SigVS.nii');
spm_write_vol(V,TsImg);


TsImg(e2)=h2(TS>MaxV);
V.fname=strcat(BaseName,'_SigVh.nii');
spm_write_vol(V,TsImg);

TsImg(e2)=UncorPval;
V.fname=strcat(BaseName,'_UncorP.nii');
spm_write_vol(V,TsImg);
end