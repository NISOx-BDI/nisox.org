function varargout=max_clsf(varargin)
% Returns maximum statistic and maximum cluster size for a given cluster
% forming threshold
%
% Usage [max_s,MaxClVox,ClSize] = max_clsf(TS,e,Dim,thresh);
% TS      - Test statistic image
% e       - voxel indixies in image space
% Dim     - statistic image dimension
% thresh  - Cluster forming threshold in terms of P-value like P=0.01
%
% Outputs
% max_s     - Maximum statistic
% MaxClVox  - Maximum cluster size for a given cluster forming threshold
% ClSize    - cluster size distribution for a given threshold
%__________________________________________________________________________
%
% max_clsf find maximum statistic value in the statistic image. Also it
% finds clusters, their sizes and returns maximum cluster size for the
% given cluster forming threshold.
% 
%__________________________________________________________________________
% Habib Ganjgahi
% Statistic Department, The univeristy of Warwick 
% December/2014


fields = {'TS','e','dim','p_value'};
for a = 1:nargin,
    eval(sprintf('%s = varargin{a};',fields{a}))
end

if ~isempty(p_value)
    
    TsImg    = zeros(dim);
    TsImg(e) = TS;

    % calculate cluster froming threshold based on 50:50 chi mixture
    chi=2*((1-p_value)-.5);
    tth=chi2inv(chi,1);
  
    perm_max_clus_size = zeros(1,length(p_value));
    clus_size          = cell(length(p_value),1);


    %%%finding the maximum cluster size for each permutation 
    for k=1:length(p_value)
        th=tth(k);  
        vol      = double(TsImg>th);
        [c,num]  = spm_bwlabel(vol,18);
        if ~isempty(num)
            ClusSize    = histc(c(:),(0:num) + 0.5);
            ClSize{k}   = ClusSize(1:end-1);
            MaxClVox(k) = max(ClSize{k});
        else
            MaxClVox(k) = 0;
            ClSize{k}   = 0;
        end
    end
else
    %if there is no spatial inference (cluster wise) the cluster size and
    %maximum cluster size is set to an empty varaibales
   ClSize = [];
   max_s  = [];
end
%%%finding the maximum statistics for each permutation 
max_s        = max(TS);

varargout{1} = max_s;
varargout{2} = MaxClVox;
varargout{3} = ClSize;
end

