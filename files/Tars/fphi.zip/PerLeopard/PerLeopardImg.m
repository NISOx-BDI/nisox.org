function varargout=PerLeopardImg(varargin)
% Fit voxel-wise eigensimplified polygenic model and return corrected FWE P-values, 
%
% Usage [h2,TS,MaxV,MaxC] = PerLeopardImg(sy,Z,nP,Dim,e2,thresh,sx);
% Inputs:
% sy         - whitened data.
% Z          - design matrix for the auxiliary model.
% sx         - transformed fixed effect design matrix.
% nP         - number of permutations. 
% Dim        - image dimension.
% e2         - coordinates in image space.
% thresh     - cluster forming threshold.
%
%
% Outputs:
% h2         - WLS heritabilty estimation image.
% TS         - Unpermuted test statistic image.
% MaxV       - Maximum statistic null distribution.
% MaxC       - Maximum cluster size null distribution.
% UncorPval  - Permutation based uncorrected P-value
%
%__________________________________________________________________________
%
% PerLeopardImg performs voxel-wise heritability estimation and hypothesis testing in terms 
% of constructing an auxiliary model that squared residuals regressed on the kinship matrix eigenvalues.
% 
% Heritability is estimated in terms of WLS estimator and for the infrence
% the permutation test is employed. 
%
% if covariates are provided then ols residulas are squared otherwise, demeaned trait is squared.
% 
% In each permutation, maximum statisitc (MaxV) and cluster size (MaxC) are captured to
% construct their empirical null distribution and calculate thier critical values.
% _________________________________________________________________________
% Habib Ganjgahi
% Statistic Department, The univeristy of Warwick 
% December/2014

fields = {'sy','sx','Z','nP','Dim','e','thresh'};
for a = 1:nargin,
   eval(sprintf('%s = varargin{a};',fields{a}))
end

if isempty(sx)
   %check if design matrix is provided
    res      = sy;
    [nS,nV]  = size(res);
    cov      = 0;
else
    [nS,nV]  = size(sy);
    hat      = eye(nS)-sx*inv(sx'*sx)*sx';  
    beta     = sx\sy;
    cov      = sx*beta;
    res      = hat*sy;
end


MaxVS   = zeros(nP+1,1);
MaxClsS = zeros(nP+1,1);

%Calculate the score test in terms of BP expression
%tic
[TS,h2Img]                = heterV(res,Z,1);
[MaxVS(1),MaxClsS(1,:)]   = max_clsf(TS,e,Dim,thresh);
%Indicator variable to calculate uncorrected P-value
IdS  = zeros(size(TS));
for p=1:nP
    fprintf('(Permutation %g) ',p)
    % Create permutation matrix for whole image
    [~,Pvec]    = sort(rand(nS,1)); % CMC
    syP         = res(Pvec,:)+cov;
    resP        = hat*syP;
    TSp         = heterV(resP,Z);
    %Indicator varaible to calculate uncorrected P-value
    IdS         = IdS+double(TSp>=TS);
    %capture maximum statistic and cluster size in each permutation, if
    %there is no cluster forming threshld, then MaxClsS will be an empty matrix 
    [MaxVS(p+1),MaxClsS(p+1,:)] = max_clsf(TSp,e,Dim,thresh);

  
end

%Calculate Uncorretcted P-value
UncorPval = (IdS+1)./(nP+1);
%Calculate Maximum statistic and maximum cluster size ciritical value

thr   = ceil((nP+1)*.95);
asdVS = sort(MaxVS);
thrVS = asdVS(thr);
if ~isempty(thresh)
    asdS  = sort(MaxClsS,1);
    thrCS = asdS(thr,:);
else
    thrCS = [];
end

varargout{1} = h2Img;
varargout{2} = TS;
varargout{3} = UncorPval;
varargout{4} = thrVS;
varargout{5} = thrCS;
end
