function varargout=PerLeopardUni(varargin)
% Return eigensimplified polygenic model parameter estimation, 
%
% Usage [h2,sigmaP,Pval] = PerLeopardUni(sy,sx,Z,nP);
%
% sy         - whitened data
% sx         - transformed fixed effect design matrix
% Z          - design matrix for the auxiliary model
% nP         - number of permutations 
%
% h2         - WLS heritabilty estimation
% sigmaP     - phenotypic variance estimation
% Pval       - permutation P-value 
%__________________________________________________________________________
%
% PerLeopardUni performs heritability estimation and hypothesis testing for univariate traits in terms 
% of constructing an auxiliary model that squared residuals regressed on the kinship matrix eigenvalues.
% Heritability is estimated in terms of WLS estimator and for the infrence
% the permutation test is employed. 
% if covariates are provided then ols residulas are squared otherwise, demeaned trait is squared.
% 
%__________________________________________________________________________
% Habib Ganjgahi
% Statistic Department, The univeristy of Warwick 
% December/2014

fields = {'sy','sx','Z','nP'};
for a = 1:nargin,
eval(sprintf('%s = varargin{a};',fields{a}))
end
if isempty(sx)
    res  = sy;
    nS       = size(res,1);
    syP      = zeros(nS,nP+1);
    syP(:,1) = res;
    for p=2:nP
        [~,Pvec] = sort(rand(nS,1));
        syP(:,p)=res(Pvec);
    end
    resi    = syP;
    value   = diag(Z(:,2));
    [p_wahh,sigma_wls]=heterR(sy,value,'wls');
else
    nS       = size(sy,1);
    hat      = eye(nS)-sx*inv(sx'*sx)*sx';  
    beta     = sx\sy;
    cov      = sx*beta;
    res      = hat*sy;
    syP      = zeros(nS,nP+1);
    syP(:,1) = res;
    for p=2:nP
        [~,Pvec] = sort(rand(nS,1));
        syP(:,p)=res(Pvec)+cov;
    end
    resi    = hat*syP;
    value   = diag(Z(:,2));
    [p_wahh,sigma_wls]=heterR(sy,sx,value,1,'wls'); 
end

TS     = heterV(resi,Z);
Pval   = mean(TS>=TS(1));
SigmaP = p_wahh+sigma_wls;
h2     = p_wahh/SigmaP;


varargout{1} = h2;
varargout{2} = SigmaP;
varargout{3} = Pval;
end
