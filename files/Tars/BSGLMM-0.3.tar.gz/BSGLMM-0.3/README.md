BSGLMM
======

Bayesian Spatial Generalised Linear Mixed Model

Please see http://warwick.ac.uk/tenichols/BSGLMM
