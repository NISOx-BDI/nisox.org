/*
 *  Testing.h
 *  WeightCox
 *
 *  Created by Jian Kang on 1/16/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

void test_simulation1(int in_total_iters, int in_adj_acpt, 
					  int in_burn_in, int in_rec_lambda,
					  int in_n,  int in_m,  double in_xi,
					  double in_xi_tau, double in_xi_sgm, 
					  double in_rho, double in_tau_rho, 
					  double in_eta, 
					  double in_tau_theta, double in_tau_eps,
					  double in_sgm1, double in_sgm0,
					  int in_df_S, int in_df_S0, 
					  int in_df_T, int in_df_T0,
					  double in_var_Sigma, double in_var_S0, double in_radius,
					  const char* datafile, 
					  const char* savename)
{
	unsigned long * seed = initial_seed("seed.dat");
	double *in_V = vec_alloc(2);
	double **S = mat_alloc(DIM);
	char x_file[100];
	char x_file1[100];
	char sigma_file[100];
	char num_file[100];
	char par_file[100];
	char intense_file[100];
	char setting_file[100];
	char vol_intensity[100];
	char contrast[100];
	char study[100];
	char Zpoints[100];
	char Znum[100];
	
	strcpy(Znum, savename);
	strcat(Znum, "_Znum.txt");
	
	strcpy(Zpoints, savename);
	strcat(Zpoints,"_Zpoints.txt");
	
	strcpy(contrast,savename);
	strcat(contrast,"_contrast.txt");
	
	strcpy(study, savename);
	strcat(study,"_study.txt");
	
	strcpy(vol_intensity, savename);
	strcat(vol_intensity, "_vol.txt");
	
	
	strcpy(intense_file, savename);
	strcat(intense_file, "_intensity");
	
	
	strcpy(x_file, savename);
	strcat(x_file, "_x.txt");
	
	strcpy(x_file1, savename);
	strcat(x_file1, "_x1.txt");
	
	strcpy(sigma_file, savename);
	strcat(sigma_file, "_sigma.txt");
	
	strcpy(num_file, savename);
	strcat(num_file, "_num.txt");
	
	strcpy(par_file, savename);
	strcat(par_file, "_results.txt");
	
	strcpy(setting_file, savename);
	strcat(setting_file, "_setting.txt");	
	
	
	FILE* fx = fopen(x_file, "wt");
	FILE* fx1 = fopen(x_file1,"wt");
	FILE* fsigma = fopen(sigma_file,"wt");
	FILE* fnum = fopen(num_file,"wt");
	FILE* fpar = fopen(par_file, "wt");
	FILE* fcontrast = fopen(contrast,"wt");
	FILE* fstudy = fopen(study,"wt");
	FILE* fZ = fopen(Zpoints, "wt");
	FILE* fZnum = fopen(Znum, "wt");
	
	fprintf(fpar,"iteration Birth/Death numOfCluster    m    theta           eps    rho    totalBirthRate                 totalDeathRate			acceptRatio\n");
	
	FILE *fid = fopen(setting_file, "wt");
	
	in_V[0] = 1;
	in_V[1] = 0.75;
	
	
	
	points pp = initial_points();
	//read_matlab_mask("matlab_mask.txt", pp);
	
	read_mask("brainmask.nii", pp);
	read_amygdala(pp);
	read_points1(datafile,pp);
	
	
	/*pars initial_pars1(int in_total_iters,int in_adj_acpt,  int in_burn_in,  int in_rec_lambda,
	 double* in_V, int in_V_n, 
	 int in_n,  int in_m,  
	 double in_eta, double in_tau_theta, double in_tau_eps,
	 double in_sgm0, double in_sgm1,
	 int in_df_S, int in_df_T, double in_var_Sigma, 
	 double in_vol)*/
	
	//pp.m = 300;
	
	if (in_m==-1)
		in_m=pp.m1;
	
	pars p = initial_pars1(in_total_iters,in_adj_acpt,in_burn_in, in_rec_lambda, in_V, 2,
						   in_n, in_m, in_xi, in_xi_tau, in_xi_sgm,
						   in_rho, in_tau_rho, 
						   in_eta, in_tau_theta,in_tau_eps,
						   in_sgm0, in_sgm1,
						   in_df_S, in_df_S0, 
						   in_df_T, in_df_T0,
						   in_var_Sigma, in_var_S0, in_radius,
						   pp.vol);
	
	p.xi_all_alpha = vec_alloc(pp.n_contrast);
	
	// initial xi
	for(int i=0; i<pp.n_contrast; i++)
	{
		p.xi_all_alpha[i] = p.xi_alpha;
		pp.xi[i] = p.xi;
		pp.rho_all[i] = p.rho;
	}
	
	p.xi_all_alpha[pp.n_contrast] = 0.5*pp.n_contrast*p.xi_alpha;
	
	save_pars(fid, p, pp);
	fclose(fid);
	
	//fprintf(p.temp_fid, "Iteration Birth/Death TotalClusterNum ClusterNum logDeathRatePart1 logDeathRatePart2 logDeathRatePart3     logDeathRate              DeathRate\n");
	
	
	
	printf("m = %d\n", pp.m1);
	
	double *tp = vec_alloc(pp.m1);
	double *Z_tp = vec_alloc(pp.m1);
	int idx = 0;
	
	
	for(int i=0; i<p.total_iters; i++)
	{
		
		p.iters = i;
		printf("--------%d\n",i);
		
		
		
		Z_approx_tprob(Z_tp, pp,p,seed,SIMUL);
		
		Z_spatial_birth_death(Z_tp, pp,p,10,seed);
		
		
		/*printf("Lambda[0][0]: \n");
		 mat_print(pp.Lambda[0][0], DIM, " %.4f");
		 
		 printf("Z_S0: \n");
		 mat_print(p.S0, DIM, " %.4f");*/
		
		
		
		Z_move_step(pp, p, seed);
		
		
		
		
		
		/*printf("Z[0][0]: \n");
		 vec_print(pp.matZ[0][0], DIM, " %.4f");
		 printf("Lambda[0][0]: \n");
		 mat_print(pp.Lambda[0][0], DIM, " %.4f");*/
		
		
		//for(int kj=0; kj<100; kj++)
		//{
		//	vec_print(pp.Y[kj],DIM, " %4.2f");
		//}
		approx_tprob(tp, pp, p, seed, SIMUL);
		spatial_birth_death(tp,pp,p,10,seed);
		
		
		
		
		/*printf("Birth_rate = %lf\n", p.totalBirthRate);
		 printf("Death_rate = %.20lf\n", p.totalDeathRate);
		 
		 printf("beta = %lf\n", p.beta);
		 printf("mu (m) = %lf (%d)\n ", p.mu, pp.m);
		 printf("theta = %lf\n",p.theta);
		 printf("accept_theta = %lf \n", p.acpt1);
		 printf("sigma for theta = %lf\n", p.sgm1);
		 printf("eps = %lf\n",p.eps);
		 printf("accept_eps = %lf\n", p.acpt0);
		 printf("sigma for eps = %lf\n",p.sgm0);*/
		
		rec_pars(fpar, p, pp);
		rec_Z(fZ,pp,p);
		rec_numZ(fZnum, pp, p);
		move_step(pp,p,seed);
		
		update_kappa(pp, p, seed);
		//cut_centers(p, 5);
		
		
		
		//printf("n = %d\n", p.n);
		
		update_S(p, seed);
		update_beta(p, pp, seed);
		
		printf("beta = %.10f\n",p.beta);
		
		printf("phi = \n");
		vec_print(p.phi, p.V_n,"%.4lf ");
		
		//printf("rho = ");
		for(int i=0; i<5; i++)
			printf("%.4f ", pp.rho_all[i]);
		printf("\n");
		
		if(p.iters>p.burn_in && p.iters*1.0/p.rec_lambda == p.iters/p.rec_lambda)
		{
			rec_intensity(pp, p);
			rec_centers(fx, p,idx);
			rec_centers1(fx1,p);
			rec_id_study(fstudy, pp, p);
			rec_id_contrast(fcontrast, pp, p);
			rec_Sigma(fsigma, p);
			rec_num(fnum,p);
			printf("Writing intensity functions ...");
			write_vol(vol_intensity, pp, p);
			
		}
		
		printf("N0 = %d\n", p.N0);
		for(int k=0; k<p.n; k++)
		{
			//printf("Cluster %d has %d points, %d studies, %d constrasts \n", k,
			//	   p.Num[k],p.studyNum[k],p.contrastNum[k]);
			printf("Cluster %d has %d points\n", k,
				   p.Num[k]);
		}
		
		
		if (p.n>0)
		{
			printf("X[0] = \n");
			vec_print(p.X[0], DIM, "% .4f");
			printf("Sigma[0] = \n");
			mat_print(p.Sigma[0], DIM, "% .4f");
		}
		
		
		printf("xi: ");
		for(int i=0; i<5; i++)
		{
			printf("%lf ", pp.xi[i]);
		}
		printf("\n");
		
	}
	
	//printf("Writing the Z points...\n");
	
	
	printf("n = %d\n",p.n);
	printf("Writing intensity functions ...");
	write_margin(intense_file, pp, p);
	printf("Finished! \n");
	//save_seed(seed,"seed.dat");
	free(seed);
	mat_free(S,DIM);
	free(tp);
	free(Z_tp);
	free(in_V);
	free(p.xi_all_alpha);
	
	
	free_pars(p);
	free_points(pp);
	
	fclose(fx);
	fclose(fx1);
	fclose(fpar);
	fclose(fsigma);
	fclose(fnum);
	fclose(fstudy);
	fclose(fcontrast);
	fclose(fZ);
	fclose(fZnum);
}

void test_eigen()
{
	double **S = mat_alloc(DIM);
	S[0][0] = 100.0; S[0][1] = 0.4; S[0][2] = 0.5;
	S[1][0] = 0.4; S[1][1] = 2.0; S[1][2] = 0.9;
	S[2][0] = 0.5; S[2][1] = 0.9; S[2][2] = 3.0;
	
	double* eigen_vector = vec_alloc(DIM*DIM);
	double* eigen_value = vec_alloc(DIM);
	
	
	
	eigen(eigen_vector, eigen_value, S);
	
	
	eigen_print(eigen_vector, eigen_value);
	
	free(eigen_vector);
	free(eigen_value);
	
	mat_free(S, DIM);
}

void test_tprob()
{
	unsigned long * seed = initial_seed("seed.dat");
	double *in_V = vec_alloc(2);
	double **S = mat_alloc(DIM);
	Timer t;
	
	in_V[0] = 1;
	in_V[1] = 0.75;
	points pp = initial_points();
	read_matlab_mask("matlab_mask.txt", pp);
	read_points("points.txt",pp);
	pars p = initial_pars1(50000,100,1000, 20, in_V, 2,
						   30, pp.m, 0.01,0.1,0.0003,1,1,
						   0.25, 0.2,0.2,
						   -1, -1,
						   5, 5,5,5, 4,2, 10,
						   pp.vol);
	
	S[0][0] = 10;
	S[1][1] = S[0][0];
	S[2][2] = S[1][1];
	
	rinverse_wishart(p.S, S, p.df_S, seed);
	
	
	double* tp = vec_alloc(pp.m);
	double* tp1 = vec_alloc(pp.m);
	t.restart();
	ttprob(tp, pp, p, seed, SIMUL);
	printf("time for old one: %lf\n", t.elapsed());
	t.restart();
	approx_tprob(tp1, pp, p, seed, SIMUL);
	printf("time for new one: %lf\n", t.elapsed());
	
	double temp = 0;
	int k = 0;
	for(int i=0; i<pp.m; i++)
	{
		if(tp1[i]>=0.99)
		{
			printf("%d: %.4f %.4f\n",i, tp[i], tp1[i]);
			temp += tp[i];
			k++;
		}
	}
	temp /= k;
	printf("mean tp (k) = %lf (%d)\n", temp, k);
	
	free(tp);
	free(tp1);
	free(in_V);
	mat_free(S,DIM);
}


void test_rand()
{
	unsigned long* seed = initial_seed("seed.dat");
	double **S = mat_alloc(DIM);
	double **X = mat_alloc(DIM);
	double **Y = mat_alloc(DIM);
	int N = 10000;
	int v = 10;
	
	//test random number inverse wishart
	S[0][0] = 1.0; S[0][1] = 0.4; S[0][2] = 0.5;
	S[1][0] = 0.4; S[1][1] = 2.0; S[1][2] = 0.9;
	S[2][0] = 0.5; S[2][1] = 0.9; S[2][2] = 3.0;
	
	for(int i=0; i<N; i++)
	{
		rinverse_wishart(X, S, v, seed);
		mat_plus(Y, X, Y, DIM);
		printf("----%d----\n", i);
		mat_print(X, DIM, "%.4f ");
	}
	mat_times_k(Y, DIM, 1.0/N);
	
	printf("--------\n Y = \n");
	mat_print(Y, DIM, "%.4f ");
	mat_times_k(S,DIM, 1.0/(v-DIM-1));
	printf("--------\n S/(v-dim-1) = \n");
	mat_print(S, DIM, "%.4f ");
	
	mat_free(S,DIM);
	mat_free(X,DIM);
	mat_free(Y, DIM);
}

void test_invwishart()
{
	double **S = mat_alloc(DIM);
	double **W = mat_alloc(DIM);
	int v = 6;
	
	//test random number inverse wishart
	S[0][0] = 4.0; S[0][1] = 2.0; S[0][2] = 1.0;
	S[1][0] = 2.0; S[1][1] = 3.0; S[1][2] = 0.5;
	S[2][0] = 1.0; S[2][1] = 0.5; S[2][2] = 5.0;
	
	mat_copyval(W, S, DIM);
	
	S[0][0] = 1.0; S[0][1] = 0.5; S[0][2] = 0.5;
	S[1][0] = 0.5; S[1][1] = 1.0; S[1][2] = 0.5;
	S[2][0] = 0.5; S[2][1] = 0.5; S[2][2] = 1.0;
	
	
	
	double d = dinvWishart(W, S, DIM, v);
	
	printf("The density is %.20lf\n", d);
	
	
	mat_free(S,DIM);
	mat_free(W,DIM);
}

int write_mask(const char* filename, MY_DATATYPE*** mask, int* dim)
{
	FILE* fvol = fopen(filename, "wt");
	int t = 0;
	fprintf(fvol,"%d %d %d\n", dim[0], dim[1], dim[2]);
	for(int i=0; i<dim[0]; i++)
		for(int j=0; j<dim[1]; j++)
			for(int k=0; k<dim[2]; k++)
				if(mask[i][j][k]>0.0)
				{
					fprintf(fvol, "%d %d %d\n", i, j, k);
					t++;
				}
	fclose(fvol);
	printf("total number masked: %d\n", t);
	return 1;
}

void test_dmvnorm()
{
	int N = 20;
	double* x = vec_alloc(N);
	double* y = vec_alloc(N);
	double* z = vec_alloc(N);
	double* ps = vec_alloc(DIM);
	double* f = vec_alloc(N);
	double* mu = vec_alloc(DIM);
	double temp;
	int MM = 1000;
	Timer t;
	
	mu[0] = 1;
	mu[1] = 12;
	mu[2] = 2;
	
	double** Sigma = mat_alloc(DIM);
	double** SigmaInv = mat_alloc(DIM);

	Sigma[0][0] = 1; Sigma[0][1] = 2; Sigma[0][2] = 0;
	Sigma[1][0] = 2; Sigma[1][1] = 5; Sigma[1][2] = 0.5;
	Sigma[2][0] = 0; Sigma[2][1] = 0.5; Sigma[2][2] = 3;
	
    	mat_inverse(SigmaInv, Sigma, DIM);
	
	x[0] = -2;
	y[0] = 2*x[0]+10;
	z[0] = x[0]+cos(y[0]);
	for(int i = 1; i<N; i++)
	{
		x[i] = x[i-1] +0.3;
		y[i] = 2*x[i] + 10;
		z[i] = x[i] + cos(y[i]);
	}
	
	
	t.restart();
	for(int k = 0; k<MM; k++)
	{
	for(int i=0; i<N; i++)
	{
		ps[0] = x[i];
		ps[1] = y[i];
		ps[2] = z[i];
		
		//dmvnorm(pp.Y[j], Sigma, DIM, p.X[i])
		temp = dmvnorm(ps,Sigma, DIM, mu);
		
		//printf("%30.20lf  %30.20lf\n",f[i],temp);
	}
		printf("Current %d\n", k);
	}
	double t1 = t.elapsed();
	
	t.restart();
	for(int k = 0; k<MM; k++)
	{
		for(int i=0; i<N; i++)
		{
			ps[0] = x[i];
			ps[1] = y[i];
			ps[2] = z[i];
			
			//dmvnorm(pp.Y[j], Sigma, DIM, p.X[i])
			temp = dmvnorm1(ps,SigmaInv, DIM, mu);
			
		//printf("%30.20lf  %30.20lf\n",f[i],temp);
		}
		printf("Inverse %d\n", k);
	}
	double t0 = t.elapsed();
	
	
	
	printf("Time cost for Inverse code is %lf\n", t0);
	printf("Time cost for Current code is %lf\n", t1);
	
	
	free(ps);
	free(x);
	free(y);
	free(z);
	free(f);
	free(mu);
	mat_free(Sigma, DIM);
	mat_free(SigmaInv, DIM);
					   
}

void test_mat()
{
	double** mat1 = mat_alloc(DIM);
	double* vec = vec_alloc(DIM);
	double* vec1 = vec_alloc(DIM);
	
	for(int i=0; i<DIM; i++)
		for(int j=0; j<DIM; j++)
			mat1[i][j] = i+j+1;
	
	for(int i=0; i<DIM; i++)
		vec1[i] = i+1;
	
	vec_print(vec1, DIM, " %.4f");
	mat_print(mat1, DIM, " %.4f");
	
	mat_times_vec(vec, mat1, vec1, DIM);
	
	vec_print(vec,DIM, " %.4f");
	
	free(vec);
	free(vec1);
	free(mat1);
}




void test_pmvnorm()
{
	double* X = vec_alloc(DIM);
	double** Sigma = mat_alloc(DIM);
	double*p = vec_alloc(100);
	double mean = 0;
	
	X[0] = 5;
	X[1] = 44;
	X[2] = 34;
	
	for(int i=0; i<DIM; i++)
		for(int j=0; j<DIM; j++)
			Sigma[i][j] = 0.5;
	
	Sigma[0][0] = 0.8;
	Sigma[1][1] = 1.0;
	Sigma[2][2] = 1.2;
	
	points pp = initial_points();
	unsigned long* seed = initial_seed("seed.dat");
	read_matlab_mask("matlab_mask.txt", pp);
	
	for(int i=0; i<100; i++)
	{
		p[i] = pmvnorm(pp.mask, pp.dim, Sigma, DIM, X, 5000, seed);
		mean += p[i];
		printf("%d %lf\n",i, p[i]);
	}
	
	printf("mean %lf\n",  mean/100);
	
	free(X);
	free(p);
	mat_free(Sigma,DIM);
	free_points(pp);
	free(seed);
}


void sim_data0(points &pp, pars &p, unsigned long* seed)
{
	//Simulating X and Sigma
	p.n = 0;
	
	printf("n = %d\n", p.n);
	printf("Simulating X\n");
	mat_print(p.S, DIM, "%.4f ");
	
	
	
	
		
	//Simulating Points
	
	p.mu = p.eps*pp.vol;
	printf("mu = %lf\n", p.mu);
	pp.m = rpois(p.mu, seed);
	pp.W = vec_alloc(pp.m);
	pp.W_id = (int*)calloc(pp.m, sizeof(int));
	pp.Y = vec_list_alloc(DIM, pp.m);
	
	printf("m = %d\n", pp.m);
	printf("Simulating Points ...\n");
	
	for(int j=0; j<pp.m; j++)
	{			
		printf("j = %d\n", j);
		//Simulating weighting
		pp.W_id[j] = rmultinomial(p.phi, p.V_n, seed);
		pp.W[j] = p.V[pp.W_id[j]];
		
		for(int k=0; k<DIM; k++)
			pp.Y[j][k] = kiss(seed)*pp.dim[k];
				while(inRange(pp.Y[j], DIM, pp.mask, pp.dim)==0)
				{
					for(int k=0; k<DIM; k++)
						pp.Y[j][k] = kiss(seed)*pp.dim[k];
				}
			
	}
	
}


void sim_data(points &pp, pars &p, unsigned long* seed)
{
	//Simulating X and Sigma
	p.n = rpois(p.beta*pp.vol, seed);
	double** S0 = mat_alloc(DIM);
	double** Sigma0 = mat_alloc(DIM);
	
	printf("n = %d\n", p.n);
	printf("Simulating X\n");
	mat_print(p.S, DIM, "%.4f ");
	for(int i=0; i<p.n; i++)
	{
		
		for(int j=0; j<DIM; j++)
			p.X[i][j] =pp.dim[j]/4.0+ kiss(seed)*3.0*pp.dim[j]/4.0; 
		while(inRange(p.X[i], DIM, pp.mask, pp.dim)==0)
		{
			for(int j=0; j<DIM; j++)
				p.X[i][j] = pp.dim[j]/4.0+ 3.0*kiss(seed)*pp.dim[j]/4.0; 
		}
		
		//mat_print(p.S, DIM, "%.4f ");
		rinverse_wishart(p.Sigma[i], p.S, p.df_S, seed);
		
		printf("i = %d\n",i);
		vec_print(p.X[i], DIM, "%.4f ");
		printf("--------------\n");
		mat_print(p.Sigma[i], DIM, "%.4f ");
	}
	
	
	
	
	//Simulating Points
	
	double* prob = vec_alloc(p.n+1);
	double* temp = vec_alloc(DIM);
	
	for(int i=0; i<p.n; i++)
		p.update_indicator[i] = 1;
	
	nporb_cal(pp, p, seed);
	mu_cal(pp, p, seed);
	printf("mu = %lf\n", p.mu);
	pp.m = rpois(p.mu, seed);
	pp.W = vec_alloc(pp.m);
	pp.W_id = (int*)calloc(pp.m, sizeof(int));
	pp.Y = vec_list_alloc(DIM, pp.m);
	int idx;
	
	printf("m = %d\n", pp.m);
	printf("Simulating Points ...\n");
	
	for(int j=0; j<pp.m; j++)
	{			
		printf("j = %d\n", j);
		//Simulating weighting
		pp.W_id[j] = rmultinomial(p.phi, p.V_n, seed);
		pp.W[j] = p.V[pp.W_id[j]];
		
		//Calculating probability for each point
		prob[0] = p.eps*pp.vol;
		for(int i=0;i<p.n;i++)
		{
			mat_copyval(Sigma0,p.Sigma[i],DIM);
			mat_times_k(Sigma0,DIM,1.0/pp.W[j]);
			prob[i+1] =  prob[i] + p.theta*pmvnorm(pp.mask,pp.dim,Sigma0,DIM,p.X[i],SIMUL,seed);
		}
		
		
		for(int i=0; i<p.n+1; i++)
			prob[i] /= prob[p.n]; 
		
		idx = (int) rmultinomial(prob, p.n+1, seed);
		
		if (idx==0)
		{
			for(int k=0; k<DIM; k++)
				pp.Y[j][k] = kiss(seed)*pp.dim[k];
			while(inRange(pp.Y[j], DIM, pp.mask, pp.dim)==0)
			{
				for(int k=0; k<DIM; k++)
					pp.Y[j][k] = kiss(seed)*pp.dim[k];
			}
		}
		else
		{
			mat_copyval(Sigma0, p.Sigma[idx-1], DIM);
			mat_times_k(Sigma0, DIM, 1/pp.W[j]);
			rmvnorm(temp, Sigma0, DIM, p.X[idx-1], seed, 0);
			while (inRange(temp, DIM, pp.mask, pp.dim)==0)
			{
				rmvnorm(temp, Sigma0, DIM, p.X[idx-1], seed, 1);
			}
			vec_copyval(pp.Y[j], temp, DIM);
		}
		
		
	}
	
	mat_free(S0, DIM);
	mat_free(Sigma0, DIM);		
	free(prob);
	free(temp);
}

void sim_h_data(const char* savename, points &pp, pars &p, unsigned long* seed)
{
	//Simulating population centers X and Sigma
	p.n = (int)(p.beta*pp.vol);
	double** S0 = mat_alloc(DIM);
	double** Sigma0 = mat_alloc(DIM);
	
	printf("n = %d\n", p.n);
	printf("Simulating X\n");
	mat_print(p.S, DIM, "%.4f ");
	for(int i=0; i<p.n; i++)
	{
		
		for(int j=0; j<DIM; j++)
			p.X[i][j] =pp.dim[j]/4.0+ kiss(seed)*3.0*pp.dim[j]/4.0; 
		while(inRange(p.X[i], DIM, pp.mask, pp.dim)==0)
		{
			for(int j=0; j<DIM; j++)
				p.X[i][j] = pp.dim[j]/4.0+ 3.0*kiss(seed)*pp.dim[j]/4.0; 
		}
		
		//mat_print(p.S, DIM, "%.4f ");
		rinverse_wishart(p.Sigma[i], p.S, p.df_S, seed);
		
		printf("i = %d\n",i);
		vec_print(p.X[i], DIM, "%.4f ");
		printf("--------------\n");
		mat_print(p.Sigma[i], DIM, "%.4f ");
	}
	
		
	//Simulating parent and orphaned children
	
	
	double* prob = vec_alloc(p.n+1);
	double* temp = vec_alloc(DIM);
	
	pp.m = (int)(p.eps*pp.vol+p.theta*p.n);
	//pp.W = vec_alloc(pp.m);
	//pp.W_id = (int*)calloc(pp.m, sizeof(int));
	//pp.Y = vec_list_alloc(DIM, pp.m);
	int idx;
	
	printf("m = %d\n", pp.m);
	printf("Simulating Points ...\n");
	
	for(int j=0; j<pp.m; j++)
	{			
		printf("j = %d\n", j);
		//Simulating weighting
		pp.W_id[j] = rmultinomial(p.phi, p.V_n, seed);
		pp.W[j] = p.V[pp.W_id[j]];
		
		//Calculating probability for each point
		prob[0] = p.eps*pp.vol;
		for(int i=0;i<p.n;i++)
		{
			mat_copyval(Sigma0,p.Sigma[i],DIM);
			mat_times_k(Sigma0,DIM,1.0/pp.W[j]);
			prob[i+1] =  prob[i] + p.theta*pmvnorm(pp.mask,pp.dim,Sigma0,DIM,p.X[i],SIMUL,seed);
		}
		
		
		for(int i=0; i<p.n+1; i++)
			prob[i] /= prob[p.n]; 
		
		idx = (int) rmultinomial(prob, p.n+1, seed);
		
		if (idx==0)
		{
			for(int k=0; k<DIM; k++)
				pp.Y[j][k] = kiss(seed)*pp.dim[k];
			while(inRange(pp.Y[j], DIM, pp.mask, pp.dim)==0)
			{
				for(int k=0; k<DIM; k++)
					pp.Y[j][k] = kiss(seed)*pp.dim[k];
			}
		}
		else
		{
			mat_copyval(Sigma0, p.Sigma[idx-1], DIM);
			mat_times_k(Sigma0, DIM, 1/pp.W[j]);
			rmvnorm(temp, Sigma0, DIM, p.X[idx-1], seed, 0);
			while (inRange(temp, DIM, pp.mask, pp.dim)==0)
			{
				rmvnorm(temp, Sigma0, DIM, p.X[idx-1], seed, 1);
			}
			vec_copyval(pp.Y[j], temp, DIM);
		}
		
		
	}
	
	
	//Simulating non-orphaned children 
	//int tmpm = pp.m1;
	pp.m1 = 0;
	int k = 0;
	int pnum = 0;
	int childnum = (int)p.rho;
	double tmpW;
	int tmpWID;
	for(int t=0; t<pp.n_contrast; t++)
	{
		tmpWID = rmultinomial(p.phi, p.V_n, seed);
		tmpW = p.V[tmpWID];
		pp.c_num[t] = (int) (p.xi*pp.m);
		for(int j=0; j<pp.c_num[t]; j++)
		{
			pp.contrast1[pp.m1] = t;
			pp.study1[pp.m1] = t;
			pp.W1[pp.m1] = tmpW;
			pp.W1_id[pp.m1] = tmpWID;
			vec_copyval(pp.dat[pp.m1], pp.Y[k], DIM);
			pp.m1++;
			k++;
		}
		
		
		pnum = (int)(pp.m/pp.n_contrast- p.xi*pp.m);
		pp.c_num[t] += pnum;
		
		for(int j=0; j<pnum; j++)
		{
			rinverse_wishart(pp.Lambda[t][j], p.S0, p.df_S0, seed);
			for(int l=0; l<childnum; l++)
			{
				pp.contrast1[pp.m1] = t;
				pp.study1[pp.m1] = t;
				pp.W1[pp.m1] = tmpW;
				pp.W1_id[pp.m1] = tmpWID;
				mat_copyval(Sigma0,pp.Lambda[t][j],DIM);
				mat_times_k(Sigma0, DIM, 1.0/pp.W1[pp.m1]);
				rmvnorm(pp.dat[pp.m1], Sigma0,DIM , pp.Y[k],seed , 0);
				pp.m1++;
			}
			k++;
				
		}
	}
	
	char savepoints[100];
	char savepars[100];
	char saveX[100];
	
	strcpy(savepoints, savename);
	strcat(savepoints, "_simpoints.txt");
	
	
	strcpy(savepars, savename);
	strcat(savepars, "_simpars.txt");
	
	strcpy(saveX, savename);
	strcat(saveX, "_simX.txt");
	
	
	
	
	FILE* fid  = fopen(savepoints,"wt");
	for(int i=0; i<pp.m1; i++)
	{
		fprintf(fid, "%d %d %lf %lf %lf %d %lf\n", pp.study1[i], pp.contrast1[i], 
				pp.dat[i][0],pp.dat[i][1],pp.dat[i][2],pp.W1_id[i],pp.W1[i]);
	}
	fclose(fid);
	
	
	FILE* fpars = fopen(savepars, "wt");
	fprintf(fpars, "N(X) = %d\n", p.n);
	fprintf(fpars, "N(Y) = %d\n", pp.m1);
	fprintf(fpars, "theta = %lf\n", p.theta);
	fprintf(fpars, "eps = %lf\n", p.eps);
	fprintf(fpars, "xi = %lf\n", p.xi);
	fprintf(fpars, "rho = %lf\n", p.rho);
	fclose(fpars);
	
	FILE* fX = fopen(saveX, "wt");
	for(int i=0; i<p.n; i++)
	{
		fprintf(fX, "%lf %lf %lf\n", p.X[i][0], p.X[i][1], p.X[i][2]);
	}
	fclose(fX);
	
	
	mat_free(S0, DIM);
	mat_free(Sigma0, DIM);		
	free(prob);
	free(temp);
}


void test_sim_h_dat(int in_total_iters, int in_adj_acpt, 
					  int in_burn_in, int in_rec_lambda,
					  int in_n,  int in_m,  double in_xi,
					  double in_xi_tau, double in_xi_sgm, 
					  double in_rho, double in_tau_rho, 
					  double in_eta, 
					  double in_tau_theta, double in_tau_eps,
					  double in_sgm1, double in_sgm0,
					  int in_df_S, int in_df_S0, 
					  int in_df_T, int in_df_T0,
					  double in_var_Sigma, double in_var_S0, double in_radius,
					  const char* datafile, 
					  const char* savename)
{
	unsigned long * seed = initial_seed("seed.dat");
	double *in_V = vec_alloc(2);

	char savefile[100];
	
	strcpy(savefile, savename);
	strcat(savefile, "_simpoints.txt");

	in_V[0] = 1;
	in_V[1] = 0.75;
	
	
	
	points pp = initial_points();
	//read_matlab_mask("matlab_mask.txt", pp);
	
	read_mask("brainmask.nii", pp);
	read_amygdala(pp);
	read_points1(datafile,pp);
	
	/*pars initial_pars1(int in_total_iters,int in_adj_acpt,  int in_burn_in,  int in_rec_lambda,
	 double* in_V, int in_V_n, 
	 int in_n,  int in_m,  
	 double in_eta, double in_tau_theta, double in_tau_eps,
	 double in_sgm0, double in_sgm1,
	 int in_df_S, int in_df_T, double in_var_Sigma, 
	 double in_vol)*/
	
	//pp.m = 300;
	
	if (in_m==-1)
		in_m=pp.m1;
	
	pars p = initial_pars1(in_total_iters,in_adj_acpt,in_burn_in, in_rec_lambda, in_V, 2,
						   in_n, in_m, in_xi, in_xi_tau, in_xi_sgm,
						   in_rho, in_tau_rho, 
						   in_eta, in_tau_theta,in_tau_eps,
						   in_sgm0, in_sgm1,
						   in_df_S, in_df_S0, 
						   in_df_T, in_df_T0,
						   in_var_Sigma, in_var_S0, in_radius,
						   pp.vol);
	
		
	
	printf("m = %d\n", pp.m1);
	int tmpm1 = pp.m1;
	int tmpm = pp.m;
	
	vec_print(pp.Y[0],DIM, " %4.2f");
	sim_h_data(savefile, pp, p, seed);	
	
	free_pars(p);
	pp.m1 = tmpm1;
	pp.m = tmpm;
	free_points(pp);
	free(in_V);
	free(seed);
	
}



void write_points(const char* filename, points &pp)
{
	FILE* fid;
	fid = fopen(filename, "wt");
	for(int j=0; j<pp.m; j++)
	{
		fprintf(fid, "%lf %lf %lf %d %lf\n", pp.Y[j][0], pp.Y[j][1], pp.Y[j][2], pp.W_id[j], pp.W[j]);
	}
	fclose(fid);
}

/*void test_simulation2(int in_total_iters, int in_burn_in,
					  int in_n,  double in_eta, 
					  double in_tau_theta, double in_tau_eps,
					  double in_sgm1, double in_sgm0,
					  int in_df_S, int in_df_T, double in_var_Sigma,
					  const char* datafile, 
					  const char* intense_file, const char* x_file, const char* par_file)*/


void test_simul_data0(int in_n,  int in_m, double in_eta, 
					 double in_tau_theta, double in_tau_eps,
					 int in_df_S, int in_df_S0, int in_df_T, int in_df_T0, double in_var_Sigma,double in_var_S0,
					 const char* datafile, const char* parfile)
{
	unsigned long* seed = initial_seed("seed.dat");
	kiss(seed);
	double* in_V = vec_alloc(2);
	in_V[0] = 1;
	in_V[1] = 0.75;
	points pp = initial_points();
	//read_matlab_mask("matlab_mask.txt", pp);
	read_mask("brainmask.nii", pp);
	/*pars initial_pars1(int in_total_iters,int in_adj_acpt,  int in_burn_in,  
					   int in_rec_lambda,
					   double* in_V, int in_V_n, 
					   int in_n,  int in_m,  double in_xi, 
					   double in_eta, double in_tau_theta, double in_tau_eps,
					   double in_sgm0, double in_sgm1,
					   int in_df_S, int in_df_T, double in_var_Sigma, in_radius,
					   double in_vol)*/
	
	pars p = initial_pars1(10000,100,5000, 20, in_V,2,
						   in_n,in_m, 0.01,0.1,0.003, 1,1,
						   in_eta, in_tau_theta,in_tau_eps,
						   -1, -1,
						   in_df_S, in_df_S0, in_df_T, in_df_T0, in_var_Sigma, in_var_S0, 10,
						   pp.vol);
	
	sim_data0(pp,p,seed);
	
	
	FILE* fid;
	fid = fopen(parfile, "wt");
	
	save_pars(fid, p, pp);
	fprintf(fid, "Actrual Number of Cluster = %d\n", p.n);
	
	fclose(fid);
	
	
	
	write_points(datafile, pp);

	
	free(seed);
	free_points(pp);
	free_pars(p);
}


void test_simul_data(int in_n,  int in_m, double in_eta, 
					 double in_tau_theta, double in_tau_eps,
					 int in_df_S, int in_df_S0, int in_df_T, int in_df_T0, double in_var_Sigma, double in_var_S0,
					 const char* datafile, const char* parfile)
{
	unsigned long* seed = initial_seed("seed.dat");
	double* in_V = vec_alloc(2);
	in_V[0] = 1;
	in_V[1] = 0.75;
	points pp = initial_points();
	//read_matlab_mask("matlab_mask.txt", pp);
	read_mask("brainmask.nii", pp);
	/*pars initial_pars1(int in_total_iters,int in_adj_acpt,  int in_burn_in,  
	 int in_rec_lambda,
	 double* in_V, int in_V_n, 
	 int in_n,  int in_m,  
	 double in_eta, double in_tau_theta, double in_tau_eps,
	 double in_sgm0, double in_sgm1,
	 int in_df_S, int in_df_T, double in_var_Sigma, 
	 double in_vol)*/
	
	pars p = initial_pars1(10000,100,5000, 20, in_V,2,
						   in_n,in_m, 0.01, 0.1,0.003, 1,1,
						   in_eta, in_tau_theta,in_tau_eps,
						   -1, -1,
						   in_df_S, in_df_S0, 
						   in_df_T, in_df_T0, 
						   in_var_Sigma, in_var_S0, 10,
						   pp.vol);
	
	sim_data(pp,p,seed);
	
	
	FILE* fid;
	fid = fopen(parfile, "wt");
	
	save_pars(fid, p, pp);
	fprintf(fid, "Actrual Number of Cluster = %d\n", p.n);
	
	/*fprintf(fid, "beta = %lf\n", p.beta);
	 fprintf(fid, "n = %d\n", p.n);
	 fprintf(fid, "m = %d\n", pp.m);
	 fprintf(fid, "df_S = %d\n", in_df_S);
	 fprintf(fid, "df_T = %d\n", in_df_T);
	 fprintf(fid, "Varance of Sigma = %lf \n", in_var_Sigma);
	 fprintf(fid, "Ratio of noise = %lf\n", in_eta);
	 fprintf(fid, "vol = %lf\n", pp.vol);
	 fprintf(fid, "theta = %lf\n", p.theta);
	 fprintf(fid, "epsilon = %lf \n", p.eps);
	 fprintf(fid, "alpha0 = %lf\n",p.alpha0);
	 fprintf(fid, "beta0 = %lf\n",p.beta0);
	 fprintf(fid, "alpha1 = %lf\n", p.alpha1);
	 fprintf(fid, "beta1 = %lf\n", p.beta1);*/
	
	fclose(fid);
	
	
	
	write_points(datafile, pp);
	
	
	free(seed);
	free_points(pp);
	free_pars(p);
}
