#ifndef _HIERARCHICAL_H_
#define _HIERARCHICAL_H_


/*
 *  Hierarchical.h
 *  HWeightCox01
 *
 *  Created by Jian Kang on 3/26/09.
 *  Copyright 2009 University of Michigan. All rights reserved.
 *
 */

#include "WeightedCox.h"

#define TRUNC_NORMAL_PROB 0.99
#define THRESH_NORMAL 2.34
#define ITERS 500



void Z_approx_tprob(double *tp, points &pp, pars &p, unsigned long* seed, int iters);

void Z_birth_rate_T(int i, double **prob, points &pp, pars &p, double* tp);

void Z_update_slambdalist(points &pp, pars &p);

void Z_update_dnormlist(int t, points &pp, pars &p);

void Z_add_dnormlist(int t, points &pp, pars &p);

void Z_rm_dnormlist(int t, int idx, points &pp, pars &p);

void Z_death_rate_T(int t, double** Zprob, points &pp, pars &p,unsigned long* seed);

void Z_give_a_birth(int t, double **prob, points &pp, pars &p,unsigned long* seed);


void Z_rm_centers(int t, int i, points &pp, pars &p);

void Z_death_step(int t, double **prob, points &pp, pars &p, unsigned long* seed);

int Z_update_kappa(int t, points &pp, pars &p, unsigned long *seed);

void rec_Zall(FILE* fid, points &pp, pars &p);

void Z2Y(points &pp);

void Z_spatial_birth_death(double *tp, points &pp, pars &p, int steps, unsigned long* seed);

void Z_update_S(points &pp, pars &p, unsigned long* seed);

void Z_update_nprob(int t, int i, points &pp, unsigned long* seed);

void Z_mu_cal(int t, points &pp, pars &p);

//Update Z
void Z_update_Z(int t, int Zidx, points &pp, pars &p, unsigned long* seed);


//Update Lambda
void Z_update_Lambda(int t, points &pp, pars &p, unsigned long* seed);

int Z_update_xi(int t, points &pp, pars &p, unsigned long* seed);

int Z_update_xi_all_1(points &pp, pars &p, unsigned long* seed);

int Z_update_xi_all(points &pp, pars &p, unsigned long* seed);

int Z_update_rho(points &pp, pars &p, unsigned long* seed);


int Z_update_rho_all(int t,points &pp, pars &p, unsigned long* seed);

void Z_move_step(points &pp, pars &p, unsigned long*seed);

#endif  //_HIERARCHICAL_H_