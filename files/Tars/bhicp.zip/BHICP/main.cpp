#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <Accelerate/Accelerate.h>

#include"MatVec.h"
#include"randgen.h"
#include"cholesky.h"
#include"WeightedCox.h"
#include"Hierarchical.h"
#include"nifti1.h"
#include"Timer.h"
#include"Assessment.h"
//#include"Testing.h"


#define CUT_NUM 5

double M = exp(-64*log(2.0));

typedef unsigned char DATA_TYPE;






void BHMCCP(int in_total_iters, int in_adj_acpt,
            int in_burn_in, int in_rec_lambda,
            int in_n,  int in_m,  double in_xi,
            double in_xi_tau, double in_xi_sgm, 
            double in_rho, double in_tau_rho, 
            double in_eta, 
            double in_tau_theta, double in_tau_eps,
            double in_sgm1, double in_sgm0,
            int in_df_S, int in_df_S0, 
            int in_df_T, int in_df_T0,
            double in_var_Sigma, double in_var_S0, double in_radius,int num_children,
            double rstart, double rend, int rnum, 
            const char* datafile, 
            const char* savename,
            int rec_int, int model_check, int save_sPACs)
{
	unsigned long * seed = initial_seed("seed.dat");
	double *in_V = vec_alloc(2);
	double **S = mat_alloc(DIM);
	char x_file[100];
	char x_file1[100];
	char sigma_file[100];
	char num_file[100];
	char par_file[100];
	char intense_file[100];
	char setting_file[100];
	char vol_intensity[100];
	char contrast[100];
	char study[100];
	char Zpoints[100];
	char Znum[100];
	char Zall[100];
	char SS0[100];
	char count[100];
	char ra[100];
	char la[100];
	char curvol_intensity[100];
	char sim_file[100];
	char diffLfun_file[100];
	char seedname[100];
	
	
	kiss(seed);
    //save_seed(seed,"seed1.dat");
	
	
	sprintf(seedname, "%s_seed.txt",savename);
	save_seed(seed, seedname);
	
	
	printf("seed = \n");
	printf("%lu %lu %lu\n",seed[0],seed[1],seed[2]);
	
	
	strcpy(ra, savename);
	strcat(ra, "_Ramygdala.txt");
	
	strcpy(la, savename);
	strcat(la, "_Lamygdala.txt");
    
	
	
	strcpy(count, savename);
	strcat(count, "_amygcount.txt");
	
	
	strcpy(Znum, savename);
	strcat(Znum, "_Znum.txt");
	
	strcpy(Zall, savename);
	strcat(Zall,"_Zall.txt");
	
	
	strcpy(Zpoints, savename);
	strcat(Zpoints,"_Zpoints.txt");
	
	strcpy(contrast,savename);
	strcat(contrast,"_contrast.txt");
	
	strcpy(study, savename);
	strcat(study,"_study.txt");
	
	strcpy(vol_intensity, savename);
	strcat(vol_intensity, "_vol.txt");
    
	strcpy(curvol_intensity, savename);
	strcat(curvol_intensity, "_curvol");
    
	
	strcpy(intense_file, savename);
	strcat(intense_file, "_intensity");
	
	
	strcpy(x_file, savename);
	strcat(x_file, "_x.txt");
	
	strcpy(x_file1, savename);
	strcat(x_file1, "_x1.txt");
	
	strcpy(sigma_file, savename);
	strcat(sigma_file, "_sigma.txt");
	
	strcpy(SS0, savename);
	strcat(SS0, "_SS0.txt");
	
	strcpy(num_file, savename);
	strcat(num_file, "_num.txt");
	
	strcpy(par_file, savename);
	strcat(par_file, "_results.txt");
	
	strcpy(setting_file, savename);
	strcat(setting_file, "_setting.txt");	
	
	
	
	
	
	FILE* fx = fopen(x_file, "wt");
	FILE* fx1 = fopen(x_file1,"wt");
	FILE* fsigma = fopen(sigma_file,"wt");
	FILE* fnum = fopen(num_file,"wt");
	FILE* fpar = fopen(par_file, "wt");
	FILE* fcontrast = fopen(contrast,"wt");
	FILE* fstudy = fopen(study,"wt");
	FILE* fZ = fopen(Zpoints, "wt");
	FILE* fZnum = fopen(Znum, "wt");
	FILE* fZall = fopen(Zall, "wt");
	FILE* fSS0 = fopen(SS0,"wt");
	FILE* fcount = fopen(count, "wt");
	FILE* fra = fopen(ra,"wt");
	FILE* fla = fopen(la,"wt");
	
	
	fprintf(fpar,"iteration Birth/Death numOfCluster    m       mp        N0        npacs       theta           eps    rho    totalBirthRate                 totalDeathRate          acceptRatio      phi0  phi1 birthnum deathnum\n");
	
	FILE *fid = fopen(setting_file, "wt");
	in_V[0] = 1.00;
	in_V[1] = 0.75;
	
	points pp = initial_points();
	read_mask("brainmask.nii", pp);
	read_amygdala(pp);
	read_points1(datafile,pp);
	
	if (in_m==-1)
		in_m=pp.m1;
	
	pars p = initial_pars1(in_total_iters,in_adj_acpt,in_burn_in, in_rec_lambda, in_V, 2,
						   in_n, in_m, in_xi, in_xi_tau, in_xi_sgm,
						   in_rho, in_tau_rho, 
						   in_eta, in_tau_theta,in_tau_eps,
						   in_sgm0, in_sgm1,
						   in_df_S, in_df_S0, 
						   in_df_T, in_df_T0,
						   in_var_Sigma, in_var_S0, in_radius,
						   pp.vol,num_children);
	
	p.xi_all_alpha = vec_alloc(pp.n_contrast);
	
	double sumxi =0;
	
	// initial xi
	for(int i=0; i<pp.n_contrast; i++)
	{
		p.xi_all_alpha[i] = p.xi_alpha;
		pp.xi[i] = p.xi_alpha;
		sumxi += pp.xi[i];
		
		pp.rho_all[i] = p.rho;
	}
	
	p.xi_all_alpha[pp.n_contrast] = pp.n_contrast*p.xi_alpha/19;
	pp.xi[pp.n_contrast] = p.xi_all_alpha[pp.n_contrast];
	
	for(int i=0; i<pp.n_contrast+1; i++)
		pp.xi[i] /= sumxi;
	
	
	
	
	save_pars(fid, p, pp);
	fclose(fid);
	
	
	printf("m = %d\n", pp.m1);
	
	double *tp = vec_alloc(pp.m1);
	double *Z_tp = vec_alloc(pp.m1);
	int idx = 0;
	pp.numOfBirth = 0;
	pp.numOfDeath = 0;
	
	for(int i=0; i<p.total_iters; i++)
	{
		
		p.iters = i;
		
		
		if(!(p.iters%100))
		{
			pp.xi_acpt = 0;
		}
		printf("\n\n%d | %d %d %d %d %.6lf | %.6lf %.6lf %.6lf| ", 
			   i, p.n, pp.m, p.N0, pp.m_p,pp.npacs, p.theta, p.eps, p.beta);
		for(int j=0;j<5; j++)
			printf("%.6lf ", pp.rho_all[j]);
		printf("| ");
		for(int j=0;j<5; j++)
			printf("%d ", pp.c_num[j]);
		printf("| ");
		for(int j=0;j<5; j++)
			printf("%d ", pp.Z0_n[j]);
		printf("| ");
		for(int j=0;j<5; j++)
			printf("%d ", pp.Zg_n[j]);
		
        
		printf("| ");
		for(int j=0;j<5; j++)
			printf("%.6lf ", pp.xi[j]);
		
		printf("| %d", pp.xi_acpt);
		
        
		fflush(stdout);
		
        
		
		Z_approx_tprob(Z_tp, pp,p,seed,SIMUL);
		Z_spatial_birth_death(Z_tp, pp,p,10,seed);
		Z_move_step(pp, p, seed);
		
		approx_tprob(tp, pp, p, seed, SIMUL);
		spatial_birth_death(tp,pp,p,10,seed);
		
		move_step(pp,p,seed);
		
		
		
		printf(" %d %d\n", pp.numOfBirth, pp.numOfDeath);
		
        
		
		update_kappa(pp, p, seed);
		
		
		
		update_S(p, seed);
		update_beta(p, pp, seed);
		
		
		rec_pars(fpar, p, pp);
		rec_Z(fZ,pp,p);
		rec_numZ(fZnum, pp, p);
		rec_Zall(fZall, pp, p);
		rec_S(fSS0,p);
		
		if(!(p.iters%1000) && p.iters>p.burn_in)
		{
			rec_PAC_in_LA(fla, pp, p);
			rec_PAC_in_RA(fra, pp, p);
		}
		
		if(p.iters>p.burn_in && !(p.iters%p.rec_lambda))
//            if(p.iters>p.burn_in && p.iters*1.0/p.rec_lambda == p.iters/p.rec_lambda)
		{
			rec_intensity(pp, p);
			rec_centers(fx, p,idx);
			rec_centers1(fx1,p);
			rec_id_study(fstudy, pp, p);
			rec_id_contrast(fcontrast, pp, p);
			rec_Sigma(fsigma, p);
			rec_num(fnum,p);
			rec_Amygdala(fcount, p,pp);
			
            
			
			
			if (rec_int==1)
			{
				sprintf(curvol_intensity, "%s_curvol_%d.txt", savename, p.iters);
				write_curvol(curvol_intensity, pp, p);
			}
			
			
			if (model_check ==1)
			{
				simAllPACs(pp, p, seed);
				compute_diff_Lfun(rstart, rend, rnum, pp, p, seed);
				if(save_sPACs==1)
				{
					sprintf(sim_file, "%s_simPACs_%d.txt",savename,p.iters);
					write_sPACs(sim_file, pp, p);
				}
				sprintf(diffLfun_file, "%s_diffLfun_%d.txt", savename, p.iters);
				write_diff_Lfun(diffLfun_file, pp, rnum);
			}
		}
		
		//printf("%d", p.N0);
		//for(int k=0; k<p.n; k++)
		//	printf(" %d",p.Num[k]);
		
		printf("\n");
		
		
		
	}
    
	printf("Writing intensity functions ...");
    
	write_vol(vol_intensity, pp, p);
	
	write_margin(intense_file, pp, p);
	printf("Finished! \n");
	
	//save_seed(seed,"seed.dat");
	free(seed);
	mat_free(S,DIM);
	free(tp);
	free(Z_tp);
	free(in_V);
	free(p.xi_all_alpha);
	
	
	free_pars(p);
	free_points(pp);
	
	fclose(fx);
	fclose(fx1);
	fclose(fpar);
	fclose(fsigma);
	fclose(fnum);
	fclose(fstudy);
	fclose(fcontrast);
	fclose(fZ);
	fclose(fZnum);
	fclose(fZall);
	fclose(fSS0);
	fclose(fcount);
	fclose(fra);
	fclose(fla);
}


void BHMCCP2(int in_total_iters, int in_adj_acpt, 
             int in_burn_in, int in_rec_lambda,
             int in_n,  int in_m,  double in_xi,
             double in_xi_tau, double in_xi_sgm, 
             double in_rho, double in_tau_rho, 
             double a_theta, double b_theta,
             double a_eps, double b_eps,
             double in_sgm1, double in_sgm0,
             int in_df_S, int in_df_S0, 
             int in_df_T, int in_df_T0,
             double in_var_Sigma, double in_var_S0, double in_radius,int num_children,int cutnumber,
             double rstart, double rend, int rnum, 
             const char* datafile, 
             const char* savename,
             int rec_int, int model_check,int save_sPACs)
{
	unsigned long * seed = initial_seed("seed.dat");
	double *in_V = vec_alloc(2);
	double **S = mat_alloc(DIM);
	char x_file[100];
	char x_file1[100];
	char sigma_file[100];
	char num_file[100];
	char par_file[100];
	char intense_file[100];
	char setting_file[100];
	char vol_intensity[100];
	char contrast[100];
	char study[100];
	char Zpoints[100];
	char Znum[100];
	char Zall[100];
	char SS0[100];
	char count[100];
	char ra[100];
	char la[100];
	char curvol_intensity[100];
	char sim_file[100];
	char diffLfun_file[100];
	char num_Z00_file[100];
	char num_Z01_file[100];
	char num_Z1_file[100];
	char xi_file[100];
	char rho_file[100];
	char beta_file[100];
	char seedname[100];
	char pred_int_name[100];
	
	kiss(seed);
    //save_seed(seed,"seed1.dat");
	
	sprintf(num_Z00_file,"%s_num_Z00.txt",savename);
	sprintf(num_Z1_file,"%s_num_Z1.txt",savename);
	sprintf(num_Z01_file,"%s_num_Z01.txt",savename);
	sprintf(xi_file,"%s_rho.txt",savename);
	sprintf(rho_file,"%s_eta.txt",savename);
	sprintf(beta_file,"%s_beta.txt",savename);
	
	sprintf(seedname, "%s_seed.txt",savename);
	save_seed(seed, seedname);
	
	
	printf("seed = \n");
	printf("%lu %lu %lu\n",seed[0],seed[1],seed[2]);
	
	
	strcpy(ra, savename);
	strcat(ra, "_Ramygdala.txt");
	
	strcpy(la, savename);
	strcat(la, "_Lamygdala.txt");
	
	
	
	strcpy(count, savename);
	strcat(count, "_amygcount.txt");
	
	
	strcpy(Znum, savename);
	strcat(Znum, "_Znum.txt");
	
	strcpy(Zall, savename);
	strcat(Zall,"_Zall.txt");
	
	
	strcpy(Zpoints, savename);
	strcat(Zpoints,"_Zpoints.txt");
	
	strcpy(contrast,savename);
	strcat(contrast,"_contrast.txt");
	
	strcpy(study, savename);
	strcat(study,"_study.txt");
	
	strcpy(vol_intensity, savename);
	strcat(vol_intensity, "_vol.txt");
	
	strcpy(pred_int_name, savename);
	strcat(pred_int_name, "_pred_vol.txt");
	
	strcpy(curvol_intensity, savename);
	strcat(curvol_intensity, "_curvol");
	
	
	strcpy(intense_file, savename);
	strcat(intense_file, "_intensity");
	
	
	strcpy(x_file, savename);
	strcat(x_file, "_x.txt");
	
	strcpy(x_file1, savename);
	strcat(x_file1, "_x1.txt");
	
	strcpy(sigma_file, savename);
	strcat(sigma_file, "_sigma.txt");
	
	strcpy(SS0, savename);
	strcat(SS0, "_SS0.txt");
	
	strcpy(num_file, savename);
	strcat(num_file, "_num.txt");
	
	strcpy(par_file, savename);
	strcat(par_file, "_results.txt");
	
	strcpy(setting_file, savename);
	strcat(setting_file, "_setting.txt");	
	
	
	
	
	
	FILE* fx = fopen(x_file, "wt");
	FILE* fx1 = fopen(x_file1,"wt");
	FILE* fsigma = fopen(sigma_file,"wt");
	FILE* fnum = fopen(num_file,"wt");
	FILE* fpar = fopen(par_file, "wt");
	FILE* fcontrast = fopen(contrast,"wt");
	FILE* fstudy = fopen(study,"wt");
	FILE* fZ = fopen(Zpoints, "wt");
	FILE* fZnum = fopen(Znum, "wt");
	FILE* fZall = fopen(Zall, "wt");
	FILE* fSS0 = fopen(SS0,"wt");
	FILE* fcount = fopen(count, "wt");
	FILE* fra = fopen(ra,"wt");
	FILE* fla = fopen(la,"wt");
	FILE* fnum_Z00 = fopen(num_Z00_file,"wt");
	FILE* fnum_Z01 = fopen(num_Z01_file,"wt");
	FILE* fnum_Z1  = fopen(num_Z1_file,"wt");
	FILE* fxi = fopen(xi_file,"wt");
	FILE* frho = fopen(rho_file,"wt");
	FILE* fbeta = fopen(beta_file,"wt");
    
	
	
	fprintf(fpar,"iteration Birth/Death numOfCluster    m       mp        N0        npacs       theta           eps    rho    totalBirthRate                 totalDeathRate          acceptRatio      phi0  phi1 birthnum deathnum\n");
	
	FILE *fid = fopen(setting_file, "wt");
	in_V[0] = 1.00;
	in_V[1] = 0.75;
	
	points pp = initial_points();
	read_mask("brainmask.nii", pp);
	read_amygdala(pp);
	read_points1(datafile,pp);
	
	if (in_m==-1)
		in_m=pp.m1;
	
	pars p = initial_pars2(in_total_iters,in_adj_acpt,in_burn_in, in_rec_lambda, in_V, 2,
						   in_n, in_m, in_xi, in_xi_tau, in_xi_sgm,
						   in_rho, in_tau_rho, 
						   a_theta,b_theta,a_eps,b_eps,
						   in_sgm0, in_sgm1,
						   in_df_S, in_df_S0, 
						   in_df_T, in_df_T0,
						   in_var_Sigma, in_var_S0, in_radius,
						   pp.vol,num_children,cutnumber);
	
	p.xi_all_alpha = vec_alloc(pp.n_contrast);
	
	double sumxi =0;
	
	// initial xi
	for(int i=0; i<pp.n_contrast; i++)
	{
		p.xi_all_alpha[i] = p.xi_alpha;
		pp.xi[i] = p.xi_alpha;
		sumxi += pp.xi[i];
		
		pp.rho_all[i] = p.rho;
	}
	
	p.xi_all_alpha[pp.n_contrast] = pp.n_contrast*p.xi_alpha;
	pp.xi[pp.n_contrast] = p.xi_all_alpha[pp.n_contrast];
	
	for(int i=0; i<pp.n_contrast+1; i++)
		pp.xi[i] /= sumxi;
	
	
	
	
	save_pars(fid, p, pp);
	fclose(fid);
	
	
	
	printf("m = %d\n", pp.m1);
	
	double *tp = vec_alloc(pp.m1);
	double *Z_tp = vec_alloc(pp.m1);
	int idx = 0;
	pp.numOfBirth = 0;
	pp.numOfDeath = 0;
	
	for(int i=0; i<p.total_iters; i++)
	{
		
		p.iters = i;
		
		
		if(!(p.iters%100))
		{
			pp.xi_acpt = 0;
		}
		printf("\n\n%d | %d %d %d %d %.6lf | %.6lf %.6lf %.6lf| ", 
			   i, p.n, pp.m, p.N0, pp.m_p,pp.npacs, p.theta, p.eps, p.beta);
		for(int j=0;j<5; j++)
			printf("%.6lf ", pp.rho_all[j]);
		printf("| ");
		for(int j=0;j<5; j++)
			printf("%d ", pp.c_num[j]);
		printf("| ");
		for(int j=0;j<5; j++)
			printf("%d ", pp.Z0_n[j]);
		printf("| ");
		for(int j=0;j<5; j++)
			printf("%d ", pp.Zg_n[j]);
		
		
		printf("| ");
		for(int j=0;j<5; j++)
			printf("%.6lf ", pp.xi[j]);
		
		printf("| %d", pp.xi_acpt);
		
		
		fflush(stdout);
		
		
		
		Z_approx_tprob(Z_tp, pp,p,seed,SIMUL);
		Z_spatial_birth_death(Z_tp, pp,p,10,seed);
		Z_move_step(pp, p, seed);
		
		approx_tprob(tp, pp, p, seed, SIMUL);
		spatial_birth_death(tp,pp,p,10,seed);
		
		move_step(pp,p,seed);
		
		
		
		printf(" %d %d\n", pp.numOfBirth, pp.numOfDeath);
		
		
		
		update_kappa(pp, p, seed);
		
		
		
		update_S(p, seed);
		update_beta(p, pp, seed);
		
		
		rec_pars(fpar, p, pp);
		rec_Z(fZ,pp,p);
		rec_numZ(fZnum, pp, p);
		rec_Zall(fZall, pp, p);
		rec_S(fSS0,p);
		rec_num_Z00(fnum_Z00,pp,p);
		rec_num_Z01(fnum_Z01,pp,p);
		rec_num_Z1(fnum_Z1, pp, p);
		rec_xi(fxi,pp,p);
		rec_rho(frho,pp,p);
		rec_beta(fbeta, pp, p);
		
		if(!(p.iters%1000) && p.iters>p.burn_in)
		{
			rec_PAC_in_LA(fla, pp, p);
			rec_PAC_in_RA(fra, pp, p);
		}
		
		if(p.iters>p.burn_in && !(p.iters%p.rec_lambda))
//            if(p.iters>p.burn_in && p.iters*1.0/p.rec_lambda == p.iters/p.rec_lambda)
		{
			rec_num(fnum,p);
			rec_centers1(fx1,p);
			rec_Sigma(fsigma, p);
			
			rec_intensity(pp, p);
            
			rec_centers(fx, p,idx);
			
			rec_id_study(fstudy, pp, p);
			rec_id_contrast(fcontrast, pp, p);
            
            
			rec_Amygdala(fcount, p,pp);
			
			
			
			
			if (rec_int==1)
			{
				sprintf(curvol_intensity, "%s_curvol_%d.txt", savename, p.iters);
				write_curvol(curvol_intensity, pp, p);
			}
			
			
			if (model_check ==1)
			{
				rec_pred_intensity(pp, p, seed);
				simAllPACs(pp, p, seed);
				compute_diff_Lfun(rstart, rend, rnum, pp, p, seed);
				if(save_sPACs==1)
				{
					sprintf(sim_file, "%s_simPACs_%d.txt",savename,p.iters);
					write_sPACs(sim_file, pp, p);
				}
				sprintf(diffLfun_file, "%s_diffLfun_%d.txt", savename, p.iters);
				write_diff_Lfun(diffLfun_file, pp, rnum);
			}
		}
		
		printf("\n %d", p.N0);
		for(int k=0; k<p.n; k++)
			printf(" %d",p.Num[k]);
		
		printf("\n");
		
		
		
	}
	
	printf("Writing intensity functions ...");
	
	write_vol(vol_intensity, pp, p);
	write_pred_vol(pred_int_name, pp, p);
	write_margin(intense_file, pp, p);
	printf("Finished! \n");
	
	//save_seed(seed,"seed.dat");
	free(seed);
	mat_free(S,DIM);
	free(tp);
	free(Z_tp);
	free(in_V);
	free(p.xi_all_alpha);
	
	
	free_pars(p);
	free_points(pp);
	
	fclose(fx);
	fclose(fx1);
	fclose(fpar);
	fclose(fsigma);
	fclose(fnum);
	fclose(fstudy);
	fclose(fcontrast);
	fclose(fZ);
	fclose(fZnum);
	fclose(fZall);
	fclose(fSS0);
	fclose(fcount);
	fclose(fra);
	fclose(fla);
	fclose(fnum_Z00);
	fclose(fnum_Z01);
	fclose(fnum_Z1);
	fclose(fxi);
	fclose(frho);
	fclose(fbeta);
}


void BHMCCP3(int in_total_iters, int in_adj_acpt, 
			 int in_burn_in, int in_rec_lambda,
			 double a_beta, double b_beta,  
			 double a_theta,  double a_eps, 
			 int in_df_S, int in_df_S0, 
			 int in_df_T, 
			 double in_var_Sigma, double in_var_S0, 
			 double rstart, double rend, int rnum, 
			 const char* datafile, 
			 const char* savename,
			 int rec_int, 
			 int model_check,
			 int save_sPACs)
{
	unsigned long * seed = initial_seed("seed.dat");
	double *in_V = vec_alloc(2);
	double **S = mat_alloc(DIM);
	char x_file[100];
	char x_file1[100];
	char sigma_file[100];
	char num_file[100];
	char par_file[100];
	char intense_file[100];
	char setting_file[100];
	char vol_intensity[100];
	char contrast[100];
	char study[100];
	char Zpoints[100];
	char Znum[100];
	char Zall[100];
	char SS0[100];
	char count[100];
	char ra[100];
	char la[100];
	char curvol_intensity[100];
	char sim_file[100];
	char diffLfun_file[100];
	char num_Z00_file[100];
	char num_Z01_file[100];
	char num_Z1_file[100];
	char xi_file[100];
	char rho_file[100];
	char beta_file[100];
	char seedname[100];
	char pred_int_name[100];
	
	kiss(seed);
	
	sprintf(num_Z00_file,"%s_num_Z00.txt",savename);
	sprintf(num_Z1_file,"%s_num_Z1.txt",savename);
	sprintf(num_Z01_file,"%s_num_Z01.txt",savename);
	sprintf(xi_file,"%s_rho.txt",savename);
	sprintf(rho_file,"%s_eta.txt",savename);
	sprintf(beta_file,"%s_beta.txt",savename);
	
	sprintf(seedname, "%s_seed.txt",savename);
	save_seed(seed, seedname);
	
	
	printf("seed = \n");
	printf("%lu %lu %lu\n",seed[0],seed[1],seed[2]);
	
	
	strcpy(ra, savename);
	strcat(ra, "_Ramygdala.txt");
	
	strcpy(la, savename);
	strcat(la, "_Lamygdala.txt");
	
	strcpy(count, savename);
	strcat(count, "_amygcount.txt");
	
	strcpy(Znum, savename);
	strcat(Znum, "_Znum.txt");
	
	strcpy(Zall, savename);
	strcat(Zall,"_Zall.txt");
	
	strcpy(Zpoints, savename);
	strcat(Zpoints,"_Zpoints.txt");
	
	strcpy(contrast,savename);
	strcat(contrast,"_contrast.txt");
	
	strcpy(study, savename);
	strcat(study,"_study.txt");
	
	strcpy(vol_intensity, savename);
	strcat(vol_intensity, "_vol.txt");
	
	strcpy(pred_int_name, savename);
	strcat(pred_int_name, "_pred_vol.txt");
	
	strcpy(curvol_intensity, savename);
	strcat(curvol_intensity, "_curvol");
	
	strcpy(intense_file, savename);
	strcat(intense_file, "_intensity");
	
	strcpy(x_file, savename);
	strcat(x_file, "_x.txt");
	
	strcpy(x_file1, savename);
	strcat(x_file1, "_x1.txt");
	
	strcpy(sigma_file, savename);
	strcat(sigma_file, "_sigma.txt");
	
	strcpy(SS0, savename);
	strcat(SS0, "_SS0.txt");
	
	strcpy(num_file, savename);
	strcat(num_file, "_num.txt");
	
	strcpy(par_file, savename);
	strcat(par_file, "_results.txt");
	
	strcpy(setting_file, savename);
	strcat(setting_file, "_setting.txt");	
	
	FILE* fx = fopen(x_file, "wt");
	FILE* fx1 = fopen(x_file1,"wt");
	FILE* fsigma = fopen(sigma_file,"wt");
	FILE* fnum = fopen(num_file,"wt");
	FILE* fpar = fopen(par_file, "wt");
	FILE* fcontrast = fopen(contrast,"wt");
	FILE* fstudy = fopen(study,"wt");
	FILE* fZ = fopen(Zpoints, "wt");
	FILE* fZnum = fopen(Znum, "wt");
	FILE* fZall = fopen(Zall, "wt");
	FILE* fSS0 = fopen(SS0,"wt");
	FILE* fcount = fopen(count, "wt");
	FILE* fra = fopen(ra,"wt");
	FILE* fla = fopen(la,"wt");
	FILE* fnum_Z00 = fopen(num_Z00_file,"wt");
	FILE* fnum_Z01 = fopen(num_Z01_file,"wt");
	FILE* fnum_Z1  = fopen(num_Z1_file,"wt");
	FILE* fxi = fopen(xi_file,"wt");
	FILE* frho = fopen(rho_file,"wt");
	FILE* fbeta = fopen(beta_file,"wt");
	
	fprintf(fpar,"iteration Birth/Death numOfCluster    m       mp        N0        npacs       theta           eps    rho    totalBirthRate                 totalDeathRate          acceptRatio      phi0  phi1 birthnum deathnum\n");
	
	FILE *fid = fopen(setting_file, "wt");
	in_V[0] = 1.00;
	in_V[1] = 0.75;
	
	points pp = initial_points();
	read_mask("brainmask.nii", pp);
	read_amygdala(pp);
	read_points1(datafile,pp);
	
	pars p = initial_pars3(in_total_iters, in_adj_acpt, in_burn_in, in_rec_lambda,
						   in_V, 2, a_beta, b_beta, a_theta, a_eps, in_df_S, in_df_S0, 
						   in_df_T, in_var_Sigma, in_var_S0, pp.vol);
    
	p.xi_all_alpha = vec_alloc(pp.n_contrast+1);
	
	double sumxi =0;
	
	// initial xi
	for(int i=0; i<pp.n_contrast; i++)
	{
		p.xi_all_alpha[i] = 0.5;
		pp.xi[i] = 0.5;
		sumxi += pp.xi[i];
		
		pp.rho_all[i] = p.rho;
	}
	
	p.xi_all_alpha[pp.n_contrast] = pp.n_contrast*p.xi_alpha;
	pp.xi[pp.n_contrast] = p.xi_all_alpha[pp.n_contrast];
	
	for(int i=0; i<pp.n_contrast+1; i++)
		pp.xi[i] /= sumxi;
	
	
	
	save_pars(fid, p, pp);
	fclose(fid);
	
	
	
	printf("m = %d\n", pp.m1);
	
	double *tp = vec_alloc(pp.m1);
	double *Z_tp = vec_alloc(pp.m1);
	int idx = 0;
	pp.numOfBirth = 0;
	pp.numOfDeath = 0;
	
	for(int i=0; i<p.total_iters; i++)
	{
		
		p.iters = i;
		
		
		if(!(p.iters%100))
		{
			pp.xi_acpt = 0;
		}
		printf("\n\n%d | %d %d %d %d %.6lf | %.6lf %.6lf %.6lf| ", 
			   i, p.n, pp.m, p.N0, pp.m_p,pp.npacs, p.theta, p.eps, p.beta);
		for(int j=0;j<5; j++)
			printf("%.6lf ", pp.rho_all[j]);
		printf("| ");
		for(int j=0;j<5; j++)
			printf("%d ", pp.c_num[j]);
		printf("| ");
		for(int j=0;j<5; j++)
			printf("%d ", pp.Z0_n[j]);
		printf("| ");
		for(int j=0;j<5; j++)
			printf("%d ", pp.Zg_n[j]);
		
		
		printf("| ");
		for(int j=0;j<5; j++)
			printf("%.6lf ", pp.xi[j]);
		
		printf("| %d", pp.xi_acpt);
		
		
		fflush(stdout);
		
		
		
		Z_approx_tprob(Z_tp, pp,p,seed,SIMUL);
		Z_spatial_birth_death(Z_tp, pp,p,10,seed);
		Z_move_step(pp, p, seed);
		
		approx_tprob(tp, pp, p, seed, SIMUL);
		spatial_birth_death(tp,pp,p,10,seed);
		
		move_step(pp,p,seed);
		
		
		
		printf(" %d %d\n", pp.numOfBirth, pp.numOfDeath);
		
		
		
		update_kappa(pp, p, seed);
		
		
		
		update_S(p, seed);
		update_beta(p, pp, seed);
		
		
		rec_pars(fpar, p, pp);
		rec_Z(fZ,pp,p);
		rec_numZ(fZnum, pp, p);
		rec_Zall(fZall, pp, p);
		rec_S(fSS0,p);
		rec_num_Z00(fnum_Z00,pp,p);
		rec_num_Z01(fnum_Z01,pp,p);
		rec_num_Z1(fnum_Z1, pp, p);
		rec_xi(fxi,pp,p);
		rec_rho(frho,pp,p);
		rec_beta(fbeta, pp, p);
		
		if(!(p.iters%1000) && p.iters>p.burn_in)
		{
			rec_PAC_in_LA(fla, pp, p);
			rec_PAC_in_RA(fra, pp, p);
		}
		
		if(p.iters>p.burn_in && !(p.iters%p.rec_lambda))
            //            if(p.iters>p.burn_in && p.iters*1.0/p.rec_lambda == p.iters/p.rec_lambda)
		{
			rec_num(fnum,p);
			rec_centers1(fx1,p);
			rec_Sigma(fsigma, p);
			
			rec_intensity(pp, p);
			
			rec_centers(fx, p,idx);
			
			rec_id_study(fstudy, pp, p);
			rec_id_contrast(fcontrast, pp, p);
			
			
			rec_Amygdala(fcount, p,pp);
			
			
			
			
			if (rec_int==1)
			{
				sprintf(curvol_intensity, "%s_curvol_%d.txt", savename, p.iters);
				write_curvol(curvol_intensity, pp, p);
			}
			
			
			if (model_check ==1)
			{
				rec_pred_intensity(pp, p, seed);
				simAllPACs(pp, p, seed);
				compute_diff_Lfun(rstart, rend, rnum, pp, p, seed);
				if(save_sPACs==1)
				{
					sprintf(sim_file, "%s_simPACs_%d.txt",savename,p.iters);
					write_sPACs(sim_file, pp, p);
				}
				sprintf(diffLfun_file, "%s_diffLfun_%d.txt", savename, p.iters);
				write_diff_Lfun(diffLfun_file, pp, rnum);
			}
		}
		
		printf("\n %d", p.N0);
		for(int k=0; k<p.n; k++)
			printf(" %d",p.Num[k]);
		
		printf("\n");
		
		
		
	}
	
	printf("Writing intensity functions ...");
	
	write_vol(vol_intensity, pp, p);
	write_pred_vol(pred_int_name, pp, p);
	write_margin(intense_file, pp, p);
	printf("Finished! \n");
	
	//save_seed(seed,"seed.dat");
	free(seed);
	mat_free(S,DIM);
	free(tp);
	free(Z_tp);
	free(in_V);
	free(p.xi_all_alpha);
	
	
	free_pars(p);
	free_points(pp);
	
	fclose(fx);
	fclose(fx1);
	fclose(fpar);
	fclose(fsigma);
	fclose(fnum);
	fclose(fstudy);
	fclose(fcontrast);
	fclose(fZ);
	fclose(fZnum);
	fclose(fZall);
	fclose(fSS0);
	fclose(fcount);
	fclose(fra);
	fclose(fla);
	fclose(fnum_Z00);
	fclose(fnum_Z01);
	fclose(fnum_Z1);
	fclose(fxi);
	fclose(frho);
	fclose(fbeta);
}



void BHMCCP4(int in_total_iters, int in_adj_acpt, 
			 int in_burn_in, int in_rec_lambda,
			 double a_beta, double b_beta,  
			 double a_theta,  double a_eps, 
			 int in_df_S, int in_df_S0, 
			 int in_df_T, 
			 double in_var_Sigma, double in_var_S0, 
			 double rstart, double rend, int rnum, 
			 const char* datafile, 
			 const char* savename,
			 int rec_int, 
			 int model_check,
			 int save_sPACs)
{
	unsigned long * seed = initial_seed("seed.dat");
	double *in_V = vec_alloc(2);
	double **S = mat_alloc(DIM);
	char x_file[100];
	char x_file1[100];
	char sigma_file[100];
	char num_file[100];
	char par_file[100];
	char intense_file[100];
	char setting_file[100];
	char vol_intensity[100];
	char contrast[100];
	char study[100];
	char Zpoints[100];
	char Znum[100];
	char Zall[100];
	char SS0[100];
	char count[100];
	char ra[100];
	char la[100];
	char curvol_intensity[100];
	char sim_file[100];
	char diffLfun_file[100];
	char num_Z00_file[100];
	char num_Z01_file[100];
	char num_Z1_file[100];
	char xi_file[100];
	char rho_file[100];
	char beta_file[100];
	char seedname[100];
	char pred_int_name[100];
	
	kiss(seed);
	
	sprintf(num_Z00_file,"%s_num_Z00.txt",savename);
	sprintf(num_Z1_file,"%s_num_Z1.txt",savename);
	sprintf(num_Z01_file,"%s_num_Z01.txt",savename);
	sprintf(xi_file,"%s_rho.txt",savename);
	sprintf(rho_file,"%s_eta.txt",savename);
	sprintf(beta_file,"%s_beta.txt",savename);
	
	sprintf(seedname, "%s_seed.txt",savename);
	save_seed(seed, seedname);
	
	
	printf("seed = \n");
	printf("%lu %lu %lu\n",seed[0],seed[1],seed[2]);
	
	
	strcpy(ra, savename);
	strcat(ra, "_Ramygdala.txt");
	
	strcpy(la, savename);
	strcat(la, "_Lamygdala.txt");
	
	strcpy(count, savename);
	strcat(count, "_amygcount.txt");
	
	strcpy(Znum, savename);
	strcat(Znum, "_Znum.txt");
	
	strcpy(Zall, savename);
	strcat(Zall,"_Zall.txt");
	
	strcpy(Zpoints, savename);
	strcat(Zpoints,"_Zpoints.txt");
	
	strcpy(contrast,savename);
	strcat(contrast,"_contrast.txt");
	
	strcpy(study, savename);
	strcat(study,"_study.txt");
	
	strcpy(vol_intensity, savename);
	strcat(vol_intensity, "_vol.txt");
	
	strcpy(pred_int_name, savename);
	strcat(pred_int_name, "_pred_vol.txt");
	
	strcpy(curvol_intensity, savename);
	strcat(curvol_intensity, "_curvol");
	
	strcpy(intense_file, savename);
	strcat(intense_file, "_intensity");
	
	strcpy(x_file, savename);
	strcat(x_file, "_x.txt");
	
	strcpy(x_file1, savename);
	strcat(x_file1, "_x1.txt");
	
	strcpy(sigma_file, savename);
	strcat(sigma_file, "_sigma.txt");
	
	strcpy(SS0, savename);
	strcat(SS0, "_SS0.txt");
	
	strcpy(num_file, savename);
	strcat(num_file, "_num.txt");
	
	strcpy(par_file, savename);
	strcat(par_file, "_results.txt");
	
	strcpy(setting_file, savename);
	strcat(setting_file, "_setting.txt");	
	
	FILE* fx = fopen(x_file, "wt");
	FILE* fx1 = fopen(x_file1,"wt");
	FILE* fsigma = fopen(sigma_file,"wt");
	FILE* fnum = fopen(num_file,"wt");
	FILE* fpar = fopen(par_file, "wt");
	FILE* fcontrast = fopen(contrast,"wt");
	FILE* fstudy = fopen(study,"wt");
	FILE* fZ = fopen(Zpoints, "wt");
	FILE* fZnum = fopen(Znum, "wt");
	FILE* fZall = fopen(Zall, "wt");
	FILE* fSS0 = fopen(SS0,"wt");
	FILE* fcount = fopen(count, "wt");
	FILE* fra = fopen(ra,"wt");
	FILE* fla = fopen(la,"wt");
	FILE* fnum_Z00 = fopen(num_Z00_file,"wt");
	FILE* fnum_Z01 = fopen(num_Z01_file,"wt");
	FILE* fnum_Z1  = fopen(num_Z1_file,"wt");
	FILE* fxi = fopen(xi_file,"wt");
	FILE* frho = fopen(rho_file,"wt");
	FILE* fbeta = fopen(beta_file,"wt");
	
	fprintf(fpar,"iteration Birth/Death numOfCluster    m       mp        N0        npacs       theta           eps    rho    totalBirthRate                 totalDeathRate          acceptRatio      phi0  phi1 birthnum deathnum\n");
	
	FILE *fid = fopen(setting_file, "wt");
	in_V[0] = 1.00;
	in_V[1] = 1.00;
	
	points pp = initial_points();
	read_mask("brainmask.nii", pp);
	read_amygdala(pp);
	read_points1(datafile,pp);
	
	pars p = initial_pars3(in_total_iters, in_adj_acpt, in_burn_in, in_rec_lambda,
						   in_V, 2, a_beta, b_beta, a_theta, a_eps, in_df_S, in_df_S0, 
						   in_df_T, in_var_Sigma, in_var_S0, pp.vol);
	
	p.xi_all_alpha = vec_alloc(pp.n_contrast+1);
	
	double sumxi =0;
	
	// initial xi
	for(int i=0; i<pp.n_contrast; i++)
	{
		p.xi_all_alpha[i] = 0.5;
		pp.xi[i] = 0.5;
		sumxi += pp.xi[i];
		
		pp.rho_all[i] = p.rho;
	}
	
	p.xi_all_alpha[pp.n_contrast] = pp.n_contrast*p.xi_alpha;
	pp.xi[pp.n_contrast] = p.xi_all_alpha[pp.n_contrast];
	
	for(int i=0; i<pp.n_contrast+1; i++)
		pp.xi[i] /= sumxi;
	
	
	
	save_pars(fid, p, pp);
	fclose(fid);
	
	
	
	printf("m = %d\n", pp.m1);
	
	double *tp = vec_alloc(pp.m1);
	double *Z_tp = vec_alloc(pp.m1);
	int idx = 0;
	pp.numOfBirth = 0;
	pp.numOfDeath = 0;
	
	Z2Y(pp);
	
	for(int i=0; i<p.total_iters; i++)
	{
		
		p.iters = i;
		
		
		if(!(p.iters%100))
		{
			pp.xi_acpt = 0;
		}
		printf("\n\n%d | %d %d %d %d %.6lf | %.6lf %.6lf %.6lf| ", 
			   i, p.n, pp.m, p.N0, pp.m_p,pp.npacs, p.theta, p.eps, p.beta);
		for(int j=0;j<5; j++)
			printf("%.6lf ", pp.rho_all[j]);
		printf("| ");
		for(int j=0;j<5; j++)
			printf("%d ", pp.c_num[j]);
		printf("| ");
		for(int j=0;j<5; j++)
			printf("%d ", pp.Z0_n[j]);
		printf("| ");
		for(int j=0;j<5; j++)
			printf("%d ", pp.Zg_n[j]);
		
		
		printf("| ");
		for(int j=0;j<5; j++)
			printf("%.6lf ", pp.xi[j]);
		
		printf("| %d", pp.xi_acpt);
		
		
		fflush(stdout);
		
		
		
		Z_approx_tprob(Z_tp, pp,p,seed,SIMUL);
		Z_spatial_birth_death(Z_tp, pp,p,10,seed);
		Z_move_step(pp, p, seed);
		
		
		
		approx_tprob(tp, pp, p, seed, SIMUL);
		spatial_birth_death(tp,pp,p,10,seed);
		
	    move_step(pp,p,seed);
		
		
		
		printf(" %d %d\n", pp.numOfBirth, pp.numOfDeath);
		
		
		
		//update_kappa(pp, p, seed);
		
		
		
		//update_S(p, seed);
		//update_beta(p, pp, seed);
		
		
		rec_pars(fpar, p, pp);
		//rec_Z(fZ,pp,p);
		//rec_numZ(fZnum, pp, p);
		//rec_Zall(fZall, pp, p);
		rec_S(fSS0,p);
		//rec_num_Z00(fnum_Z00,pp,p);
		//rec_num_Z01(fnum_Z01,pp,p);
		//rec_num_Z1(fnum_Z1, pp, p);
		rec_xi(fxi,pp,p);
		rec_rho(frho,pp,p);
		rec_beta(fbeta, pp, p);
		
		rec_centers1(fx1,p);
		rec_Sigma(fsigma, p);
        
		
		if(!(p.iters%1000) && p.iters>p.burn_in)
		{
			rec_PAC_in_LA(fla, pp, p);
			rec_PAC_in_RA(fra, pp, p);
		}
		
		if(p.iters>p.burn_in && !(p.iters%p.rec_lambda))
//            if(p.iters>p.burn_in && p.iters*1.0/p.rec_lambda == p.iters/p.rec_lambda)
		{
			rec_num(fnum,p);
			
			rec_intensity(pp, p);
			
			rec_centers(fx, p,idx);
			
			rec_id_study(fstudy, pp, p);
			rec_id_contrast(fcontrast, pp, p);
			
			
			rec_Amygdala(fcount, p,pp);
			
			
			
			
			if (rec_int==1)
			{
				sprintf(curvol_intensity, "%s_curvol_%d.txt", savename, p.iters);
				write_curvol(curvol_intensity, pp, p);
			}
			
			
			if (model_check ==1)
			{
				rec_pred_intensity(pp, p, seed);
				simAllPACs(pp, p, seed);
				compute_diff_Lfun(rstart, rend, rnum, pp, p, seed);
				if(save_sPACs==1)
				{
					sprintf(sim_file, "%s_simPACs_%d.txt",savename,p.iters);
					write_sPACs(sim_file, pp, p);
				}
				sprintf(diffLfun_file, "%s_diffLfun_%d.txt", savename, p.iters);
				write_diff_Lfun(diffLfun_file, pp, rnum);
			}
		}
		
		printf("\n %d", p.N0);
		for(int k=0; k<p.n; k++)
			printf(" %d",p.Num[k]);
		
		printf("\n");
		
		
		
	}
	
	printf("Writing intensity functions ...");
	
	write_vol(vol_intensity, pp, p);
	write_pred_vol(pred_int_name, pp, p);
	write_margin(intense_file, pp, p);
	printf("Finished! \n");
	
	//save_seed(seed,"seed.dat");
	free(seed);
	mat_free(S,DIM);
	free(tp);
	free(Z_tp);
	free(in_V);
	free(p.xi_all_alpha);
	
	
	free_pars(p);
	free_points(pp);
	
	fclose(fx);
	fclose(fx1);
	fclose(fpar);
	fclose(fsigma);
	fclose(fnum);
	fclose(fstudy);
	fclose(fcontrast);
	fclose(fZ);
	fclose(fZnum);
	fclose(fZall);
	fclose(fSS0);
	fclose(fcount);
	fclose(fra);
	fclose(fla);
	fclose(fnum_Z00);
	fclose(fnum_Z01);
	fclose(fnum_Z1);
	fclose(fxi);
	fclose(frho);
	fclose(fbeta);
}


void BHMCCP5(int in_total_iters, int in_adj_acpt, 
			 int in_burn_in, int in_rec_lambda,
			 double a_beta, double b_beta,  
			 double a_theta,  double a_eps, 
			 int in_df_S, int in_df_S0, 
			 int in_df_T, 
			 double in_var_Sigma, double in_var_S0, 
			 double rstart, double rend, int rnum, 
			 const char* datafile, 
			 const char* savename,
			 int rec_int, 
			 int model_check,
			 int save_sPACs)
{
	unsigned long * seed = initial_seed("seed.dat");
	double *in_V = vec_alloc(2);
	double **S = mat_alloc(DIM);
	char x_file[100];
	char x_file1[100];
	char sigma_file[100];
	char num_file[100];
	char par_file[100];
	char intense_file[100];
	char setting_file[100];
	char vol_intensity[100];
	char contrast[100];
	char study[100];
	char Zpoints[100];
	char Znum[100];
	char Zall[100];
	char SS0[100];
	char count[100];
	char ra[100];
	char la[100];
	char curvol_intensity[100];
	char sim_file[100];
	char diffLfun_file[100];
	char num_Z00_file[100];
	char num_Z01_file[100];
	char num_Z1_file[100];
	char xi_file[100];
	char rho_file[100];
	char beta_file[100];
	char seedname[100];
	char pred_int_name[100];
    char region_int_name[1000];
    char region_popctr_name[1000];
	
	kiss(seed);
	
	sprintf(num_Z00_file,"%s_num_Z00.txt",savename);
	sprintf(num_Z1_file,"%s_num_Z1.txt",savename);
	sprintf(num_Z01_file,"%s_num_Z01.txt",savename);
	sprintf(xi_file,"%s_rho.txt",savename);
	sprintf(rho_file,"%s_eta.txt",savename);
	sprintf(beta_file,"%s_beta.txt",savename);
	
	sprintf(seedname, "%s_seed.txt",savename);
	save_seed(seed, seedname);
	
	
	printf("seed = \n");
	printf("%lu %lu %lu\n",seed[0],seed[1],seed[2]);
	
	
	strcpy(ra, savename);
	strcat(ra, "_Ramygdala.txt");
	
	strcpy(la, savename);
	strcat(la, "_Lamygdala.txt");
	
	strcpy(count, savename);
	strcat(count, "_amygcount.txt");
	
	strcpy(Znum, savename);
	strcat(Znum, "_Znum.txt");
	
	strcpy(Zall, savename);
	strcat(Zall,"_Zall.txt");
	
	strcpy(Zpoints, savename);
	strcat(Zpoints,"_Zpoints.txt");
	
	strcpy(contrast,savename);
	strcat(contrast,"_contrast.txt");
	
	strcpy(study, savename);
	strcat(study,"_study.txt");
	
	strcpy(vol_intensity, savename);
	strcat(vol_intensity, "_vol.txt");
	
	strcpy(pred_int_name, savename);
	strcat(pred_int_name, "_pred_vol.txt");
	
	strcpy(curvol_intensity, savename);
	strcat(curvol_intensity, "_curvol");
	
	strcpy(intense_file, savename);
	strcat(intense_file, "_intensity");
	
	strcpy(x_file, savename);
	strcat(x_file, "_x.txt");
	
	strcpy(x_file1, savename);
	strcat(x_file1, "_x1.txt");
	
	strcpy(sigma_file, savename);
	strcat(sigma_file, "_sigma.txt");
	
	strcpy(SS0, savename);
	strcat(SS0, "_SS0.txt");
	
	strcpy(num_file, savename);
	strcat(num_file, "_num.txt");
	
	strcpy(par_file, savename);
	strcat(par_file, "_results.txt");
	
	strcpy(setting_file, savename);
	strcat(setting_file, "_setting.txt");
    
    
    strcpy(region_int_name,savename);
    strcat(region_int_name,"_region_int.txt");
    
    strcpy(region_popctr_name,savename);
    strcat(region_popctr_name,"_region_popctr.txt");
    
    
	
	FILE* fx = fopen(x_file, "wt");
	FILE* fx1 = fopen(x_file1,"wt");
	FILE* fsigma = fopen(sigma_file,"wt");
	FILE* fnum = fopen(num_file,"wt");
	FILE* fpar = fopen(par_file, "wt");
	FILE* fcontrast = fopen(contrast,"wt");
	FILE* fstudy = fopen(study,"wt");
	FILE* fZ = fopen(Zpoints, "wt");
	FILE* fZnum = fopen(Znum, "wt");
	FILE* fZall = fopen(Zall, "wt");
	FILE* fSS0 = fopen(SS0,"wt");
	FILE* fcount = fopen(count, "wt");
	FILE* fra = fopen(ra,"wt");
	FILE* fla = fopen(la,"wt");
	FILE* fnum_Z00 = fopen(num_Z00_file,"wt");
	FILE* fnum_Z01 = fopen(num_Z01_file,"wt");
	FILE* fnum_Z1  = fopen(num_Z1_file,"wt");
	FILE* fxi = fopen(xi_file,"wt");
	FILE* frho = fopen(rho_file,"wt");
	FILE* fbeta = fopen(beta_file,"wt");
	
	fprintf(fpar,"iteration Birth/Death numOfCluster    m       mp        N0        npacs       theta           eps    rho    totalBirthRate                 totalDeathRate          acceptRatio      phi0  phi1 birthnum deathnum\n");
	
	FILE *fid = fopen(setting_file, "wt");
	in_V[0] = 1.00;
	in_V[1] = 1.00;
	
	points pp = initial_points();
	read_mask("brainmask.nii", pp);
	read_amygdala(pp);
	//read_points1(datafile,pp);
    read_points2(datafile,pp);
    

	
	pars p = initial_pars3(in_total_iters, in_adj_acpt, in_burn_in, in_rec_lambda,
						   in_V, 2, a_beta, b_beta, a_theta, a_eps, in_df_S, in_df_S0,
						   in_df_T, in_var_Sigma, in_var_S0, pp.vol);
    
    initial_regionMask(pp, "rBucknerlab_7clusters_SPMAnat_Other_combined");
    
    pp.numOfIntensity = (p.total_iters - p.burn_in)/2;
    
    initial_regionIntensity(pp);
    
    

    
	
	p.xi_all_alpha = vec_alloc(pp.n_contrast+1);
	
	double sumxi =0;
	
	// initial xi
	for(int i=0; i<pp.n_contrast; i++)
	{
		p.xi_all_alpha[i] = 0.5;
		pp.xi[i] = 0.5;
		sumxi += pp.xi[i];
		
		pp.rho_all[i] = p.rho;
	}
	
	p.xi_all_alpha[pp.n_contrast] = pp.n_contrast*p.xi_alpha;
	pp.xi[pp.n_contrast] = p.xi_all_alpha[pp.n_contrast];
	
	for(int i=0; i<pp.n_contrast+1; i++)
		pp.xi[i] /= sumxi;
	
	
	
	save_pars(fid, p, pp);
	fclose(fid);
	
	
	
	printf("m = %d\n", pp.m1);
	
	double *tp = vec_alloc(pp.m1);
	double *Z_tp = vec_alloc(pp.m1);
	//int idx = 0;
	pp.numOfBirth = 0;
	pp.numOfDeath = 0;
	
	Z2Y(pp);
    

    
    pp.numOfIntensity = 0;
	
	for(int i=0; i<p.total_iters; i++)
	{
		
		p.iters = i;
		
		
		if(!(p.iters%100))
		{
			pp.xi_acpt = 0;
		}
        
        if(!(p.iters%50))
        {
            printf("\n\n%d | %d %d %d %d %.6lf | %.6lf %.6lf %.6lf| ", 
                   i, p.n, pp.m, p.N0, pp.m_p,pp.npacs, p.theta, p.eps, p.beta);
  
  
        
		for(int j=0;j<5; j++)
			printf("%.6lf ", pp.rho_all[j]);
		printf("| ");
		for(int j=0;j<5; j++)
			printf("%d ", pp.c_num[j]);
		printf("| ");
		for(int j=0;j<5; j++)
			printf("%d ", pp.Z0_n[j]);
		printf("| ");
		for(int j=0;j<5; j++)
			printf("%d ", pp.Zg_n[j]);
		
		
		printf("| ");
		for(int j=0;j<5; j++)
			printf("%.6lf ", pp.xi[j]);
		
		printf("| %d", pp.xi_acpt);
            
        printf(" %d %d\n", pp.numOfBirth, pp.numOfDeath);
		
        printf("\n %d", p.N0);
        for(int k=0; k<p.n; k++)
            printf(" %d",p.Num[k]);
            
        printf("\n");

		
		fflush(stdout);
		
		}
        
		
		Z_approx_tprob(Z_tp, pp,p,seed,SIMUL);
		Z_spatial_birth_death(Z_tp, pp,p,10,seed);
		Z_move_step(pp, p, seed);
		
		
		
		approx_tprob(tp, pp, p, seed, SIMUL);
		spatial_birth_death(tp,pp,p,10,seed);
		
	    move_step(pp,p,seed);
		
		
		

		
		
		
		//update_kappa(pp, p, seed);
		
		
		
		//update_S(p, seed);
		//update_beta(p, pp, seed);
		
		
		
		
		/* if(!(p.iters%1000) && p.iters>p.burn_in)
         {
         rec_PAC_in_LA(fla, pp, p);
         rec_PAC_in_RA(fra, pp, p);
         } */
		
        
        //save region intensity
        if (p.iters>=p.burn_in && p.iters%2 ==0) {
            compute_regionIntensity(pp, p);
        }
        
        
		
		if(p.iters>p.burn_in && !(p.iters%p.rec_lambda))
        
//		if(p.iters>p.burn_in && p.iters*1.0/p.rec_lambda == p.iters/p.rec_lambda)
		{
			/* rec_num(fnum,p);
             
             rec_intensity(pp, p);
             
             rec_centers(fx, p,idx);
             
             rec_id_study(fstudy, pp, p);
             rec_id_contrast(fcontrast, pp, p);
             
             
             rec_Amygdala(fcount, p,pp);
             */
			rec_intensity(pp, p);
			rec_pars(fpar, p, pp);
			//rec_Z(fZ,pp,p);
			//rec_numZ(fZnum, pp, p);
			//rec_Zall(fZall, pp, p);
			rec_S(fSS0,p);
			//rec_num_Z00(fnum_Z00,pp,p);
			//rec_num_Z01(fnum_Z01,pp,p);
			//rec_num_Z1(fnum_Z1, pp, p);
			rec_xi(fxi,pp,p);
			rec_rho(frho,pp,p);
			rec_beta(fbeta, pp, p);
			
			rec_centers1(fx1,p);
			rec_Sigma(fsigma, p);
			
			
			
			if (rec_int==1)
			{
				sprintf(curvol_intensity, "%s_curvol_%d.txt", savename, p.iters);
				write_curvol(curvol_intensity, pp, p);
			}
			
			
			if (model_check ==1)
			{
				rec_pred_intensity(pp, p, seed);
				simAllPACs(pp, p, seed);
				compute_diff_Lfun(rstart, rend, rnum, pp, p, seed);
				if(save_sPACs==1)
				{
					sprintf(sim_file, "%s_simPACs_%d.txt",savename,p.iters);
					write_sPACs(sim_file, pp, p);
				}
				sprintf(diffLfun_file, "%s_diffLfun_%d.txt", savename, p.iters);
				write_diff_Lfun(diffLfun_file, pp, rnum);
			}
		}
		
		
		
		
	}
	

	
    printf("Writing intensity functions ...");
    write_regionIntensity(region_int_name,pp);
    write_regionPopCtr(region_popctr_name, pp);
    
	write_vol(vol_intensity, pp, p);
	write_pred_vol(pred_int_name, pp, p);
	write_margin(intense_file, pp, p);
	printf("Finished! \n");
	
	//save_seed(seed,"seed.dat");
	free(seed);
	mat_free(S,DIM);
	free(tp);
	free(Z_tp);
	free(in_V);
	free(p.xi_all_alpha);
	
	free_regionIntensity(pp);
    free_regionMask(pp);
	free_pars(p);
	free_points(pp);
	
	fclose(fx);
	fclose(fx1);
	fclose(fpar);
	fclose(fsigma);
	fclose(fnum);
	fclose(fstudy);
	fclose(fcontrast);
	fclose(fZ);
	fclose(fZnum);
	fclose(fZall);
	fclose(fSS0);
	fclose(fcount);
	fclose(fra);
	fclose(fla);
	fclose(fnum_Z00);
	fclose(fnum_Z01);
	fclose(fnum_Z1);
	fclose(fxi);
	fclose(frho);
	fclose(fbeta);
}



int main (int argc, char * const argv[]) 
{
    
    /*int* dim = (int*)malloc(3*sizeof(int));
    
    MY_DATATYPE16*** imgdat = read_mask_img("rBucknerlab_7clusters_SPMAnat_Other_combined", dim);
    
    
    //print_mask_img(imgdat, dim, 37);
    
    double minvalue = 100, maxvalue = 0;
    for (int i=0; i<dim[0]; i++) {
        for (int j=0; j<dim[1]; j++) {
            for(int k=0; k<dim[2]; k++){
                if (maxvalue<imgdat[i][j][k]) {
                    maxvalue = imgdat[i][j][k];
                }
                if (minvalue>imgdat[i][j][k]) {
                    minvalue = imgdat[i][j][k];
                }
            }
        }
    }
    
    
    printf("Range = (%4.2f %4.2f)\n",minvalue,maxvalue);
    

    
    print_mask_img_xyz(imgdat, dim, 41, 58, 37);
    print_mask_img_xyz(imgdat, dim, 45, 58, 37);
    
    free_mask_img(imgdat, dim);
    
    
    
    
    free(dim);*/
    
    //runmodel arguments: savename dataname parametername
    
    
	
	printf("Meta-Analysis via hierarchical weighted cox processes\n");
	time_t start,end;
	unsigned long hours,mins,seconds,diff;
	
	time(&start);
    
	int in_total_iters, in_adj_acpt, in_burn_in, in_rec_lambda, rec_int, model_check;
	double a_beta, b_beta, a_theta, a_eps;
	int in_df_S, in_df_S0, in_df_T, rnum;
	double in_var_Sigma, in_var_S0, rstart, rend;
	char tmpstr[100];
	char savename[100];
	char command[100];
	char datafile[100];
    
    
	FILE* fid;
    
	sprintf(command, "mkdir simresults");
	system(command);
    
	sprintf(command, "mkdir simresults/%s",argv[1]);
	system(command);
    
	sprintf(command, "cp %s simresults/%s/%s_newpars.txt",argv[3],argv[1],argv[1]);
	system(command);
    
	sprintf(savename, "simresults/%s/%s",argv[1],argv[1]);
    
    printf("pars name %s\n",argv[3]);
    
	fid = fopen(argv[3], "r");
    
	fscanf(fid, "%s %d\n", tmpstr, &in_total_iters);
	fscanf(fid, "%s %d\n", tmpstr, &in_adj_acpt);
	fscanf(fid, "%s %d\n", tmpstr, &in_burn_in);
	fscanf(fid, "%s %d\n", tmpstr, &in_rec_lambda);
	fscanf(fid, "%s %lf\n", tmpstr, &a_beta);
	fscanf(fid, "%s %lf\n", tmpstr, &b_beta);
	fscanf(fid, "%s %lf\n", tmpstr, &a_theta);
	fscanf(fid, "%s %lf\n", tmpstr, &a_eps);
	fscanf(fid, "%s %d\n", tmpstr, &in_df_S);
	fscanf(fid, "%s %d\n", tmpstr, &in_df_S0);
	fscanf(fid, "%s %d\n", tmpstr, &in_df_T);
	fscanf(fid, "%s %lf\n", tmpstr, &in_var_Sigma);
	fscanf(fid, "%s %lf\n", tmpstr, &in_var_S0);
	fscanf(fid, "%s %lf\n", tmpstr, &rstart);
	fscanf(fid, "%s %lf\n", tmpstr, &rend);
	fscanf(fid, "%s %d\n", tmpstr, &rnum);
	
    
	printf("Total iterations: %d\n", in_total_iters);
	printf("Burn-in: %d\n", in_burn_in);
	
	
	printf("b_beta = %lf\n",b_beta);
	fclose(fid);
	
	sprintf(datafile,"%s",argv[2]);
    
    
	rec_int = 0;
	model_check = 0;
	int save_sPACs = 0;
	if (argc>=5) {
		rec_int = atoi(argv[4]);
	}
	if (argc>=6) {
		model_check = atoi(argv[5]);
	}
	if (argc>=7)
	{
		save_sPACs = atoi(argv[6]);
	}
    
    printf("argc = %d\n",argc);
    printf("rec_int = %d\n",rec_int);
    printf("model_check = %d\n",model_check);
    printf("save_sPACs = %d\n",save_sPACs);
    
    
    points pp = initial_points();
    initial_regionMask(pp, "rBucknerlab_7clusters_SPMAnat_Other_combined");
	initial_regionIntensity(pp);
    
    for (int i=0; i<pp.numOfregion; i++) {
        printf("Region[%d] = %d\n",i,pp.regionCount[i]);
    }
	
	BHMCCP5(in_total_iters, in_adj_acpt,
			in_burn_in, in_rec_lambda,
			a_beta, b_beta,  
			a_theta,a_eps, 
			in_df_S, in_df_S0, 
			in_df_T, 
			in_var_Sigma, in_var_S0, 
			rstart, rend, rnum, 
			datafile, 
			savename,
			rec_int, 
			model_check,
			save_sPACs);
    
    
	
	
	time(&end);
	
	diff = end-start;
	hours = diff/3600;
	mins =(diff-3600*hours)/60;
	seconds = (diff-3600*hours-60*mins);
	
	printf("Time elapsed: %ld hours %ld mins %ld seconds\n",hours,mins, seconds);
    
	
	return 0;
}


