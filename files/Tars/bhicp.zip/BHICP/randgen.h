#ifndef _RANDGEN_H_
#define _RANDGEN_H_

#include <stdlib.h>
#include <math.h>
#include <stdio.h>
/*#include <sys\timeb.h>*/

extern double M; /* exp(-32*log(2.0))*/

//initialize seed from a seed file
unsigned long * initial_seed(const char *seedfile);


//initialize seed by given 3 integers
unsigned long * initial_seed(unsigned long u0,unsigned long u1,unsigned long u2);


//save seed
void save_seed(unsigned long* seed, const char* filename);



double kiss(unsigned long *seed);


int runiform_n(int n,unsigned long *seed);


void permute_sample(double *v,int len,unsigned long *seed); 


void permute_sample_int(int *v,int len,unsigned long *seed); 


//inline 
long rmultinomial(double *prob,long len,unsigned long *seed);



//inline 
double runif_atob(unsigned long *seed,double a,double b);



double rexp(double beta,unsigned long *seed);


double sgamma(double a,unsigned long* seed);



double fsign( double num, double sign );



double snorm(unsigned long *seed);



double rnorm(double mean,double stdev,unsigned long *seed);


double rgamma(double alpha,double beta,unsigned long *seed);


double rinverse_gamma(double alpha,double beta,unsigned long *seed);

double fact_ln(int k);


int rpois(double lambda,unsigned long *seed);


double *rdirichlet(double *alpha,int len,unsigned long *seed);


double rbeta(double alpha,double beta,unsigned long *seed);


double rchisq(int n, unsigned long* seed);

#endif //_RANDGEN_H_
