#ifndef _WEIGHTED_COX_H_
#define _WEIGHTED_COX_H_

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "randgen.h"
#include "cholesky.h"
#include "MatVec.h"
#include "Mnormal.h"
#include "nifti1.h"

typedef unsigned char MY_DATATYPE;
typedef float MY_DATATYPE16;

#define DIM 3
#define MAX_N 100 //the maximum number of X
#define SIMUL 500
#define THRESH 4.5
#define TRUNC_PROB 0.99
#define MASK_THRESH 200
#define MIN_HEADER_SIZE 348
#define Z_MAX 100 // the maximum number of points in Z_i
#define SIM_MAX 500// the maximum number of simulated points per study
#define R_MAX 50// the maximum number of r's for difference of L 



typedef struct{
	//Pars for simulation
	int iters;
	int total_iters;
	int adj_acpt;
	int rec_lambda;
    int rec_intensity;
	int burn_in; 

	
	
	//Pars for weights
	double* phi;
	double* V; // the values that weight can take
	int V_n;
	
	
	//Pars for eps and theta
	double eps;
	double theta;
	double rho;
	double xi;
	double alpha_rho;
	double beta_rho;
	double beta;
	double a;
	double b;

	double alpha0;
	double beta0;
	double sgm0;
	double acpt0;
	double alpha1;
	double beta1;
	double sgm1;
	double acpt1;
	
	double xi_sgm;
	double xi_alpha;
	double*xi_all_alpha;
	double xi_beta;
	
	
	int numOfBirth;
	int numOfDeath;
	
	double mu;
	double totalBirthRate;
	double birth_acpt;
	double death_acpt;
	double totalDeathRate;

	double radius2;
	
	int BorD;
	FILE* temp_fid;
	FILE* results_fid;
	

	//Pars for X and Sigma
	double** X;//vector list
	double*** Sigma;//matrix list
	double*** SigmaInv; //matrix list
	int n;//number of X
	double** S; //Scale matric for Sigma 
	double** S0;//Scale matrix for Lambda
	double** invS;
	double** invS0;
	double** invT;
	double** invT0;
	double** T;
	double** T0;
	double** norm_prob;
	int* update_indicator;
	int* Num;
	int* studyNum;
	int* contrastNum;
	int N0;
	int df_T;
	int df_S;
	int df_S0;
	int df_T0;
	
	
	int num_children;
	int cutnumber;
} pars;

typedef struct {
	double**dat;
	double***sPACs;
	double*sW;
	
	double** diffLfun;
	
	int*sWid;
	double***matZ;
	int* numZ;
    double* Z_tB;
	double* Z_tD;
	double** Z_norm_prob;
	double* Z_mu;
	double** dnorm_list;
	double* lambda_list;
	double* slambda_list;
	double*** Z_dnorm_list;
	double** Z_lambda_list;
	double* xi;
	double* rho_all;
	int xi_acpt;
	
	int* numsPACs;
	
	int** Z_kappa;
	//int* Zvec_kappa;
	int** Z_n;
	int* Z0_n;
	int* Zg_n;
	int* Y_n;
	double**** Lambda;//covariance matrix list for Z
	double**** invLambda; 
	double** Y;
	double* W;
	double* W1;
	double* WM;
	int* kappa;
	int* W_id;
	int* W1_id;
	int* study;
	int* study1;
	int** id_study;
	int* s_id;
	int* c_num;
	int* s_num;
	int* contrast;
	int* contrast1;
	int* Zi;
	int* Zj;
	int** idx_Y;
	
	int* la_id;
	int* ra_id;
	int n_la;
	int n_ra;
	
	int** id_contrast;
	int* c_id;
	int m;
	int m1; // data dimension
	int m_p; // num of parents 
	int n_study;
	int n_contrast;

	int* dim;
	MY_DATATYPE*** mask;	
	MY_DATATYPE*** Lamygdala;
	MY_DATATYPE*** Ramygdala;
    MY_DATATYPE16*** regionmask;
	double vol;
	
	double*** intensity;
	double*** pred_intensity;
	double*** curint;
	int num_intense;
	int num_pred_int;
	int intval_intense;
	
	double npacs;
	
	int numOfBirth;
	int numOfDeath;
	
	double* orgin;
    
    double** regionIntensity;
    int* regionCount;
    
    
    int numOfregion;
    int numOfIntensity;
    
    int** popCtrRegionCount;
	
} points;


typedef struct {
	MY_DATATYPE*** L;
	MY_DATATYPE*** R;
} Amygdala;


points initial_points();


pars initial_pars1(int in_total_iters,int in_adj_acpt,  int in_burn_in,  
				   int in_rec_lambda,
				  double* in_V, int in_V_n, 
				  int in_n,  int in_m,  
				 double in_xi, double in_tau_xi, double in_xi_sgm, 
				  double in_rho, double in_tau_rho,
				  double in_eta, double in_tau_theta, double in_tau_eps,
				   double in_sgm0, double in_sgm1,
				  int in_df_S, int in_df_S0, 
				   int in_df_T, int in_df_T0,
				   double in_var_Sigma, double in_var_S0, double in_radius,
				   double in_vol, int num_children);

pars initial_pars2(int in_total_iters,int in_adj_acpt,  int in_burn_in,  
				   int in_rec_lambda,
				   double* in_V, int in_V_n, 
				   int in_n,  int in_m,
				   double in_xi, double in_tau_xi, double in_xi_sgm, 
				   double in_rho, double in_tau_rho,
				   double a_theta, double b_theta,   
				   double a_eps, double b_eps,
				   double in_sgm0, double in_sgm1,
				   int in_df_S, int in_df_S0, 
				   int in_df_T, int in_df_T0,
				   double in_var_Sigma, double in_var_S0, double in_radius,
				   double in_vol, int num_children,int cutnumber);

pars initial_pars3(int in_total_iters,int in_adj_acpt,  int in_burn_in,  
				   int in_rec_lambda,
				   double* in_V, int in_V_n, 
				   double a_beta, double b_beta,
				   double a_theta, double a_eps,
				   int in_df_S, int in_df_S0, 
				   int in_df_T, 
				   double in_var_Sigma, double in_var_S0, double in_vol);



void free_points(points &pp);

void free_pars(pars &p);

void read_points(const char* pointsfile, points &pp);

void read_points1(const char* pointsfile, points &pp);

MY_DATATYPE16* read_img(const char* data_file, int* dim);

MY_DATATYPE* read_nii(const char* data_file, int* dim);


void read_matlab_mask(const char* maskfile, points &pp);

void read_mask(const char* maskfile, points &pp);

void read_amygdala(points &pp);

double* tprob(points &pp, pars &p,unsigned long* seed, int iters);

void ttprob(double *tp, points &pp, pars &p,unsigned long* seed, int iters);

int prob_region(points &pp, double* eigen_value, double* eigen_vector, double*X, double thresh);

void approx_tprob(double *tp, points &pp, pars &p, unsigned long* seed, int iters);

double birth_rate_T(double *prob, points &pp, pars &p, double* tp);

double mat_det(double ** X, int size);

void mat_k(double **X, double k);

double mat_trace(double** X, int size);

double** mat_inv(double** X, int size);

void mat_inv3(double**invA,double** a);

void mat_t_vec(double* v1, double**A, double*v);

double** mat_multiply(double ** X, double ** Y, int size);

void mat_mul(double** result, double** X, double ** Y, int size);

void mat_times_vec(double* res, double** mat, double*vec, int size);

void mat_plus(double** result, double**X, double**Y, int size);

void vec_plus(double*v3, double*v1, double*v2);

void mat_inverse(double** result, double**X, int size);

//Density function of invWishart Distribution 
double dinvWishart(double** Sigma, double** S, int size, int df);

void update_dnormlist(points &pp, pars &p);

void add_dnormlist(points &pp, pars &p);

void rm_dnormlist(int idx, points &pp, pars &p);

double death_rate_T(double* prob, points &pp, pars &p,unsigned long* seed);

void rinverse_wishart(double** results, double** S, int df,unsigned long* seed);

int give_a_birth(double *prob, points &pp, pars &p,unsigned long* seed);

double birth_rate(double *prob, double**Sigma,points &pp, pars &p, unsigned long *seed,int iters);

void rm_centers(int idx, pars &p, points &pp);

void spatial_birth_death(double *tp, points &pp, pars &p, int steps, unsigned long* seed);

void spatial_birth_death_1(double *tp, points &pp, pars &p, int steps, unsigned long* seed);


int birth_death(double* tp, points &pp, pars &p, unsigned long* seed);

int update_kappa(points &pp, pars &p, unsigned long *seed);

void rec_Amygdala(FILE* fid, pars &p, points &pp);

void nporb_cal(points &pp, pars &p, unsigned long* seed);

void update_nprob(int i, points &pp, pars &p, unsigned long* seed);

void mu_cal(points &pp, pars &p, unsigned long* seed);

void update_Sigma(points &pp, pars &p, unsigned long* seed);

void update_X(points &pp, pars &p, unsigned long* seed);

void adjust_acceptance(double accept,double &sgm);

int update_eps(points &pp, pars &p, unsigned long* seed);

int update_theta(points &pp, pars &p, unsigned long* seed);

int update_theta1(points &pp, pars &p, unsigned long* seed);

void update_phi(points &pp, pars &p, unsigned long* seed);

void update_S(pars &p, unsigned long* seed);

void update_beta(pars &p, points &pp, unsigned long* seed);

void cut_centers(pars &p, int cut_num);

void cut_centers1(points &pp,pars &p);

int move_step(points &pp, pars &p, unsigned long* seed);

//Do not update theta
int move_step1(points &pp, pars &p, unsigned long* seed);

//The intensity function of the cox process (integrate out weights)
double cox_lambda(double *y, pars &p);


int rec_intensity(points &pp, pars &p);

//Save intensity function
void write_vol(const char* filename, points &pp, pars &p);

void write_curvol(const char* filename, points &pp, pars &p);

void write_margin(const char* filename, points &pp, pars &p);

void write_pred_vol(const char* filename, points &pp, pars &p);

void bd_accept(int acptidx, pars &p);

//record the parameters
void rec_pars(FILE* fvol, pars &p, points &pp);

void rec_Z(FILE* fvol, points &pp, pars &p);

void rec_numZ(FILE *fvol, points &pp, pars &p);

void rec_PAC_in_LA(FILE *fid, points &pp, pars &p);

void rec_PAC_in_RA(FILE *fid, points &pp, pars &p);


void rec_id_study(FILE* fvol,points &pp, pars &p);

void rec_id_contrast(FILE* fvol, points &pp, pars &p);

void rec_centers(FILE* fvol, pars &p, int &idx);

void rec_centers1(FILE* fvol, pars &p);

void rec_Sigma(FILE* fvol, pars &p);

void rec_S(FILE* fvol, pars &p);

void rec_num(FILE* fvol, pars &p);

void rec_num_Z0(FILE *fvol, points&pp, pars &p);
void rec_num_Z1(FILE *fvol, points&pp, pars &p);
void rec_num_Z00(FILE *fvol, points&pp, pars &p);
void rec_num_Z01(FILE *fvol, points&pp, pars &p);

void rec_xi(FILE* fvol, points &pp, pars &p);
void rec_rho(FILE* fvol, points &pp, pars &p);
void rec_beta(FILE* fvol, points &pp, pars&p);


MY_DATATYPE16*** read_mask_img(const char*data_file,int* dim);
void free_mask_img(MY_DATATYPE16*** imgdat, int* dim);
void print_mask_img(MY_DATATYPE16*** imgdat, int*dim, int slide);

void print_mask_img_xyz(MY_DATATYPE16*** imgdat, int*dim, int x, int y, int z);

//save parameters
void save_pars(FILE* fid, pars &p, points &pp);


void initial_regionMask(points &pp,const char* regionmaskfile);
void initial_regionIntensity(points &pp);
void free_regionMask(points &pp);

void free_regionIntensity(points &pp);


void compute_regionIntensity(points &pp, pars &p);

void write_regionIntensity(const char* data_file, points &pp);

void write_regionPopCtr(const char* data_file, points &pp);

void read_points2(const char* pointsfile, points &pp);

#endif //_WEIGHTED_COX_H_

