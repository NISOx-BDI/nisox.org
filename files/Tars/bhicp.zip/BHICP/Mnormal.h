#ifndef _MNORMAL_H_
#define _MNORMAL_H_

#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include <Accelerate/Accelerate.h>

#include"cholesky.h"
#include"MatVec.h"
#include"randgen.h"


#define SIZE 3
#define SIZE2 9
#define INV_SQRT2PI3  0.063493635934241

//Multivariate Normal Density Function
double dmvnorm(double *x, double **a,int size_A,double *mean);

int eigen(double* eigen_vector, double* eigen_value, double**S); 

void eigen_print(double* eigen_vector, double* eigen_value);


double dmvnorm0(double *x, double **A,int size_A,double *mean);

//Multivariate Normal Density Function
double dmvnorm1(double *x, double **invA,int size_A,double *mean);
//inRange
int inRange(double*x,int size, unsigned char*** mask, int*range);

//Multivariate normal probability by Monte-Carlo Method
double pmvnorm(unsigned char***mask, int* range, double**A, int size, double *mean, int iters,unsigned long* seed);

//Generate Random Number from Multivariate T Distribution
int rmvt(double *result, double* mean, double **S, int size, int df, unsigned long* seed, int flag);

//Multivariate T probability
double pmvt(unsigned char***mask, int *range, double **S, int size, double *mean, int df, int iters, unsigned long* seed);


#endif //_MNORMAL_H_



