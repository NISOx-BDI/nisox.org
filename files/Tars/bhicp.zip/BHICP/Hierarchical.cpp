/*
 *  Hierarchical.cpp
 *  NewHWCox04
 *
 *  Created by Jian Kang on 4/6/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */



#include "Hierarchical.h"


void Z_approx_tprob(double *tp, points &pp, pars &p, unsigned long* seed, int iters)
{
	double**S0list = mat_copy(p.S0, DIM);
	double* eigen_value = vec_alloc(DIM);
	double* eigen_vector = vec_alloc(DIM*DIM);
	
	
	mat_times_k(S0list,DIM,1.0/(p.df_S0-2));
	eigen(eigen_vector, eigen_value, S0list); 
	
	for(int i=0; i<pp.n_contrast; i++)
	{
		for(int j=pp.c_id[i]; j<pp.c_id[i+1]; j++)
		{
			//mat_print(S0list, DIM, "%4.2f");
			//printf("%d\n",j);
			if (prob_region(pp, eigen_value, eigen_vector, pp.dat[j], THRESH)==1)
			{
				tp[j] = TRUNC_PROB;
			}
			else
			{
				tp[j] = pmvt(pp.mask,pp.dim,S0list,DIM,pp.dat[j],p.df_S0-2,iters,seed);
			}
		}
	}
	
	mat_free(S0list, DIM);
    free(eigen_value);
	free(eigen_vector);
}

void Z_birth_rate_T(int i, double **prob, points &pp, pars &p, double* tp)
{
	int j;
	
	//for(i=0; i<pp.n_contrast; i++)
	//{
	prob[i][0] = tp[pp.c_id[i]];
	for(j=pp.c_id[i]+1; j<pp.c_id[i+1]; j++)
		prob[i][j-pp.c_id[i]] = prob[i][j-pp.c_id[i]-1]+tp[j];
	
	pp.Z_tB[i] = pp.rho_all[i]*prob[i][pp.c_id[i+1]-pp.c_id[i]-1];
	
	for(j=pp.c_id[i]; j<pp.c_id[i+1]; j++)
		prob[i][j-pp.c_id[i]] /= prob[i][pp.c_id[i+1]-pp.c_id[i]-1];
	//}
	
}

void Z_update_slambdalist(points &pp, pars &p)
{
	double** Sigma = mat_alloc(DIM);
	for(int j=0; j<pp.m1; j++)
	{
		pp.slambda_list[j] = 0;
		for(int i=0; i<p.n; i++)
		{
			mat_copyval(Sigma, p.SigmaInv[i], DIM);
			mat_times_k(Sigma, DIM, pp.W1[j]);
			pp.slambda_list[j] += dmvnorm1(pp.dat[j], Sigma, DIM, p.X[i]);
		}
		pp.slambda_list[j] = p.eps + pp.slambda_list[j]*p.theta;
	}
	
	mat_free(Sigma, DIM);
}

void Z_update_dnormlist(int t, points &pp, pars &p)
{
	//double** Sigma = mat_alloc(DIM);
	
	for(int j=0; j<pp.c_num[t]; j++)
	{
		pp.Z_lambda_list[j][t] = 0;
		for(int i=0; i<pp.numZ[t]; i++)
		{
			//mat_copyval(Sigma, pp.invLambda[t][i], DIM);
			//mat_times_k(Sigma, DIM, pp.W1[j+pp.c_id[t]]);
			//pp.Z_dnorm_list[j][t][i] = dmvnorm1(pp.dat[j+pp.c_id[t]], Sigma, DIM, pp.matZ[t][i]);
			pp.Z_dnorm_list[j][t][i] = dmvnorm1(pp.dat[j+pp.c_id[t]], pp.invLambda[t][i], DIM, pp.matZ[t][i]);
			pp.Z_lambda_list[j][t] += pp.Z_dnorm_list[j][t][i];
		}
		pp.Z_lambda_list[j][t] = pp.xi[t]*pp.slambda_list[t] + pp.Z_lambda_list[j][t]*pp.rho_all[t];
	}
	//mat_free(Sigma, DIM);
}


void Z_add_dnormlist(int t, points &pp, pars &p)
{
	//double** Sigma = mat_alloc(DIM);
	
	for(int j=0; j<pp.c_num[t]; j++)
	{
		//mat_copyval(Sigma, pp.invLambda[t][pp.numZ[t]], DIM);
		//mat_times_k(Sigma, DIM, pp.W1[j+pp.c_id[t]]);
		//pp.Z_dnorm_list[j][t][pp.numZ[t]] = dmvnorm1(pp.dat[j+pp.c_id[t]], Sigma, DIM, pp.matZ[t][pp.numZ[t]]);			
		pp.Z_dnorm_list[j][t][pp.numZ[t]] = dmvnorm1(pp.dat[j+pp.c_id[t]], pp.invLambda[t][pp.numZ[t]], DIM, pp.matZ[t][pp.numZ[t]]);			
		pp.Z_lambda_list[j][t] += pp.rho_all[t]*pp.Z_dnorm_list[j][t][pp.numZ[t]];
	}
	
	
	//mat_free(Sigma, DIM);
}

void Z_rm_dnormlist(int t, int idx, points &pp, pars &p)
{
	for(int j=0; j<pp.c_num[t]; j++)
	{
		pp.Z_lambda_list[j][t] -= pp.Z_dnorm_list[j][t][idx]*pp.rho_all[t];
		pp.Z_dnorm_list[j][t][idx] = pp.Z_dnorm_list[j][t][pp.numZ[t]-1];
	}
}

void Z_death_rate_T(int t, double** Zprob, points &pp, pars &p,unsigned long* seed)
{
	double part1 = 0, part2 = 0, part3 = 0, part4=0;
	double* templist = vec_alloc(pp.m1);
	double temp, max_log_prob;
	//double** Sigma = mat_alloc(DIM);
	
	double* prob = vec_alloc(pp.m1);
	int flag = 0;
	
	pp.Z_tD[t] = 0.0;
	
	if(pp.numZ[t]>1)
	{
		
		for(int i=0; i<pp.numZ[t]; i++)
		{
		    part1 = pp.rho_all[t]*pmvnorm(pp.mask, pp.dim, pp.Lambda[t][i], DIM, pp.matZ[t][i], SIMUL, seed);
			
			flag = 0;
			
			part2 = 0.0;
			
			for(int j=0; j<pp.c_num[t]; j++)
			{
				temp = pp.rho_all[t]*pp.Z_dnorm_list[j][t][i]/(pp.Z_lambda_list[j][t] - pp.rho_all[t]*pp.Z_dnorm_list[j][t][i]);
				part2 += log1p(temp);
			}
			
			
			
			part3 = 0.0;
			for(int j=0; j<pp.c_num[t]; j++)
			{
				part3 += pp.Z_dnorm_list[j][t][i];
				//printf("dnorm: %4.2f ", dnorm_list[j][i]);
			}
			//printf("\n");
			if (part3>0)
				part3 = log(pp.rho_all[t]*part3);
			else
				flag = 2;
			
			
			part4 = 0;
			
			for(int l=0; l<p.n; l++)
			{
				//mat_copyval(Sigma, p.SigmaInv[l], DIM);
				//mat_times_k(Sigma, DIM, pp.W1[pp.c_id[t]]);
				//part4 += dmvnorm1(pp.matZ[t][i],Sigma,DIM,p.X[l]);
				part4 += dmvnorm1(pp.matZ[t][i],p.SigmaInv[l],DIM,p.X[l]);
			}
			
			
			part4 = log((part4*p.theta+p.eps)*pp.xi[pp.n_contrast]/pp.n_contrast);
			
			
			
			//printf("%4.6f %4.6f %4.6f %4.6f\n", part1,part2,part3,part4);
			if (flag == 0)
			{
     			prob[i] = part1-part2+part3-part4;
			}
			else if(flag == 1)
			{
				prob[i] = -1e100;
			}
			else
			{
				prob[i] = -1e100;
			}
			
		}
		
		for(int i=0; i<pp.numZ[t]; i++)
		{
			pp.Z_tD[t] +=  exp(prob[i]);
		}
		
		
		max_log_prob = prob[0];
		for(int i=1; i<pp.numZ[t]; i++)
		{
			if(max_log_prob < prob[i])
			{
				max_log_prob = prob[i];
			}
		}
		
		for(int i=0; i<pp.numZ[t]; i++)
		{
			prob[i] = exp(prob[i] - max_log_prob);
		}
		
		for(int i=1; i<pp.numZ[t]; i++)
			prob[i] += prob[i-1];
		
		
		for(int i=0; i<pp.numZ[t]; i++)
			prob[i] /= prob[p.n-1];
		
		for(int i=0; i<pp.numZ[t]; i++)
			Zprob[t][i] = prob[i];
		
	}
	
	
	free(templist);
	//mat_free(Sigma, DIM);
	free(prob);
	
}


void Z_give_a_birth(int t, double **prob, points &pp, pars &p,unsigned long* seed)
{
	int i = 0;
	double** Lambda = mat_alloc(DIM);
	double** tmpmat = mat_alloc(DIM);
	
	mat_copyval(tmpmat,p.S0, DIM);
	
	
	i = (int) rmultinomial(prob[t], pp.c_num[t], seed);
	
	rwishart(pp.Lambda[t][pp.numZ[t]], tmpmat, DIM, p.df_S0, seed);
	
	mat_inverse(pp.invLambda[t][pp.numZ[t]], pp.Lambda[t][pp.numZ[t]], DIM);
	
	
	
	/*mat_copyval(pp.Lambda[t][pp.numZ[t]], p.S0,DIM);
	 mat_inverse(pp.invLambda[t][pp.numZ[t]], pp.Lambda[t][pp.numZ[t]] , DIM);*/
	
	mat_copyval(Lambda, pp.Lambda[t][pp.numZ[t]], DIM);
	
	//printf("contrast : %d\n", t);
	//printf("num of z: %d\n", pp.numZ[t]);
	//printf("Lambda = \n");
	//mat_print(Lambda, DIM, " %.4f");
	
	
	rmvnorm(pp.matZ[t][pp.numZ[t]],Lambda, DIM, pp.dat[pp.c_id[t]+i], seed, 0);
	
	int flag = 1;
	
	/*for(int i=0; i<pp.numZ[t]; i++)
	 {
	 if(vec_dist(pp.matZ[t][i],pp.matZ[t][pp.numZ[t]],DIM)<p.radius2)
	 {
	 flag = 0;
	 break;
	 }
	 }*/
	
	if(inRange(pp.matZ[t][pp.numZ[t]], DIM, pp.mask, pp.dim) && pp.numZ[t]<pp.c_num[t] && flag==1)
	{
		Z_add_dnormlist(t, pp, p);
		pp.numZ[t] ++;
		//printf("Z_birth\n");
	}
	
	
	mat_free(Lambda,DIM);
	mat_free(tmpmat,DIM);
}



void Z_rm_centers(int t, int i, points &pp, pars &p)
{
	if (pp.numZ[t]>0)
	{
		for(int j=0; j<pp.c_num[t]; j++){
			if(pp.Z_kappa[t][j] == i)
				pp.Z_kappa[t][j] = -1;
			if(pp.Z_kappa[t][j] ==pp.numZ[t]-1 && pp.Z_kappa[t][j]!= i) {
				pp.Z_kappa[t][j] = i;
			}
			
		}
		mat_copyval(pp.invLambda[t][i], pp.Lambda[t][pp.numZ[t]-1], DIM);
		mat_copyval(pp.Lambda[t][i], pp.Lambda[t][pp.numZ[t]-1], DIM);
		mat_copyval(pp.invLambda[t][i], pp.invLambda[t][pp.numZ[t]-1], DIM);
		vec_copyval(pp.matZ[t][i], pp.matZ[t][pp.numZ[t]-1], DIM);
		pp.Z0_n[t] += pp.Z_n[t][i];
		pp.Z_n[t][i] = pp.Z_n[t][pp.numZ[t]-1];
		Z_rm_dnormlist(t, i, pp, p);
		pp.numZ[t]--;
		
	}
	
}

void Z_death_step(int t, double **prob, points &pp, pars &p, unsigned long* seed)
{
	int i=0;
	i = (int) rmultinomial(prob[t], pp.numZ[t], seed);
	Z_rm_centers(t, i, pp, p);
}



int Z_update_kappa(int t, points &pp, pars &p, unsigned long *seed)
{
	
	double* prob = vec_alloc(Z_MAX+1);
	double** Sigma = mat_alloc(DIM);
	
	//	for(int t =0; t<pp.n_contrast; t++)
	//	{
	if(pp.numZ[t]==0)
		return -1;
	
	
	for(int i=0; i<pp.numZ[t]; i++)
		pp.Z_n[t][i] = 0;
	
	pp.Z0_n[t] = 0;
	pp.Zg_n[t] = 0;
	
	
	for(int j=0; j<pp.c_num[t]; j++)
	{			
		
		prob[0] = pp.xi[t]*pp.slambda_list[j+pp.c_id[t]]; 
				
		for(int i=0; i<pp.numZ[t]; i++)
		{
			prob[i+1] = prob[i] + pp.rho_all[t]*pp.Z_dnorm_list[j][t][i];
		}
		
		pp.Z_kappa[t][j] = -1;
		
		if (prob[pp.numZ[t]]>0)
		{
			for(int i=0; i<pp.numZ[t]+1; i++)
			{
				prob[i] /= prob[pp.numZ[t]];
			}
		}
		else
		{
			prob[0] = 1.0/(pp.numZ[t]+1);
			for(int i=1; i<pp.numZ[t]+1; i++)
			{
				prob[i] = prob[i-1]+prob[0]; 
			}
		}
		
		
		//printf("%d %d %d\n", t, j, pp.numZ[t]+1);
		//vec_print(prob, pp.numZ[t]+1, " %.4f");
		pp.Z_kappa[t][j] = rmultinomial(prob, pp.numZ[t]+1, seed);
		//printf("%d\n",pp.Z_kappa[t][j]);
		pp.Z_kappa[t][j]--;
		
		
		if(pp.Z_kappa[t][j]>=0 && pp.Z_kappa[t][j]<pp.numZ[t])
		{
			pp.Z_n[t][pp.Z_kappa[t][j]] ++;
		}
		else
		{
			pp.Z0_n[t]++;
			if (kiss(seed)>p.eps/pp.slambda_list[j+pp.c_id[t]])
			{
				pp.Zg_n[t]++;
			}
		}
		
	}
	
	
	
	//printf("%d\n", t);
	//vec_print(pp.Z_n[t],pp.numZ[t]," %d");
	
	if(p.iters>=0)
	{
		int nn = pp.numZ[t];
		for(int i=nn-1; i>=0; i--)
		{
			if(pp.Z_n[t][i]<=p.num_children)
				Z_rm_centers(t, i, pp,p);
		}
	}
	
	//vec_print(pp.Z_n[t],pp.numZ[t]," %d");
	
	
	//update Z_n
	
	//for(int j=0; j<pp.c_num[t];j++)
	//	pp.Zvec_kappa[pp.c_id[t]+j] = pp.Z_kappa[t][j];
	
	
	
	free(prob);
	mat_free(Sigma, DIM);
	return 1;
}

void rec_Zall(FILE* fid, points &pp, pars &p)
{
	for(int i=0; i<pp.n_contrast; i++)
	{
		if(i<=5 || i==42 || i==115 || i==347 || i==351 || i==415)
		{
			for(int j=0; j<pp.numZ[i]; j++)
			{
				fprintf(fid,"%d %d %d ", p.iters, pp.Z_n[i][j],pp.contrast1[pp.c_id[i]]);;
				for(int k=0; k<3; k++)
				{
					fprintf(fid, "%.4lf ", pp.matZ[i][j][k]);
				}
				fprintf(fid,"%lf %lf %lf %lf %lf %lf",
						pp.Lambda[i][j][0][0],pp.Lambda[i][j][0][1],pp.Lambda[i][j][0][2],pp.Lambda[i][j][1][1],pp.Lambda[i][j][1][2],pp.Lambda[i][j][2][2]);
				fprintf(fid,"\n");
			}
		}
	}
	fflush(fid);
}


void Z2Y(points &pp)
{
	pp.npacs = 0;
	pp.m = 0;
	pp.m_p = 0;
	
	int *tempidx;
	
	for(int i=0; i<pp.n_contrast; i++)
	{
		if (pp.numZ[i]>0) 
		{
			tempidx = (int*)calloc(pp.numZ[i], sizeof(int));
			for(int j=0; j<pp.numZ[i]; j++)
			{
				vec_copyval(pp.Y[pp.m],pp.matZ[i][j],DIM);
				pp.Y_n[pp.m] = pp.Z_n[i][j];
				tempidx[j] = pp.m;
				pp.W[pp.m] = pp.W1[pp.c_id[i]];
				pp.contrast[pp.m] = pp.contrast1[pp.c_id[i]];
				pp.study[pp.m] = pp.study1[pp.c_id[i]];
				pp.W_id[pp.m] = pp.W1_id[pp.c_id[i]];
				
				pp.npacs += pp.Y_n[pp.m];
				pp.m++;
				pp.m_p++;
			}
		}
		
		for(int j=0; j<pp.c_num[i]; j++)
		{
			if(pp.Z_kappa[i][j]<0 || pp.Z_kappa[i][j]>=pp.numZ[i])
			{
				vec_copyval(pp.Y[pp.m],pp.dat[pp.c_id[i]+j],DIM);
				pp.Y_n[pp.m] = -1;
				pp.idx_Y[i][j] = pp.m;
				pp.W[pp.m] = pp.W1[pp.c_id[i]+j];
				pp.contrast[pp.m] = pp.contrast1[pp.c_id[i]+j];
				pp.study[pp.m] = pp.study1[pp.c_id[i]+j];
				pp.W_id[pp.m] = pp.W1_id[pp.c_id[i]+j];
				pp.m++;
			}
			else
			{
				pp.idx_Y[i][j] = tempidx[pp.Z_kappa[i][j]];
			}
		}
		if (pp.numZ[i]>0) 
			free(tempidx);
	}	
	
	if(pp.m_p>0)
		pp.npacs /= pp.m_p;
	
}



void Z_spatial_birth_death(double *tp, points &pp, pars &p, int steps, unsigned long* seed)
{
	double r;
	
	double** bprob = vec_list_alloc(pp.m1+1,pp.n_contrast);
	double** dprob = vec_list_alloc(Z_MAX, pp.n_contrast);
	double* T = vec_copy(pp.Z_tB,pp.n_contrast);
	double s=0;
	int k;
	
	Z_update_slambdalist(pp,p);
	
	
	for(int t=0; t<pp.n_contrast; t++)
	{
		
		Z_update_dnormlist(t, pp, p);
		Z_birth_rate_T(t,bprob, pp, p, tp);
		
		s = 0;
		k = 0;
		while(s <1.0/T[t] && k<steps)
		{
			//printf("Total Birth Rate: %.10f\n",pp.Z_tB[t]);
			//printf("Total Death Rate: %.10f\n",pp.Z_tD[t]);
			Z_death_rate_T(t, dprob, pp, p, seed);
			r = kiss(seed);
			if(r<pp.Z_tB[t]/(pp.Z_tB[t]+pp.Z_tD[t]))
			{
				Z_give_a_birth(t, bprob, pp, p, seed);
			}
			else
			{
				Z_death_step(t, dprob, pp,p,seed);
			}
			
			s += rexp(pp.Z_tB[t]+pp.Z_tD[t],seed);
			k++;
			
		}
		//printf("contrast %d, num = %d\n",t,pp.numZ[t]);
		
	}
	
	vec_list_free(bprob,pp.n_contrast);
	vec_list_free(dprob,pp.n_contrast);
	free(T);
}


void Z_update_S(points &pp, pars &p, unsigned long* seed)
{
	double** S0 = mat_copy(p.invT0,DIM);
	double** Sigma0 = mat_alloc(DIM);
	int df = 0;
	
	
	for(int t=0; t<pp.n_contrast; t++)
	{
		for(int i=0; i<pp.numZ[t]; i++)
		{
			mat_plus(S0, S0, pp.invLambda[t][i], DIM);
			df++;
		}
	}
	
	//printf("ZS0 = \n");
	//mat_print(S0, DIM, "%.4f ");
	double** Tn = mat_inv(S0, DIM);
	
	
	rwishart(p.S0, Tn, DIM, p.df_T0+df*p.df_S0, seed);
	mat_inverse(p.invS0, p.S0, DIM);
	
	//printf("Z_S0 = \n");
	//mat_print(p.S0, DIM,"%.4f ");
	
	mat_free(S0,DIM);
	mat_free(Sigma0, DIM);
	mat_free(Tn, DIM);
}

void Z_update_nprob(int t, int i, points &pp, unsigned long* seed)
{
	pp.Z_norm_prob[t][i] = pmvnorm(pp.mask,pp.dim, pp.Lambda[t][i], DIM, pp.matZ[t][i], SIMUL, seed); 
}

void Z_mu_cal(int t, points &pp, pars &p)
{	
	double temp = 0;
	for(int i=0; i<pp.numZ[t]; i++)
	{
		temp += pp.Z_norm_prob[t][i];
	}
	
    temp*=pp.rho_all[t];
	pp.Z_mu[t] = pp.xi[t]*p.mu + temp;
}



//Update Z
void Z_update_Z(int t, int Zidx, points &pp, pars &p, unsigned long* seed)
{
	double** meanDat = vec_list_alloc(DIM, Z_MAX);
	double** Sigma = mat_alloc(DIM);
	double* z = vec_alloc(DIM);
	double* tmpvec = vec_alloc(DIM);
	double**tmpmat = mat_alloc(DIM);
	double temp;
	double muOld = pp.Z_mu[t];
	int idx;
	
	for(int i=0; i<pp.numZ[t]; i++)
		for(int a=0; a<DIM; a++)
			meanDat[i][a] = 0;
	
	for(int j=0; j<pp.c_num[t]; j++)
		for(int a=0; a<DIM; a++)
		{
			if(pp.Z_kappa[t][j]>-1)
			{
			    meanDat[pp.Z_kappa[t][j]][a] += pp.dat[j+pp.c_id[t]][a];
			}
		}
	
	for(int i=0; i<pp.numZ[t]; i++)
	{
		if(pp.Z_n[t][i]<2)
			continue;
		
		for(int a=0; a<DIM; a++)
			meanDat[i][a] /= pp.Z_n[t][i];
		
		mat_copyval(Sigma, pp.invLambda[t][i], DIM);
		mat_times_k(Sigma, DIM, pp.Z_n[t][i]);
		
		if (p.n>0)
		{
			idx = Zidx+i;
			
			
			if (pp.kappa[idx]>-1)
			{
		        mat_times_vec(tmpvec, Sigma, meanDat[i], DIM);
				vec_copyval(meanDat[i], tmpvec, DIM);
				mat_copyval(tmpmat, p.SigmaInv[pp.kappa[idx]], DIM);
				mat_times_k(tmpmat,pp.W[idx],DIM);
				mat_times_vec(tmpvec, tmpmat, p.X[pp.kappa[idx]], DIM);
				vec_plus(tmpvec, meanDat[i], tmpvec);
				mat_plus(Sigma, Sigma, tmpmat,DIM);
				mat_inverse(tmpmat,Sigma,DIM);
				mat_times_vec(meanDat[i], tmpmat, tmpvec, DIM);
			}
			else
			{
				mat_inverse(tmpmat, Sigma, DIM);
			}
		}
		else
		{
			mat_inverse(tmpmat, Sigma, DIM);
		}
		
		
		
		vec_copyval(z, pp.matZ[t][i], DIM);
		rmvnorm(pp.matZ[t][i], tmpmat, DIM, meanDat[i], seed, 0);
		
		if(inRange(pp.matZ[t][i], DIM, pp.mask, pp.dim))
		{
			temp = pp.Z_norm_prob[t][i];
			Z_update_nprob(t, i, pp, seed);
			Z_mu_cal(t, pp, p);
			if(log(kiss(seed)) > pp.c_num[t]*log(muOld/pp.Z_mu[t]))
			{
				vec_copyval(pp.matZ[t][i], z , DIM);
				pp.Z_mu[t] = muOld;
				pp.Z_norm_prob[t][i] = temp;
			}
			else
			{
				muOld= pp.Z_mu[t];
			}
		}
		else
		{
			vec_copyval(pp.matZ[t][i], z, DIM);
		}
	}
	
	free(tmpvec);
	mat_free(Sigma,DIM);
	mat_free(tmpmat,DIM);
	vec_list_free(meanDat,Z_MAX);
	free(z);
}


//Update Lambda
void Z_update_Lambda(int t, points &pp, pars &p, unsigned long* seed)
{
	double** Lambda = mat_alloc(DIM);
	double** LambdaInv = mat_alloc(DIM);
	double** tmpmat = mat_alloc(DIM);
	double*** Lambda0list = mat_list_alloc(DIM, Z_MAX);
	double tempprob;
	double muOld = pp.Z_mu[t];
	
	for(int i=0; i<pp.numZ[t]; i++)
	{
		mat_copyval(Lambda0list[i], p.S0, DIM);
	}
	
	
	for(int j=0; j<pp.c_num[t]; j++)
	{
		for(int a=0; a<DIM; a++)
			for(int b=0; b<DIM; b++)
			{
				if (pp.Z_kappa[t][j]>-1)
				{
					Lambda0list[pp.Z_kappa[t][j]][a][b] += 
					(pp.dat[pp.c_id[t]+j][a]-pp.matZ[t][pp.Z_kappa[t][j]][a])
					*(pp.dat[pp.c_id[t]+j][b]-pp.matZ[t][pp.Z_kappa[t][j]][b]);
				}
			}
		
	}
	
	for(int i=0; i<pp.numZ[t]; i++)
	{
		if(pp.Z_n[t][i]<1)
			continue;
		
		
		mat_inverse(tmpmat, Lambda0list[i],DIM);
		mat_copyval(LambdaInv, pp.invLambda[t][i], DIM);
		rwishart(pp.invLambda[t][i], tmpmat, DIM, p.df_S0+pp.Z_n[t][i], seed);
		tempprob = pp.Z_norm_prob[t][i]; 
		mat_inverse(pp.Lambda[t][i], pp.invLambda[t][i], DIM);
		mat_copyval(Lambda, pp.Lambda[t][i],DIM);
		
		Z_update_nprob(t, i, pp, seed);
		Z_mu_cal(t, pp, p);
		
		
		if (log(kiss(seed))>pp.c_num[t]*log(muOld/p.mu))
		{
			mat_copyval(pp.invLambda[t][i], LambdaInv, DIM);
			mat_copyval(pp.Lambda[t][i],Lambda,DIM);
			pp.Z_mu[t] = muOld;
			pp.Z_norm_prob[t][i] = tempprob;
		}
		else
		{
			muOld = pp.Z_mu[t];
		}
	}
	
	mat_free(LambdaInv,DIM);
	mat_free(Lambda,DIM);
	mat_free(tmpmat,DIM);
	mat_list_free(Lambda0list, DIM, Z_MAX);
} 

int Z_update_xi(int t, points &pp, pars &p, unsigned long* seed)
{
	double xi_t = pp.xi[t];
	double muOld = pp.Z_mu[t];
	pp.xi[t] = xi_t + snorm(seed)*p.xi_sgm;
	
	if(pp.xi[t]<=0)
	{
		pp.xi[t] = xi_t;
		return 0;
	}
	
	Z_mu_cal(t, pp, p);
	if(log(kiss(seed))>pp.c_num[t]*log(muOld/pp.Z_mu[t])+(p.xi_alpha+pp.Z0_n[t])*log(pp.xi[t]/xi_t)-p.xi_beta*(pp.xi[t] - xi_t))
	{
		pp.xi[t] = xi_t;
		pp.Z_mu[t] = muOld;
		return 0;
	}
	return 1;
}


int Z_update_xi_all_1(points &pp, pars &p, unsigned long* seed)
{
	double* xi;// = vec_alloc(pp.n_contrast+1);
	double* muOld = vec_alloc(pp.n_contrast);
	double* num = vec_alloc(pp.n_contrast+1);
 	double temp;
	
	
	double acptratio = 0.0;
	
	
	xi = rdirichlet(p.xi_all_alpha, pp.n_contrast+1, seed);
	
	
	for(int t=0; t<pp.n_contrast+1; t++)
	{
		temp = pp.xi[t];
		pp.xi[t] = xi[t];
		xi[t] = temp;
	}
	
	for(int t=0; t<pp.n_contrast; t++)
	{
		muOld[t] = pp.Z_mu[t];
		Z_mu_cal(t, pp, p);
		acptratio += pp.c_num[t]*log(muOld[t]/pp.Z_mu[t])+pp.Z0_n[t]*log(xi[t]/pp.xi[t]);
	}
	
	
	if(log(kiss(seed))>acptratio)
	{
		for(int t=0; t<pp.n_contrast; t++)
		{
	     	pp.xi[t] = xi[t];
		    pp.Z_mu[t] = muOld[t];
		}
		pp.xi[pp.n_contrast] = xi[pp.n_contrast];
		free(num);
		free(muOld);
		free(xi);
		return 0;
	}
	
	pp.xi_acpt++;
	free(num);
	free(muOld);
	free(xi);
	return 1;
}


int Z_update_xi_all(points &pp, pars &p, unsigned long* seed)
{
	double* xi = vec_alloc(pp.n_contrast);
	double* muOld = vec_alloc(pp.n_contrast);
	double* num = vec_alloc(pp.n_contrast+1);
 	double temp,sumxi;
	
	
	double acptratio = 0.0;
	
	for(int t=0; t<pp.n_contrast; t++)
	{
		num[t] = p.xi_all_alpha[t] + (double)pp.Z0_n[t];
	}
	num[pp.n_contrast] = p.xi_all_alpha[pp.n_contrast]+pp.m_p;
	
	for(int t=0; t<pp.n_contrast; t++)
	{
		xi[t] = pp.xi[t]+p.xi_sgm*snorm(seed);
		while (xi[t]<=0)
			xi[t] =pp.xi[t]+p.xi_sgm*snorm(seed);
	}
	
	
	sumxi = 0;
	for(int t=0; t<pp.n_contrast+1; t++)
		sumxi += xi[t]; 
	
	for(int t=0; t<pp.n_contrast+1; t++)
		xi[t] /= sumxi;
	
	
	//xi = rdirichlet(num, pp.n_contrast+1, seed);
	
	
	for(int t=0; t<pp.n_contrast; t++)
	{
		temp = pp.xi[t];
		pp.xi[t] = xi[t];
		xi[t] = temp;
	}
	
	for(int t=0; t<pp.n_contrast; t++)
	{
		muOld[t] = pp.Z_mu[t];
		Z_mu_cal(t, pp, p);
		acptratio += pp.c_num[t]*log(muOld[t]/pp.Z_mu[t])+num[t]*log(xi[t]/pp.xi[t]);
	}
	
	
	if(log(kiss(seed))>acptratio)
	{
		for(int t=0; t<pp.n_contrast; t++)
		{
	     	pp.xi[t] = xi[t];
		    pp.Z_mu[t] = muOld[t];
		}
		free(num);
		free(muOld);
		free(xi);
		return 0;
	}
	
	free(num);
	free(muOld);
	free(xi);
	return 1;
}

int Z_update_rho(points &pp, pars &p, unsigned long* seed)
{
	double mu = 0;
	for(int t=0; t<pp.n_contrast; t++)
	{
		mu += pp.Z_mu[t];
	}
	
	p.rho = rgamma(p.alpha_rho + pp.m1, p.beta_rho + mu, seed);
	return 1;
}


int Z_update_rho_all(int t,points &pp, pars &p, unsigned long* seed)
{
	double muOld = pp.Z_mu[t];
	double rho = pp.rho_all[t];
	int n = pp.c_num[t] - pp.Z0_n[t];
	
	pp.rho_all[t] = rho + 0.5*snorm(seed);
	if(pp.rho_all[t]<=0)
	{
		pp.rho_all[t] = rho;
		return 0;
	}
	
	Z_mu_cal(t, pp, p);
	
	if (log(kiss(seed))>n*log(muOld/pp.Z_mu[t]) + (p.alpha_rho+n-1)*log(pp.rho_all[t]/rho)-p.beta_rho*(pp.rho_all[t]-rho))
	{
		pp.Z_mu[t] = muOld;
		pp.rho_all[t] = rho;
		return 0;
	}
	
	
	
	return 1;
}


void Z_move_step(points &pp, pars &p, unsigned long*seed)
{
	int idx=0;
	
	for(int t=0; t<pp.n_contrast; t++)
	{
		idx += pp.numZ[t];
		

		Z_update_kappa(t,pp, p, seed);
		
		
		for(int i=0; i<pp.numZ[t]; i++)
			Z_update_nprob(t, i, pp, seed);
		
		
		Z_mu_cal(t, pp,p);
		

		Z_update_Z(t, idx, pp, p, seed);

		Z_update_Lambda(t, pp, p, seed);
		//	Z_update_xi(t, pp, p, seed);
		
		Z_update_rho_all(t,pp,p,seed);
		
	}
	
	Z2Y(pp);
	Z_update_xi_all_1(pp, p, seed);
	//Z_update_S(pp, p, seed);
	
}

