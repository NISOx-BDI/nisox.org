/*
 *  Mnormal.cpp
 *  NewHWCox04
 *
 *  Created by Jian Kang on 4/6/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */


#include "Mnormal.h"


//Multivariate Normal Density Function
double dmvnorm(double *x, double **a,int size_A,double *mean)
{
	int i,j;
	double val,detA, temp;
	double invA[SIZE][SIZE];
	double tempArray[SIZE];
	
	detA = a[0][0]*(a[1][1]*a[2][2] - a[1][2]*a[1][2]) - a[1][1]*a[0][2]*a[0][2] + a[0][1]*(2*a[0][2]*a[1][2] - a[2][2]*a[0][1]);
	
	invA[0][0] = a[1][1]*a[2][2] - a[1][2]*a[1][2];
	invA[0][1] = a[0][2]*a[1][2] - a[0][1]*a[2][2];
	invA[0][2] = a[0][1]*a[1][2] - a[0][2]*a[1][1];
	invA[1][0] = invA[0][1];
	invA[1][1] = a[0][0]*a[2][2] - a[0][2]*a[0][2];
	invA[1][2] = a[0][1]*a[0][2] - a[0][0]*a[1][2];
	invA[2][0] = invA[0][2];
	invA[2][1] = invA[1][2];
	invA[2][2] = a[0][0]*a[1][1] - a[0][1]*a[0][1];
	
	for(i=0; i<size_A; i++)
		tempArray[i] = x[i] - mean[i];
	
	val = 0.0;
	for(i = 0; i<size_A; i++)
	{
		temp = 0.0;
		for (j =0; j<size_A; j++)
		{
			temp += invA[i][j]*tempArray[j];
		}
		val += tempArray[i]*temp;
	}
	
	val /= detA;
	detA = sqrt(detA);
	
	val = exp(-0.5*val);
	val = val/detA*INV_SQRT2PI3;
	return val;
}


int eigen(double* eigen_vector, double* eigen_value, double**S) 
{
	
	
	int k = 0;
	for(int i=0; i<SIZE; i++)
		for(int j=0; j<SIZE; j++)
		{
			eigen_vector[k] = S[i][j];
			k++;
		}
	
	double work[150];
	
	__CLPK_integer lda = SIZE;
    __CLPK_integer info;
	__CLPK_integer order = SIZE;
	__CLPK_integer lwork = 150;
	char jobz = 'V';
	char uplo = 'U';
    
	dsyev_(&jobz, &uplo , &order, eigen_vector, &lda, eigen_value, work, &lwork, &info);
	//printf("work(1) = %lf\n", work[0]);
	
    return info;
}

void eigen_print(double* eigen_vector, double* eigen_value)
{
	for(int i=0; i<SIZE; i++)
	{
		printf("%.4lf: ", eigen_value[i]);
		printf("(%.4lf, %.4lf, %.4lf) \n", eigen_vector[3*i], eigen_vector[3*i+1], eigen_vector[3*i+2]);
	}
}



double dmvnorm0(double *x, double **A,int size_A,double *mean)
{
	int i,j;
	double val,detA;
	double **invA;
	double *vec_alloc(int);
	double **mat_alloc(int);
	double **mat_copy(double **, int);
	void mat_free(double **, int);
	int cholesky_decomp(double **, int);
	void cholesky_invert(int,double **);
	const double Const = 0.063493635934241;//1/2*PI*sqrt(2*PI)
	
	
	invA = mat_copy(A,size_A);
	cholesky_decomp(invA,size_A);
	detA = 1;
	for(i=0;i<size_A;i++)
		detA = detA * invA[i][i];
	
	cholesky_invert(size_A,invA);
	
	val = 0;
	for(i = 0; i<size_A; i++)
		for (j =0; j<size_A; j++)
			val = val + (x[i]-mean[i])*invA[i][j]*(x[j] - mean[j]);
	
	val = exp(-val/2);
	val = val/detA*Const;
	
	mat_free(invA,size_A);
	
	return val;
}

//Multivariate Normal Density Function
double dmvnorm1(double *x, double **invA,int size_A,double *mean)
{
	int i,j;
	double val,detA,temp;
	double tempArray[SIZE];
	//double **A;
	//double *vec_alloc(int);
	//double **mat_alloc(int);
	//double **mat_copy(double **, int);
	//void mat_free(double **, int);
	//int cholesky_decomp(double **, int);
	const double Const = 0.063493635934241;//1/2*PI*sqrt(2*PI)
	
	
	//A = mat_copy(invA,size_A);
	//cholesky_decomp(A,size_A);
	//detA = 1;
	//for(i=0;i<size_A;i++)
	//	detA = detA * A[i][i];
	
	detA = invA[0][0]*(invA[1][1]*invA[2][2] - invA[1][2]*invA[1][2]) - invA[1][1]*invA[0][2]*invA[0][2] + invA[0][1]*(2*invA[0][2]*invA[1][2] - invA[2][2]*invA[0][1]);
	
	for(i=0; i<size_A; i++)
		tempArray[i] = x[i] - mean[i];
	
	val = 0.0;
	for(i = 0; i<size_A; i++)
	{
		temp = 0.0;
		for (j =0; j<size_A; j++)
		{
			temp += invA[i][j]*tempArray[j];
		}
		val += tempArray[i]*temp;
	}
	
	val = exp(-val/2);
	val = sqrt(detA)*val*Const;
	
	//mat_free(A,size_A);
	
	return val;
}

//inRange
int inRange(double*x,int size, unsigned char*** mask, int*range)
{
	for(int i=0; i<size; i++)
		if(0 > x[i] || x[i] >= range[i])
			return 0;
	return (int)mask[(int)floor(x[0])][(int)floor(x[1])][(int)floor(x[2])];
}

//Multivariate normal probability by Monte-Carlo Method
double pmvnorm(unsigned char***mask, int* range, double**A, int size, double *mean, int iters,unsigned long* seed)
{
	double *r = vec_alloc(size);
	double **Sigma = mat_copy(A,size);
	double p=0;
	
	rmvnorm(r,Sigma,size,mean,seed,0);
	if (inRange(r,size,mask,range)==1)
		p++;
	for(int i=1; i<iters; i++)
	{
		rmvnorm(r,Sigma,size,mean,seed,1);
		//vec_print(r,size,"%.4lf ");
		if (inRange(r,size,mask,range)==1)
			p++;
	}
	p /= iters;
	
	free(r);
	
	mat_free(Sigma,size);
	return p;
}

//Generate Random Number from Multivariate T Distribution
int rmvt(double *result, double* mean, double **S, int size, int df, unsigned long* seed, int flag)
{
	double* y = vec_alloc(size);
	double* zero = vec_alloc(size);
	double u = rchisq(df,seed);
	
	if (rmvnorm(y,S,size,zero,seed,flag)==0)
		return 0; 
	
	for (int i=0; i<size; i++)
	{
		result[i] = y[i]*sqrt(df/u)+mean[i];
	}
	free(y);
	free(zero);
	
	return 1;
}


//Multivariate T probability
double pmvt(unsigned char***mask, int *range, double **S, int size, double *mean, int df, int iters, unsigned long* seed)
{
	double *r = vec_alloc(size);
	double **Sigma = mat_copy(S,size);
	double p=0;
	
	if (rmvt(r,mean,Sigma,size,df,seed,0)==0)
		return -1;
	if (inRange(r,size,mask,range)==1)
		p++;
	for(int i=1; i<iters; i++)
	{
		if(rmvt(r,mean,Sigma,size,df,seed,1)==0)
			return -1;
		if (inRange(r,size,mask,range)==1)
			p++;
	}
	p /= iters;
	
	free(r);
	mat_free(Sigma,size);
	return p;
}





