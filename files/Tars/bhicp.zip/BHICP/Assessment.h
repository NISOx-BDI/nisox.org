/*
 *  Assessment.h
 *  NewHWCox04
 *
 *  Created by Jian Kang on 4/6/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#include "Mnormal.h"
#include "WeightedCox.h"

#define PI 3.141592653589793

void simStudyPACs(double** PACs, int* numOfPoints, double** studyCenters, double*** studyCov, int numOfStudyCenters, 
				  double** popCenters, double***popCov, int numOfPopCenters, 
				  double eta, double eps, double theta, double vol, double W,
				  unsigned char*** brain_mask, int* dim, unsigned long* seed);


void simAllPACs(points &pp, pars &p,unsigned long* seed);

void write_sPACs(const char* filename, points &pp, pars &p);

void rec_pred_intensity(points &pp, pars &p, unsigned long* seed);

double compute_Lfun(double r, double** PACs, double W, int Wid, int numOfPoints, double* phi, double** studyCenters, double*** studyCov, int numOfStudyCenters, 
					double** popCenters, double***popCov, int numOfPopCenters, unsigned char*** brain_mask, int* dim, double vol,  
					double eta, double eps, double theta, unsigned long* seed);


void compute_diff_Lfun(double rstart, double rend, int rnum,  points &pp, pars &p, unsigned long* seed);

void write_diff_Lfun(const char* filename, points &pp, int rnum);

double distance2(double* p1, double* p2, int dim);

double compute_edge_factor(double* p1, double* p2, unsigned char*** brain_mask, int* dim, double vol, unsigned long* seed);

void sample_unif_region(double*p, unsigned char*** brain_mask, int* dim,unsigned long* seed);

void voxel2mm(double* voxel_p, double* mm_p, double* orgin);