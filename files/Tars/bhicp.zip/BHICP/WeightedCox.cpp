/*
 *  WeightedCox.cpp
 *  NewHWCox04
 *
 *  Created by Jian Kang on 4/6/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#include "WeightedCox.h"

points initial_points()
{
	points pp;
	pp.dim = (int*)malloc(sizeof(int)*DIM);
	pp.m = 0;
	pp.Y = NULL;
	pp.dat= NULL;
	pp.matZ = NULL;
	pp.W = NULL;
	pp.W1 = NULL;
	pp.W_id = NULL;
	pp.W1_id = NULL;
	pp.kappa = NULL;
	pp.mask = NULL;
	pp.Lamygdala = NULL;
	pp.Ramygdala = NULL;
	pp.WM = NULL;
	pp.vol = 0;
	pp.intensity = NULL;
	pp.curint = NULL;
	pp.num_intense = 0;
	pp.intval_intense = 1;
	pp.num_pred_int = 0;
	return pp;
	
}


pars initial_pars1(int in_total_iters,int in_adj_acpt,  int in_burn_in,  
				   int in_rec_lambda,
				   double* in_V, int in_V_n, 
				   int in_n,  int in_m,  
				   double in_xi, double in_tau_xi, double in_xi_sgm, 
				   double in_rho, double in_tau_rho,
				   double in_eta, 
				   double in_tau_theta, double in_tau_eps,
				   double in_sgm0, double in_sgm1,
				   int in_df_S, int in_df_S0, 
				   int in_df_T, int in_df_T0,
				   double in_var_Sigma, double in_var_S0, double in_radius,
				   double in_vol, int num_children)
{
	pars p;
	
	p.total_iters = in_total_iters;
	p.adj_acpt = in_adj_acpt;
	p.burn_in = in_burn_in;
	p.rec_lambda = in_rec_lambda;
	
	double *prob  = vec_alloc(in_V_n);
	for(int i=0; i<in_V_n; i++)
		prob[i] = 1.0/in_V_n;
	
	//p.phi= rdirichlet(prob,in_V_n,seed);
	p.phi = vec_copy(prob, in_V_n);
	
	free(prob);
	
	p.V = vec_copy(in_V,in_V_n);
	p.V_n = in_V_n;
	
	p.beta = in_n/in_vol;
	p.b = 2*in_n/in_vol;
	p.a = 0/in_vol;
	
	
	p.acpt0 = 0.0;
	p.acpt1 = 0.0;
	
	p.xi = in_xi/in_m;
	p.xi_alpha = in_tau_xi;
	p.xi_beta = p.xi_alpha /p.xi;
	p.xi_sgm = in_xi_sgm/in_m;
	
	
	p.radius2 = in_radius*in_radius;
	
	
	//p.eps = rgamma(p.alpha0,p.beta0,seed);
	//p.theta = rgamma(p.alpha1,p.beta1,seed);
	
	
	p.eps = in_eta*in_m/in_vol;
	p.theta = (1-in_eta)*in_m/in_n;
	
	
	p.rho = in_rho;
	p.alpha_rho = 1.0/(in_tau_rho*in_tau_rho);
	p.beta_rho = p.alpha_rho/p.rho;
	
	
	
	p.alpha0 = 1.0/(in_tau_eps*in_tau_eps);
	p.beta0 = p.alpha0/p.eps;
	p.alpha1 = 1.0/(in_tau_theta*in_tau_theta);
	p.beta1 = p.alpha1/p.theta;
	
	p.theta = 2*p.theta;
	
	if (in_sgm0 < 0)
		p.sgm0 = in_tau_eps*p.eps;
	else
		p.sgm0 = in_sgm0;
	
	if (in_sgm1 < 0)
		p.sgm1 = in_tau_theta*p.theta;
	else
		p.sgm1 = in_sgm1;
	
	
	
	p.invT = mat_alloc(DIM);
	p.T = mat_alloc(DIM);
	p.invT0= mat_alloc(DIM);
	p.S = mat_alloc(DIM);
	p.S0 = mat_alloc(DIM);
	p.invS0=mat_alloc(DIM);
	p.invS = mat_alloc(DIM);
	p.T0 = mat_alloc(DIM);
	mat_times_k(p.T0, DIM, (in_df_S0-DIM-1.0)*in_var_S0/in_df_T0);
	mat_times_k(p.T,DIM, (in_df_S-DIM-1.0)*in_var_Sigma/in_df_T);
	mat_times_k(p.invT0, DIM, in_df_T0/((in_df_S0-DIM-1.0)*in_var_S0));
	mat_times_k(p.invT, DIM, in_df_T/((in_df_S-DIM-1.0)*in_var_Sigma));
	mat_times_k(p.S, DIM, (in_df_S-DIM-1)*in_var_Sigma);
	mat_times_k(p.invS, DIM, 1.0/((in_df_S-DIM-1)*in_var_Sigma));
	mat_times_k(p.S0, DIM, (in_df_S0-DIM-1)*in_var_S0);
	mat_times_k(p.invS0, DIM, 1.0/((in_df_S0-DIM-1)*in_var_S0));
	
	
	p.df_S = in_df_S;
	p.df_S0 = in_df_S0;
	p.df_T = in_df_T;
	p.df_T0 = in_df_T0;
	
	p.n = 0;
	p.X = vec_list_alloc(DIM,MAX_N);
	p.Sigma = mat_list_alloc(DIM,MAX_N);
	p.SigmaInv = mat_list_alloc(DIM, MAX_N);
	p.norm_prob =vec_list_alloc(p.V_n, MAX_N);
	p.update_indicator = (int*)calloc(MAX_N, sizeof(int));
	p.Num = (int*)calloc(MAX_N,sizeof(int));
	p.studyNum = (int*)calloc(MAX_N,sizeof(int));
	p.contrastNum = (int*)calloc(MAX_N,sizeof(int));
	p.N0 = 0;
	p.mu = p.eps*in_vol;
	
	p.totalBirthRate = 0;
	p.totalDeathRate = 0;
	
	p.BorD = 0;
	p.birth_acpt = 0.0;
	p.death_acpt = 0.0;
	
	p.numOfBirth = 0;
	p.numOfDeath = 0;
	
	
	p.num_children = num_children;
	
	//p.temp_fid = fopen("temp_results.txt","wt");
	
	return p;
}




pars initial_pars2(int in_total_iters,int in_adj_acpt,  int in_burn_in,  
				   int in_rec_lambda,
				   double* in_V, int in_V_n, 
				   int in_n,  int in_m,
				   double in_xi, double in_tau_xi, double in_xi_sgm, 
				   double in_rho, double in_tau_rho,
				   double a_theta, double b_theta,   
				   double a_eps, double b_eps,
				   double in_sgm0, double in_sgm1,
				   int in_df_S, int in_df_S0, 
				   int in_df_T, int in_df_T0,
				   double in_var_Sigma, double in_var_S0, double in_radius,
				   double in_vol, int num_children,int cutnumber)
{
	pars p;
	
	p.total_iters = in_total_iters;
	p.adj_acpt = in_adj_acpt;
	p.burn_in = in_burn_in;
	p.rec_lambda = in_rec_lambda;
	p.cutnumber = cutnumber;
	
	double *prob  = vec_alloc(in_V_n);
	for(int i=0; i<in_V_n; i++)
		prob[i] = 1.0/in_V_n;
	
	//p.phi= rdirichlet(prob,in_V_n,seed);
	p.phi = vec_copy(prob, in_V_n);
	
	free(prob);
	
	p.V = vec_copy(in_V,in_V_n);
	p.V_n = in_V_n;
	
	p.beta = in_n/in_vol;
	p.b = 0.0001;
	p.a = 0.003;
	
	
	p.acpt0 = 0.0;
	p.acpt1 = 0.0;
	
	p.xi = in_xi/in_m;
	p.xi_alpha = in_tau_xi;
	p.xi_beta = p.xi_alpha /p.xi;
	p.xi_sgm = in_xi_sgm/in_m;
	
	
	p.radius2 = in_radius*in_radius;
	
	
	//p.eps = rgamma(p.alpha0,p.beta0,seed);
	//p.theta = rgamma(p.alpha1,p.beta1,seed);
	b_eps = b_eps*in_vol;
	
	p.eps = a_eps/b_eps;
	p.theta = a_theta/b_theta;
	//p.theta = 200;
	
	
	p.rho = in_rho;
	p.alpha_rho = 1.0/(in_tau_rho*in_tau_rho);
	p.beta_rho = p.alpha_rho/p.rho;
	
	
	
	p.alpha0 = a_eps;
	p.beta0 = b_eps;
	p.alpha1 = a_theta;
	p.beta1 = b_theta;
	
	//p.theta = 2*p.theta;
	
	if (in_sgm0 < 0)
		p.sgm0 = p.eps/sqrt(p.alpha0);
	else
		p.sgm0 = in_sgm0;
	
	if (in_sgm1 < 0)
		p.sgm1 = p.theta/sqrt(p.alpha1);
	else
		p.sgm1 = in_sgm1;
	
	
	
	p.invT = mat_alloc(DIM);
	p.T = mat_alloc(DIM);
	p.invT0= mat_alloc(DIM);
	p.S = mat_alloc(DIM);
	p.S0 = mat_alloc(DIM);
	p.invS0=mat_alloc(DIM);
	p.invS = mat_alloc(DIM);
	p.T0 = mat_alloc(DIM);
	mat_times_k(p.T0, DIM, (in_df_S0-DIM-1.0)*in_var_S0/in_df_T0);
	mat_times_k(p.T,DIM, (in_df_S-DIM-1.0)*in_var_Sigma/in_df_T);
	mat_times_k(p.invT0, DIM, in_df_T0/((in_df_S0-DIM-1.0)*in_var_S0));
	mat_times_k(p.invT, DIM, in_df_T/((in_df_S-DIM-1.0)*in_var_Sigma));
	mat_times_k(p.S, DIM, (in_df_S-DIM-1)*in_var_Sigma);
	mat_times_k(p.invS, DIM, 1.0/((in_df_S-DIM-1)*in_var_Sigma));
	mat_times_k(p.S0, DIM, (in_df_S0-DIM-1)*in_var_S0);
	mat_times_k(p.invS0, DIM, 1.0/((in_df_S0-DIM-1)*in_var_S0));
	
	
	p.df_S = in_df_S;
	p.df_S0 = in_df_S0;
	p.df_T = in_df_T;
	p.df_T0 = in_df_T0;
	
	p.n = 0;
	p.X = vec_list_alloc(DIM,MAX_N);
	p.Sigma = mat_list_alloc(DIM,MAX_N);
	p.SigmaInv = mat_list_alloc(DIM, MAX_N);
	p.norm_prob =vec_list_alloc(p.V_n, MAX_N);
	p.update_indicator = (int*)calloc(MAX_N, sizeof(int));
	p.Num = (int*)calloc(MAX_N,sizeof(int));
	p.studyNum = (int*)calloc(MAX_N,sizeof(int));
	p.contrastNum = (int*)calloc(MAX_N,sizeof(int));
	p.N0 = 0;
	p.mu = p.eps*in_vol;
	
	p.totalBirthRate = 0;
	p.totalDeathRate = 0;
	
	p.BorD = 0;
	p.birth_acpt = 0.0;
	p.death_acpt = 0.0;
	
	p.numOfBirth = 0;
	p.numOfDeath = 0;
	
	
	p.num_children = num_children;
	
	//p.temp_fid = fopen("temp_results.txt","wt");
	
	return p;
}



pars initial_pars3(int in_total_iters,int in_adj_acpt,  int in_burn_in,  
				   int in_rec_lambda,
				   double* in_V, int in_V_n, 
				   double a_beta, double b_beta,
				   double a_theta, double a_eps,
				   int in_df_S, int in_df_S0, 
				   int in_df_T,
				   double in_var_Sigma, double in_var_S0, double in_vol)
{
	pars p;
	
	p.total_iters = in_total_iters;
	p.adj_acpt = in_adj_acpt;
	p.burn_in = in_burn_in;
	p.rec_lambda = in_rec_lambda;
	
	p.cutnumber = 10;
	double *prob  = vec_alloc(in_V_n);
	for(int i=0; i<in_V_n; i++)
		prob[i] = 1.0/in_V_n;
	
	p.phi = vec_copy(prob, in_V_n);
	free(prob);
	
	p.V = vec_copy(in_V,in_V_n);
	p.V_n = in_V_n;
	
	p.beta = a_beta/b_beta/in_vol;
	p.b = b_beta;
	p.a = a_beta;
	
	
	p.acpt0 = 0.0;
	p.acpt1 = 0.0;
	
	
	p.rho = 1.0;
	p.alpha_rho = 0.001;
	p.beta_rho = 0.001;
	
	p.xi = 0.001;
	p.xi_alpha = 0.5;
	p.xi_beta = 1.0;
	p.xi_sgm = 0.01;
	
	double in_radius = 5.0;
	p.radius2 = in_radius*in_radius;
	
	
	p.eps = a_eps;
	p.theta = a_theta;
	
	
	p.alpha0 = a_eps;
	p.beta0 = in_vol;
	p.alpha1 = a_theta;
	p.beta1 = 1.0;
	

	p.sgm0 = p.eps/sqrt(p.alpha0);
	p.sgm1 = p.theta/sqrt(p.alpha1);
	
	
	
	p.invT = mat_alloc(DIM);
	p.T = mat_alloc(DIM);
	p.invT0= mat_alloc(DIM);
	p.S = mat_alloc(DIM);
	p.S0 = mat_alloc(DIM);
	p.invS0=mat_alloc(DIM);
	p.invS = mat_alloc(DIM);
	p.T0 = mat_alloc(DIM);
	
	int in_df_T0 = 500;
	
	mat_times_k(p.T,DIM, (in_df_S-DIM-1.0)*in_var_Sigma/in_df_T);
	mat_times_k(p.invT, DIM, in_df_T/((in_df_S-DIM-1.0)*in_var_Sigma));
	mat_times_k(p.S, DIM, (in_df_S-DIM-1)*in_var_Sigma);
	mat_times_k(p.invS, DIM, 1.0/((in_df_S-DIM-1)*in_var_Sigma));
	
	mat_times_k(p.T0, DIM, (in_df_S0-DIM-1.0)*in_var_S0/in_df_T0);
	mat_times_k(p.invT0, DIM, in_df_T0/((in_df_S0-DIM-1.0)*in_var_S0));
	mat_times_k(p.S0, DIM, (in_df_S0-DIM-1)*in_var_S0);
	mat_times_k(p.invS0, DIM, 1.0/((in_df_S0-DIM-1)*in_var_S0));
	
	
	p.df_S = in_df_S;
	p.df_S0 = in_df_S0;
	p.df_T = in_df_T;
	p.df_T0 = in_df_T0;
	
	p.n = 0;
	p.X = vec_list_alloc(DIM,MAX_N);
	p.Sigma = mat_list_alloc(DIM,MAX_N);
	p.SigmaInv = mat_list_alloc(DIM, MAX_N);
	p.norm_prob =vec_list_alloc(p.V_n, MAX_N);
	p.update_indicator = (int*)calloc(MAX_N, sizeof(int));
	p.Num = (int*)calloc(MAX_N,sizeof(int));
	p.studyNum = (int*)calloc(MAX_N,sizeof(int));
	p.contrastNum = (int*)calloc(MAX_N,sizeof(int));
	p.N0 = 0;
	p.mu = p.eps*in_vol;
	
	p.totalBirthRate = 0;
	p.totalDeathRate = 0;
	
	p.BorD = 0;
	p.birth_acpt = 0.0;
	p.death_acpt = 0.0;
	
	p.numOfBirth = 0;
	p.numOfDeath = 0;
	
	
	p.num_children = 1;
	
	return p;
}




void free_points(points &pp)
{
	if(pp.dat!=NULL)
	{
		for(int i=0; i<pp.m1; i++)
		{
			free(pp.Y[i]);
			free(pp.dat[i]);
		}
		free(pp.Y);
		free(pp.dat);
		mat_mat_free(pp.Lambda, DIM, Z_MAX, pp.n_contrast);
		mat_mat_free(pp.invLambda, DIM, Z_MAX, pp.n_contrast);
		Array_free(pp.matZ, DIM, Z_MAX, pp.n_contrast); 
		Array_free(pp.sPACs, DIM, SIM_MAX, pp.n_contrast); 
		
		Array_free(pp.intensity, pp.dim[2], pp.dim[1], pp.dim[0]);
		Array_free(pp.curint, pp.dim[2], pp.dim[1], pp.dim[0]);
		Array_free(pp.pred_intensity, pp.dim[2], pp.dim[1], pp.dim[0]);
	}
	
	vec_list_free(pp.Z_kappa,pp.n_contrast);
	vec_list_free(pp.Z_n,pp.n_contrast);
	vec_list_free(pp.Z_norm_prob,pp.n_contrast);
	
	vec_list_free(pp.diffLfun, pp.n_contrast);
	
	free(pp.numsPACs);
	free(pp.Z_mu);
	free(pp.sW);
	free(pp.sWid);
	free(pp.W1);
	free(pp.W1_id);
	free(pp.W);
	free(pp.W_id);
	free(pp.kappa);
	free(pp.study);
	free(pp.study1);
	free(pp.contrast1);
	free(pp.contrast);
	vec_list_free(pp.id_study, MAX_N);
	vec_list_free(pp.id_contrast, MAX_N);
	free(pp.s_id);
	free(pp.s_num);
	free(pp.c_num);
	free(pp.c_id);
	free(pp.numZ);
	free(pp.Z_tB);
	free(pp.Z_tD);
	free(pp.Y_n);
	free(pp.xi);
	free(pp.rho_all);
	
	if(pp.mask!=NULL)
	{
		for(int i=0; i<pp.dim[0]; i++ )
		{
			for(int j=0; j<pp.dim[1]; j++)
			{
				free(pp.mask[i][j]);
				free(pp.Lamygdala[i][j]);
				free(pp.Ramygdala[i][j]);
			}
			free(pp.mask[i]);
			free(pp.Lamygdala[i]);
			free(pp.Ramygdala[i]);
			
		}
		free(pp.mask);
		free(pp.Lamygdala);
		free(pp.Ramygdala);
	}
	
	free(pp.WM);
	free(pp.lambda_list);
	free(pp.slambda_list);
	vec_list_free(pp.Z_lambda_list,pp.m1);
	vec_list_free(pp.dnorm_list,pp.m1);
	Array_free(pp.Z_dnorm_list, Z_MAX, pp.n_contrast, pp.m1);

	
	free(pp.dim);
	free(pp.Z0_n);
	free(pp.Zg_n);
	free(pp.Zi);
	free(pp.Zj);
	
	for(int i=0; i<pp.n_contrast; i++)
		free(pp.idx_Y[i]);
	free(pp.idx_Y);
	
	
	free(pp.ra_id);
	free(pp.la_id);
}

void free_pars(pars &p)
{
	free(p.V);
	//free(p.xi);
	free(p.phi);
	free(p.Num);
	free(p.studyNum);
	free(p.contrastNum);
	mat_free(p.S,DIM);
	mat_free(p.invS,DIM);
	mat_free(p.invS0, DIM);
	mat_free(p.S0, DIM);
	mat_free(p.T,DIM);
	mat_free(p.T0,DIM);
	mat_free(p.invT,DIM);
	mat_free(p.invT0,DIM);
	vec_list_free(p.X,MAX_N);
	mat_list_free(p.Sigma,DIM,MAX_N);
	mat_list_free(p.SigmaInv, DIM, MAX_N);
	vec_list_free(p.norm_prob, MAX_N);
	free(p.update_indicator);
	//fclose(p.temp_fid);
}

void read_points(const char* pointsfile, points &pp)
{
	FILE* f;
	double tp1,tp2,tp3,tp5;
	int tp4;
	
	pp.m = 0;
	f = fopen(pointsfile,"rt");
	
	while (!feof(f) && fscanf(f, "%lf %lf %lf %d %lf\n", &tp1,&tp2,&tp3,&tp4,&tp5) == 5)
		pp.m++;
	rewind(f);
	
	pp.Y = (double**)malloc(sizeof(double*)*pp.m);
	pp.W = (double*)malloc(sizeof(double)*pp.m);
	pp.W_id = (int*)malloc(sizeof(int)*pp.m);
	for(int i=0; i<pp.m; i++)
	{
		pp.Y[i] = (double*)malloc(sizeof(double)*DIM);
		fscanf(f,"%lf %lf %lf %d %lf\n",&(pp.Y[i][0]),&(pp.Y[i][1]),&(pp.Y[i][2]),&(pp.W_id[i]),&(pp.W[i]));
	}
	
	fclose(f);
	pp.kappa = (int*)calloc(pp.m, sizeof(int));
	pp.WM = vec_alloc(DIM);
	for(int j=0; j<pp.m; j++)
	{
		pp.WM[pp.W_id[j]]++; 
	}
	
	pp.intensity = Array_alloc(pp.dim[2], pp.dim[1], pp.dim[0]);
	pp.curint = Array_alloc(pp.dim[2], pp.dim[1], pp.dim[0]);
	
	for(int i=0; i<pp.dim[0]; i++)
		for(int j=0; j<pp.dim[1]; j++)
			for(int k=0; k<pp.dim[2]; k++)
			{
				pp.intensity[i][j][k] = -1;
				pp.curint[i][j][k] = -1;
			}
	
}


void read_points1(const char* pointsfile, points &pp)
{
	FILE* f;
	double tp1,tp2,tp3,tp5;
	int tp, tp0, tp4;
	
	pp.m1 = 0;
	f = fopen(pointsfile,"rt");
	
	while (!feof(f) && fscanf(f, "%d %d %lf %lf %lf %d %lf\n",&tp,&tp0,&tp1,&tp2,&tp3,&tp4,&tp5) == 7)
		pp.m1++;
	rewind(f);
	
	
	pp.dat = (double**)malloc(sizeof(double*)*pp.m1);
	
	pp.Y = vec_list_alloc(DIM,2*pp.m1);
	pp.W = (double*)malloc(sizeof(double)*pp.m1);
	pp.W_id = (int*)malloc(sizeof(int)*pp.m1);
	pp.W1 = (double*)malloc(sizeof(double)*pp.m1);
	pp.W1_id = (int*)malloc(sizeof(int)*pp.m1);
	pp.study = (int*)malloc(sizeof(int)*pp.m1);
	pp.study1 = (int*)malloc(sizeof(int)*pp.m1);
	pp.contrast = (int*)malloc(sizeof(int)*pp.m1);
	pp.contrast1 = (int*)malloc(sizeof(int)*pp.m1);
	for(int i=0; i<pp.m1; i++)
	{
		pp.dat[i] = (double*)malloc(sizeof(double)*DIM);
		fscanf(f,"%d %d %lf %lf %lf %d %lf\n",&(pp.study1[i]), &(pp.contrast1[i]), &(pp.dat[i][0]),&(pp.dat[i][1]),&(pp.dat[i][2]),&(pp.W1_id[i]),&(pp.W1[i]));
	}
	
	fclose(f);
	pp.kappa = (int*)calloc(pp.m1, sizeof(int));
	for(int j=0; j<pp.m1; j++)
		pp.kappa[j] = -1;
	
	pp.WM = vec_alloc(DIM);
	for(int j=0; j<pp.m1; j++)
	{
		pp.WM[pp.W1_id[j]]++; 
	}
	
	pp.intensity = Array_alloc(pp.dim[2], pp.dim[1], pp.dim[0]);
	pp.curint = Array_alloc(pp.dim[2], pp.dim[1], pp.dim[0]);
	
	pp.pred_intensity = Array_alloc(pp.dim[2], pp.dim[1], pp.dim[0]);
	pp.num_pred_int = 0;
	
	for(int i=0; i<pp.dim[0]; i++)
		for(int j=0; j<pp.dim[1]; j++)
			for(int k=0; k<pp.dim[2]; k++)
			{
				pp.intensity[i][j][k] = -1;
				pp.curint[i][j][k] = -1;
			}
	
	pp.n_study = 1;
	pp.n_contrast = 1;
	for(int i=0; i<pp.m1-1; i++)
	{
		if (pp.study1[i+1]!= pp.study1[i])
			pp.n_study++;
		if (pp.contrast1[i+1]!=pp.contrast1[i])
			pp.n_contrast++;
	}
	
	int j = 0;
	int id = 0;
	
	pp.Z_kappa = (int**) calloc(pp.n_contrast, sizeof(int*));
	//pp.Zvec_kappa = (int*)calloc(pp.m1,sizeof(int));
	pp.Z_n = (int**)calloc(pp.n_contrast,sizeof(int*));
	
	
	pp.diffLfun = vec_list_alloc(R_MAX,pp.n_contrast);
	pp.sW = vec_alloc(pp.n_contrast);
	pp.sWid = (int*)calloc(pp.n_contrast, sizeof(int));
	pp.Z0_n = (int*)calloc(pp.n_contrast,sizeof(int));
	pp.Zg_n = (int*)calloc(pp.n_contrast,sizeof(int));
	pp.Y_n = (int*)calloc(pp.m1, sizeof(int));
	pp.Z_norm_prob = vec_list_alloc(Z_MAX, pp.n_contrast);
	pp.Z_mu = vec_alloc(pp.n_contrast);
	pp.s_id = (int*)calloc(pp.n_study+1,sizeof(int));
	pp.c_id = (int*)calloc(pp.n_contrast+1, sizeof(int));
	pp.s_num = (int*)calloc(pp.n_study,sizeof(int));
	pp.c_num = (int*)calloc(pp.n_contrast, sizeof(int));
	pp.Z_tB = vec_alloc(pp.n_contrast);
	pp.Z_tD = vec_alloc(pp.n_contrast);
	
	//Study
	for(int i=0; i<pp.n_study; i++)
	{
		pp.s_id[i] = j;
		id = pp.study1[j];
		while(pp.study1[j]== id && j<pp.m1-1)
			j++;
	}
	pp.s_id[pp.n_study] = pp.m1-1;
	
	//Contrast
	j = 0;
	id = 0;
	for(int i=0; i<pp.n_contrast; i++)
	{
		pp.c_id[i] = j;
		id = pp.contrast1[j];
		while(pp.contrast1[j]== id && j<pp.m1-1)
			j++;
	}
	pp.c_id[pp.n_contrast] = pp.m1;
	
	for(int i=0; i<pp.n_contrast; i++)
		pp.c_num[i] = pp.c_id[i+1] - pp.c_id[i];
	
	for(int i=0; i<pp.n_study; i++)
		pp.s_num[i] = pp.s_id[i+1] - pp.s_id[i];
	
	for(int i=0; i<pp.n_contrast; i++)
	{
		pp.Z_kappa[i] = (int*)calloc(Z_MAX,sizeof(int));
		for(int j=0; j<Z_MAX; j++)
			pp.Z_kappa[i][j] = -1;
		pp.Z_n[i] = (int*)calloc(Z_MAX,sizeof(int));
	}
	
	pp.matZ = Array_alloc(DIM, Z_MAX, pp.n_contrast); 
	pp.sPACs = Array_alloc(DIM, SIM_MAX, pp.n_contrast);
	
	pp.numsPACs = (int*)calloc(pp.n_contrast, sizeof(int));

	pp.Zi = (int*)calloc(pp.m1, sizeof(int)); 
	pp.Zj = (int*)calloc(pp.m1, sizeof(int)); 
	
	pp.idx_Y = (int**)calloc(pp.n_contrast, sizeof(int*)); 
	for(int j=0; j<pp.n_contrast; j++)
	{
	    pp.idx_Y[j] = (int*)calloc(pp.c_num[j], sizeof(int));
	}
	
	pp.numZ = (int*)calloc(pp.n_contrast, sizeof(int));
	
	for(int i=0; i<pp.n_contrast; i++)
		pp.numZ[i] = 0;

	pp.Lambda = mat_mat_alloc(DIM, Z_MAX, pp.n_contrast);
	pp.invLambda = mat_mat_alloc(DIM, Z_MAX, pp.n_contrast);
	
	pp.id_study = (int**)calloc(MAX_N,sizeof(int*));
	pp.id_contrast = (int**)calloc(MAX_N, sizeof(int*));
	
	for(int i=0; i<MAX_N; i++)
	{
		pp.id_study[i] = (int*)calloc(pp.n_study,sizeof(int));
		pp.id_contrast[i] = (int*)calloc(1000, sizeof(int));
	}
	
	pp.dnorm_list = vec_list_alloc(MAX_N, pp.m1);
	pp.lambda_list = vec_alloc(pp.m1);
	pp.slambda_list = vec_alloc(pp.m1);
	pp.Z_lambda_list = vec_list_alloc(Z_MAX,pp.m1);
	pp.Z_dnorm_list = Array_alloc(Z_MAX, pp.n_contrast, pp.m1);
	pp.xi = vec_alloc(pp.n_contrast+1);
	pp.rho_all = vec_alloc(pp.n_contrast);
	
	for(int i=0; i<pp.n_contrast; i++)
		for(int j=0; j<pp.c_num[i]; j++)
		{
			pp.Zi[pp.c_id[i]+j] = i;	
			pp.Zj[pp.c_id[i]+j] = j;	
		}
	
	
	pp.n_ra = 0;
	pp.n_la = 0;
	for(int j=0; j<pp.m1; j++)
	{
		if(inRange(pp.dat[j],DIM,pp.Ramygdala,pp.dim))
			pp.n_ra++;
		
		if(inRange(pp.dat[j],DIM,pp.Lamygdala,pp.dim))
			pp.n_la++;
	}
	
	pp.la_id = (int*)calloc(pp.n_la, sizeof(int));
	pp.ra_id = (int*)calloc(pp.n_ra, sizeof(int));
	
	int tmpr = 0, tmpl =0;
	for(int j=0; j<pp.m1; j++)
	{
		if(inRange(pp.dat[j],DIM,pp.Lamygdala,pp.dim))
		{
			pp.la_id[tmpl] = j;
			tmpl++;
		}
		
		if(inRange(pp.dat[j],DIM,pp.Ramygdala,pp.dim))
		{
			pp.ra_id[tmpr] = j;
			tmpr++;
		}
	}
	
	pp.xi_acpt = 0;
	
	
	pp.orgin = vec_alloc(DIM);
	pp.orgin[0] = 45;
	pp.orgin[1] = 64;
	pp.orgin[2] = 36;
	
	
	
}

void read_points2(const char* pointsfile, points &pp)
{
	FILE* f;
	double tp1,tp2,tp3,tp5;
	int tp, tp0, tp4;
	
	pp.m1 = 0;
	f = fopen(pointsfile,"rt");
	
	while (!feof(f) && fscanf(f, "%d %lf %lf %lf %d\n",&tp0,&tp1,&tp2,&tp3,&tp4) == 5)
		pp.m1++;
	rewind(f);
	
	
	pp.dat = (double**)malloc(sizeof(double*)*pp.m1);
	
	pp.Y = vec_list_alloc(DIM,2*pp.m1);
	pp.W = (double*)malloc(sizeof(double)*pp.m1);
	pp.W_id = (int*)malloc(sizeof(int)*pp.m1);
	pp.W1 = (double*)malloc(sizeof(double)*pp.m1);
	pp.W1_id = (int*)malloc(sizeof(int)*pp.m1);
	pp.study = (int*)malloc(sizeof(int)*pp.m1);
	pp.study1 = (int*)malloc(sizeof(int)*pp.m1);
	pp.contrast = (int*)malloc(sizeof(int)*pp.m1);
	pp.contrast1 = (int*)malloc(sizeof(int)*pp.m1);
	for(int i=0; i<pp.m1; i++)
	{
		pp.dat[i] = (double*)malloc(sizeof(double)*DIM);
		fscanf(f,"%d %lf %lf %lf %d\n",&(pp.contrast1[i]), &(pp.dat[i][0]),&(pp.dat[i][1]),&(pp.dat[i][2]),&tp4);
	}
    
    for (int i=0; i<pp.m1; i++) {
        pp.W_id[i] = 0;
        pp.W[i] = 1;
        pp.W1_id[i] = 0;
        pp.W1[i] = 1;

    }
	
	fclose(f);
	pp.kappa = (int*)calloc(pp.m1, sizeof(int));
	for(int j=0; j<pp.m1; j++)
		pp.kappa[j] = -1;
	
	pp.WM = vec_alloc(DIM);
	for(int j=0; j<pp.m1; j++)
	{
		pp.WM[pp.W1_id[j]]++;
	}
	
	pp.intensity = Array_alloc(pp.dim[2], pp.dim[1], pp.dim[0]);
	pp.curint = Array_alloc(pp.dim[2], pp.dim[1], pp.dim[0]);
	
	pp.pred_intensity = Array_alloc(pp.dim[2], pp.dim[1], pp.dim[0]);
	pp.num_pred_int = 0;
	
	for(int i=0; i<pp.dim[0]; i++)
		for(int j=0; j<pp.dim[1]; j++)
			for(int k=0; k<pp.dim[2]; k++)
			{
				pp.intensity[i][j][k] = -1;
				pp.curint[i][j][k] = -1;
			}
	
	pp.n_study = 1;
	pp.n_contrast = 1;
	for(int i=0; i<pp.m1-1; i++)
	{
		if (pp.study1[i+1]!= pp.study1[i])
			pp.n_study++;
		if (pp.contrast1[i+1]!=pp.contrast1[i])
			pp.n_contrast++;
	}
	
	int j = 0;
	int id = 0;
	
	pp.Z_kappa = (int**) calloc(pp.n_contrast, sizeof(int*));
	//pp.Zvec_kappa = (int*)calloc(pp.m1,sizeof(int));
	pp.Z_n = (int**)calloc(pp.n_contrast,sizeof(int*));
	
	
	pp.diffLfun = vec_list_alloc(R_MAX,pp.n_contrast);
	pp.sW = vec_alloc(pp.n_contrast);
	pp.sWid = (int*)calloc(pp.n_contrast, sizeof(int));
	pp.Z0_n = (int*)calloc(pp.n_contrast,sizeof(int));
	pp.Zg_n = (int*)calloc(pp.n_contrast,sizeof(int));
	pp.Y_n = (int*)calloc(pp.m1, sizeof(int));
	pp.Z_norm_prob = vec_list_alloc(Z_MAX, pp.n_contrast);
	pp.Z_mu = vec_alloc(pp.n_contrast);
	pp.s_id = (int*)calloc(pp.n_study+1,sizeof(int));
	pp.c_id = (int*)calloc(pp.n_contrast+1, sizeof(int));
	pp.s_num = (int*)calloc(pp.n_study,sizeof(int));
	pp.c_num = (int*)calloc(pp.n_contrast, sizeof(int));
	pp.Z_tB = vec_alloc(pp.n_contrast);
	pp.Z_tD = vec_alloc(pp.n_contrast);
	
	//Study
	for(int i=0; i<pp.n_study; i++)
	{
		pp.s_id[i] = j;
		id = pp.study1[j];
		while(pp.study1[j]== id && j<pp.m1-1)
			j++;
	}
	pp.s_id[pp.n_study] = pp.m1-1;
	
	//Contrast
	j = 0;
	id = 0;
	for(int i=0; i<pp.n_contrast; i++)
	{
		pp.c_id[i] = j;
		id = pp.contrast1[j];
		while(pp.contrast1[j]== id && j<pp.m1-1)
			j++;
	}
	pp.c_id[pp.n_contrast] = pp.m1;
	
	for(int i=0; i<pp.n_contrast; i++)
		pp.c_num[i] = pp.c_id[i+1] - pp.c_id[i];
	
	for(int i=0; i<pp.n_study; i++)
		pp.s_num[i] = pp.s_id[i+1] - pp.s_id[i];
	
	for(int i=0; i<pp.n_contrast; i++)
	{
		pp.Z_kappa[i] = (int*)calloc(Z_MAX,sizeof(int));
		for(int j=0; j<Z_MAX; j++)
			pp.Z_kappa[i][j] = -1;
		pp.Z_n[i] = (int*)calloc(Z_MAX,sizeof(int));
	}
	
	pp.matZ = Array_alloc(DIM, Z_MAX, pp.n_contrast);
	pp.sPACs = Array_alloc(DIM, SIM_MAX, pp.n_contrast);
	
	pp.numsPACs = (int*)calloc(pp.n_contrast, sizeof(int));
    
	pp.Zi = (int*)calloc(pp.m1, sizeof(int));
	pp.Zj = (int*)calloc(pp.m1, sizeof(int));
	
	pp.idx_Y = (int**)calloc(pp.n_contrast, sizeof(int*));
	for(int j=0; j<pp.n_contrast; j++)
	{
	    pp.idx_Y[j] = (int*)calloc(pp.c_num[j], sizeof(int));
	}
	
	pp.numZ = (int*)calloc(pp.n_contrast, sizeof(int));
	
	for(int i=0; i<pp.n_contrast; i++)
		pp.numZ[i] = 0;
    
	pp.Lambda = mat_mat_alloc(DIM, Z_MAX, pp.n_contrast);
	pp.invLambda = mat_mat_alloc(DIM, Z_MAX, pp.n_contrast);
	
	pp.id_study = (int**)calloc(MAX_N,sizeof(int*));
	pp.id_contrast = (int**)calloc(MAX_N, sizeof(int*));
	
	for(int i=0; i<MAX_N; i++)
	{
		pp.id_study[i] = (int*)calloc(pp.n_study,sizeof(int));
		pp.id_contrast[i] = (int*)calloc(1000, sizeof(int));
	}
	
	pp.dnorm_list = vec_list_alloc(MAX_N, pp.m1);
	pp.lambda_list = vec_alloc(pp.m1);
	pp.slambda_list = vec_alloc(pp.m1);
	pp.Z_lambda_list = vec_list_alloc(Z_MAX,pp.m1);
	pp.Z_dnorm_list = Array_alloc(Z_MAX, pp.n_contrast, pp.m1);
	pp.xi = vec_alloc(pp.n_contrast+1);
	pp.rho_all = vec_alloc(pp.n_contrast);
	
	for(int i=0; i<pp.n_contrast; i++)
		for(int j=0; j<pp.c_num[i]; j++)
		{
			pp.Zi[pp.c_id[i]+j] = i;
			pp.Zj[pp.c_id[i]+j] = j;
		}
	
	
	pp.n_ra = 0;
	pp.n_la = 0;
	for(int j=0; j<pp.m1; j++)
	{
		if(inRange(pp.dat[j],DIM,pp.Ramygdala,pp.dim))
			pp.n_ra++;
		
		if(inRange(pp.dat[j],DIM,pp.Lamygdala,pp.dim))
			pp.n_la++;
	}
	
	pp.la_id = (int*)calloc(pp.n_la, sizeof(int));
	pp.ra_id = (int*)calloc(pp.n_ra, sizeof(int));
	
	int tmpr = 0, tmpl =0;
	for(int j=0; j<pp.m1; j++)
	{
		if(inRange(pp.dat[j],DIM,pp.Lamygdala,pp.dim))
		{
			pp.la_id[tmpl] = j;
			tmpl++;
		}
		
		if(inRange(pp.dat[j],DIM,pp.Ramygdala,pp.dim))
		{
			pp.ra_id[tmpr] = j;
			tmpr++;
		}
	}
	
	pp.xi_acpt = 0;
	
	
	pp.orgin = vec_alloc(DIM);
	pp.orgin[0] = 45;
	pp.orgin[1] = 64;
	pp.orgin[2] = 36;
	
	
	
}


MY_DATATYPE16* read_img(const char* data_file, int* dim)
{
	nifti_1_header hdr;
	int ret;
	FILE* fp;
	MY_DATATYPE16* data = NULL;
	
	/********** open and read header */
    char headernm[1000];
    char imagenm[1000];
    sprintf(headernm,"%s.hdr", data_file);
    sprintf(imagenm, "%s.img", data_file);
    
    printf("%s\n",headernm);
    
	fp = fopen(headernm,"rb");
	if (fp == NULL) {
		fprintf(stderr, "\nError opening header file %s\n",data_file);
		exit(1);
	}
	ret = fread(&hdr, MIN_HEADER_SIZE, 1, fp);
	if (ret != 1) {
		fprintf(stderr, "\nError reading header file %s\n",data_file);
		exit(1);
	}
	fclose(fp);
	
	dim[0] = hdr.dim[1];
	dim[1] = hdr.dim[2];
	dim[2] = hdr.dim[3];
	
	
	/********** print a little header information */
	fprintf(stderr, "\n%s header information:",data_file);
	fprintf(stderr, "\nXYZT dimensions: %d %d %d %d",hdr.dim[1],hdr.dim[2],hdr.dim[3],hdr.dim[4]);
	fprintf(stderr, "\nDatatype code and bits/pixel: %d %d",hdr.datatype,hdr.bitpix);
	fprintf(stderr, "\nScaling slope and intercept: %.6f %.6f",hdr.scl_slope,hdr.scl_inter);
	fprintf(stderr, "\nByte offset to data in datafile: %ld",(long)(hdr.vox_offset));
	fprintf(stderr, "\n");
	
	/********** open the datafile, jump to data offset */
	fp = fopen(imagenm,"rb");
	if (fp == NULL) {
		fprintf(stderr, "\nError opening data file %s\n",data_file);
		exit(1);
	}
	
	/*ret = fseek(fp, (long)(hdr.vox_offset), SEEK_SET);
	if (ret != 0) {
		fprintf(stderr, "\nError doing fseek() to %ld in data file %s\n",(long)(hdr.vox_offset), data_file);
		exit(1);
	}*/
	
	
	/********** allocate buffer and read first 3D volume from data file */
	data = (MY_DATATYPE16 *) malloc(sizeof(MY_DATATYPE16) * hdr.dim[1]*hdr.dim[2]*hdr.dim[3]);
	if (data == NULL) {
		fprintf(stderr, "\nError allocating data buffer for %s\n",data_file);
		exit(1);
	}
	ret = fread(data, sizeof(MY_DATATYPE16), hdr.dim[1]*hdr.dim[2]*hdr.dim[3], fp);
	if (ret != hdr.dim[1]*hdr.dim[2]*hdr.dim[3]) {
		fprintf(stderr, "\nError reading volume 1 from %s (%d)\n",data_file,ret);
		exit(1);
	}
	fclose(fp);
	
	
	/*********** scale the data buffer  */
	/*if (hdr.scl_slope != 0) {
	 for (i=0; i<hdr.dim[1]*hdr.dim[2]*hdr.dim[3]; i++)
	 data[i] = (unsigned char)((data[i] * hdr.scl_slope) + hdr.scl_inter);
	 }*/
	
	return data;
}



MY_DATATYPE16 *** read_mask_img(const char*data_file,int* dim)
{
    MY_DATATYPE16 * dat = read_img(data_file, dim);
    MY_DATATYPE16*** imgdat = (MY_DATATYPE16***)malloc(sizeof(MY_DATATYPE16**)*dim[0]);
    int s = 0;
    for (int i=0; i<dim[0]; i++) {
        imgdat[i] = (MY_DATATYPE16**)malloc(sizeof(MY_DATATYPE16*)*dim[1]);
        for (int j=0; j<dim[1]; j++) {
            imgdat[i][j] = (MY_DATATYPE16*)malloc(sizeof(MY_DATATYPE16)*dim[2]);
          }
    }
    
    for (int k=0; k<dim[2]; k++) {
        for (int j=0; j<dim[1]; j++) {
            for (int i=0; i<dim[0]; i++) {
                imgdat[i][j][k] = dat[s];
                s++;
            }
        }
    }
    free(dat);
    return imgdat;
}


void free_mask_img(MY_DATATYPE16*** imgdat, int* dim)
{
    for (int i=0; i<dim[0]; i++) {
        for (int j=0; j<dim[1]; j++) {
            free(imgdat[i][j]);
        }
        free(imgdat[i]);
    }
    free(imgdat);
}

void print_mask_img(MY_DATATYPE16*** imgdat, int*dim, int slide)
{
    for(int j=0; j<dim[1]; j++)
    {
        for(int i=0; i<dim[0];i++)
        {
            printf("%4.0f",imgdat[i][j][slide]);
        }
        printf("\n");
    }
    
}

void print_mask_img_xyz(MY_DATATYPE16*** imgdat, int*dim, int x, int y, int z)
{
 
    if ((x<=dim[0]) && (y<=dim[1]) && (z<=dim[2]) && (x>=1) && (y>=1) && (z>=1)) {
        printf("(%d, %d, %d) = %4.3f\n",x,y,z,imgdat[x-1][y-1][z-1]);
    }

    
}



MY_DATATYPE* read_nii(const char* data_file, int* dim)
{
	nifti_1_header hdr;
	int ret;
	FILE* fp;
	MY_DATATYPE* data = NULL;
	
	/********** open and read header */
	fp = fopen(data_file,"rb");
	if (fp == NULL) {
		fprintf(stderr, "\nError opening header file %s\n",data_file);
		exit(1);
	}
	ret = fread(&hdr, MIN_HEADER_SIZE, 1, fp);
	if (ret != 1) {
		fprintf(stderr, "\nError reading header file %s\n",data_file);
		exit(1);
	}
	fclose(fp);
	
	dim[0] = hdr.dim[1];
	dim[1] = hdr.dim[2];
	dim[2] = hdr.dim[3];
	
	
	/********** print a little header information */
	fprintf(stderr, "\n%s header information:",data_file);
	fprintf(stderr, "\nXYZT dimensions: %d %d %d %d",hdr.dim[1],hdr.dim[2],hdr.dim[3],hdr.dim[4]);
	fprintf(stderr, "\nDatatype code and bits/pixel: %d %d",hdr.datatype,hdr.bitpix);
	fprintf(stderr, "\nScaling slope and intercept: %.6f %.6f",hdr.scl_slope,hdr.scl_inter);
	fprintf(stderr, "\nByte offset to data in datafile: %ld",(long)(hdr.vox_offset));
	fprintf(stderr, "\n");
	
	/********** open the datafile, jump to data offset */
	fp = fopen(data_file,"rb");
	if (fp == NULL) {
		fprintf(stderr, "\nError opening data file %s\n",data_file);
		exit(1);
	}
	
	ret = fseek(fp, (long)(hdr.vox_offset), SEEK_SET);
	if (ret != 0) {
		fprintf(stderr, "\nError doing fseek() to %ld in data file %s\n",(long)(hdr.vox_offset), data_file);
		exit(1);
	}
	
	
	/********** allocate buffer and read first 3D volume from data file */
	data = (MY_DATATYPE *) malloc(sizeof(MY_DATATYPE) * hdr.dim[1]*hdr.dim[2]*hdr.dim[3]);
	if (data == NULL) {
		fprintf(stderr, "\nError allocating data buffer for %s\n",data_file);
		exit(1);
	}
	ret = fread(data, sizeof(MY_DATATYPE), hdr.dim[1]*hdr.dim[2]*hdr.dim[3], fp);
	if (ret != hdr.dim[1]*hdr.dim[2]*hdr.dim[3]) {
		fprintf(stderr, "\nError reading volume 1 from %s (%d)\n",data_file,ret);
		exit(1);
	}
	fclose(fp);
	
	
	/*********** scale the data buffer  */
	/*if (hdr.scl_slope != 0) {
	 for (i=0; i<hdr.dim[1]*hdr.dim[2]*hdr.dim[3]; i++)
	 data[i] = (unsigned char)((data[i] * hdr.scl_slope) + hdr.scl_inter);
	 }*/
	
	return data;
}


void read_matlab_mask(const char* maskfile, points &pp)
{
	FILE* fid;
	int i, j, k;
	fid = fopen(maskfile, "rt");
	
	fscanf(fid, "%d %d %d\n", &(pp.dim[0]), &(pp.dim[1]),	&(pp.dim[2]));
	
	pp.mask = (MY_DATATYPE***)malloc(sizeof(MY_DATATYPE**)*pp.dim[0]);
	for(i=0; i<pp.dim[0]; i++)
	{
		pp.mask[i] = (MY_DATATYPE**)malloc(sizeof(MY_DATATYPE*)*pp.dim[1]);
		for(j=0; j<pp.dim[1]; j++)
		{
			pp.mask[i][j] = (MY_DATATYPE*)malloc(sizeof(MY_DATATYPE)*pp.dim[2]);
		}
	}
	
	
	pp.vol = 0;
	while(!feof(fid))
	{
		fscanf(fid, "%d %d %d\n", &i,&j, &k);
		pp.mask[i-1][j-1][k-1] = 1;
		pp.vol++;
	}
	fclose(fid);
}

void read_mask(const char* maskfile, points &pp)
{
	MY_DATATYPE* data = read_nii(maskfile,pp.dim);
	int t = 0;
	pp.mask = (MY_DATATYPE***)malloc(sizeof(MY_DATATYPE**)*pp.dim[0]);
	for(int i=0; i<pp.dim[0]; i++)
	{
		pp.mask[i] = (MY_DATATYPE**)malloc(sizeof(MY_DATATYPE*)*pp.dim[1]);
		for(int j=0; j<pp.dim[1]; j++)
		{
			pp.mask[i][j] = (MY_DATATYPE*)malloc(sizeof(MY_DATATYPE)*pp.dim[2]);
		}
	}
	
	pp.vol = 0;
	for(int k=0; k<pp.dim[2];k++)
		for(int j=0; j<pp.dim[1]; j++)
			for(int i=0;i<pp.dim[0]; i++)
			{
				if (data[t]>MASK_THRESH)
				{
				    pp.mask[i][j][k] = 1;
					pp.vol += pp.mask[i][j][k];
				}
				t++;
			}
	free(data);
}


void read_amygdala(points &pp)
{
	MY_DATATYPE* Ldata = read_nii("Amygdala_L.nii", pp.dim);
	MY_DATATYPE* Rdata = read_nii("Amygdala_R.nii", pp.dim);
	int t;
	
	pp.Lamygdala = (MY_DATATYPE***)malloc(sizeof(MY_DATATYPE**)*pp.dim[0]);
	pp.Ramygdala = (MY_DATATYPE***)malloc(sizeof(MY_DATATYPE**)*pp.dim[0]);
	for(int i=0; i<pp.dim[0]; i++)
	{
		pp.Lamygdala[i] = (MY_DATATYPE**)malloc(sizeof(MY_DATATYPE*)*pp.dim[1]);
		pp.Ramygdala[i] = (MY_DATATYPE**)malloc(sizeof(MY_DATATYPE*)*pp.dim[1]);
		for(int j=0; j<pp.dim[1]; j++)
		{
			pp.Lamygdala[i][j] = (MY_DATATYPE*)malloc(sizeof(MY_DATATYPE)*pp.dim[2]);
			pp.Ramygdala[i][j] = (MY_DATATYPE*)malloc(sizeof(MY_DATATYPE)*pp.dim[2]);
		}
	}
	
	t = 0;
	for(int k=0; k<pp.dim[2];k++)
		for(int j=0; j<pp.dim[1]; j++)
			for(int i=0;i<pp.dim[0]; i++)
			{
			    pp.Lamygdala[i][j][k] = Ldata[t];
				pp.Ramygdala[i][j][k] = Rdata[t];
				t++;
			}
	free(Ldata);
	free(Rdata);
}

double* tprob(points &pp, pars &p,unsigned long* seed, int iters)
{
	double* tp = vec_alloc(pp.m);
	double**S0 = mat_copy(p.S,DIM);
	
	
	for(int j=0; j<pp.m; j++)
	{
		mat_times_k(S0,DIM,1.0/(pp.W[j]*(p.df_S-2)));
		tp[j] = pmvt(pp.mask,pp.dim,S0,DIM,pp.Y[j],p.df_S-2,iters,seed);
		mat_copyval(S0,p.S,DIM);
		//printf("%d %lf\n",j,tp[j]);
	}
	
	mat_free(S0,DIM);	
	return tp;
}

void ttprob(double *tp, points &pp, pars &p,unsigned long* seed, int iters)
{
	double**S0 = mat_copy(p.S,DIM);
	
	for(int j=0; j<pp.m; j++)
	{
		mat_times_k(S0,DIM,1.0/(pp.W[j]*(p.df_S-2)));
		tp[j] = pmvt(pp.mask,pp.dim,S0,DIM,pp.Y[j],p.df_S-2,iters,seed);
		mat_copyval(S0,p.S,DIM);
	}
	
	mat_free(S0,DIM);	
}

int prob_region(points &pp, double* eigen_value, double* eigen_vector, double*X, double thresh)
{
	double temp[DIM];
	int flag  = 0;
	
	for(int i=0; i<DIM; i++)
	{
		for(int j=0; j<DIM; j++)
			temp[j] = X[j] + thresh*sqrt(eigen_value[i])*eigen_vector[DIM*i+j];
		flag = inRange(temp, DIM,pp.mask, pp.dim);
		if(flag==0)
			break;
		for(int j=0; j<DIM; j++)
			temp[j] = X[j] - thresh*sqrt(eigen_value[i])*eigen_vector[DIM*i+j];
		flag = inRange(temp, DIM,pp.mask, pp.dim);
		if(flag==0)
			break;
	}
	
	return flag;
	
}

void approx_tprob(double *tp, points &pp, pars &p, unsigned long* seed, int iters)
{
	double***S0list = mat_list_alloc(DIM, p.V_n);
	double** eigen_value = vec_list_alloc(DIM, p.V_n);
	double** eigen_vector = vec_list_alloc(DIM*DIM, p.V_n);
	
	
	for(int k=0; k<p.V_n; k++)
	{
		S0list[k] = mat_copy(p.S, DIM);
		mat_times_k(S0list[k],DIM,1.0/(p.V[k]*(p.df_S-2)));
		eigen(eigen_vector[k], eigen_value[k], S0list[k]); 
	}
	
	for(int j=0; j<pp.m; j++)
	{
		if (prob_region(pp, eigen_value[pp.W_id[j]], eigen_vector[pp.W_id[j]], pp.Y[j], THRESH)==1)
		{
			tp[j] = TRUNC_PROB;
		}
		else
		{
			tp[j] = pmvt(pp.mask,pp.dim,S0list[pp.W_id[j]],DIM,pp.Y[j],p.df_S-2,iters,seed);
		}
	}
	
	mat_list_free(S0list, DIM,p.V_n);
	vec_list_free(eigen_value,p.V_n);
	vec_list_free(eigen_vector, p.V_n);
}

double birth_rate_T(double *prob, points &pp, pars &p, double* tp)
{
	int j;
	
	prob[0] = pp.vol;
	
	for(j=0;j<pp.m;j++)
		prob[j+1] =  prob[j] + p.theta/p.eps*tp[j]*p.phi[pp.W_id[j]];
	
	//printf("prob[%d] = %g\n",pp.m, prob[pp.m]);
	p.totalBirthRate = prob[pp.m]*p.beta;
	for(j=0;j<pp.m+1;j++)
		prob[j] /= prob[pp.m]; 
	
	return p.totalBirthRate;
}

double mat_det(double ** X, int size)
{
	double** temp = mat_copy(X,size);
	cholesky_decomp(temp, size);
	double det = 1;
	for(int i=0; i<size; i++)
		det *= temp[i][i];
	det*= det;
	
	mat_free(temp, size);
	
	return det;
}

void mat_k(double **X, double k)
{
	for(int i=0; i<DIM; i++)
		for(int j=0; j<DIM; j++)
			X[i][j] *= k;
}

double mat_trace(double** X, int size)
{
	double trace = 0;
	
	for(int i=0; i<size; i++)
		trace += X[i][i];
	
	return trace;
}

double** mat_inv(double** X, int size)
{
	double** Y = mat_copy(X,size);
	
	cholesky_decomp(Y, size);
	cholesky_invert(size, Y);
	
	return Y;
}

void mat_inv3(double**invA,double** a)
{
	
	double detA = a[0][0]*(a[1][1]*a[2][2] - a[1][2]*a[1][2]) - a[1][1]*a[0][2]*a[0][2] + a[0][1]*(2*a[0][2]*a[1][2] - a[2][2]*a[0][1]);
	
	invA[0][0] = a[1][1]*a[2][2] - a[1][2]*a[1][2];
	invA[0][1] = a[0][2]*a[1][2] - a[0][1]*a[2][2];
	invA[0][2] = a[0][1]*a[1][2] - a[0][2]*a[1][1];
	invA[1][0] = invA[0][1];
	invA[1][1] = a[0][0]*a[2][2] - a[0][2]*a[0][2];
	invA[1][2] = a[0][1]*a[0][2] - a[0][0]*a[1][2];
	invA[2][0] = invA[0][2];
	invA[2][1] = invA[1][2];
	invA[2][2] = a[0][0]*a[1][1] - a[0][1]*a[0][1];
	
	for(int i=0; i<DIM; i++)
		for(int j=0; j<DIM; j++)
			invA[i][j] = invA[i][j]/detA;
	
}


void mat_t_vec(double* v1, double**A, double*v)
{
	
	for(int i=0; i<DIM; i++)
	{
		v1[i] = 0;
		for(int j=0; j<DIM; j++)
			v1[i] += A[i][j]*v[j];
	}
}

double** mat_multiply(double ** X, double ** Y, int size)
{
	double** Z = mat_alloc(size);
	
	for(int i=0; i<size; i++)
		for(int j=0; j<size; j++)
		{
			Z[i][j] = 0;
			for(int k=0; k<size; k++)
				Z[i][j] += X[i][k]*Y[k][j];
		}
	
	return Z;
}

void mat_mul(double** result, double** X, double ** Y, int size)
{
	for(int i=0; i<size; i++)
		for(int j=0; j<size; j++)
		{
			result[i][j] = 0;
			for(int k=0; k<size; k++)
				result[i][j] += X[i][k]*Y[k][j];
		}
}

void mat_times_vec(double* res, double** mat, double*vec, int size)
{
	
	for(int i=0; i<size; i++)
	{
		res[i] = 0;
		for(int j=0; j<size;j++)
		{
			res[i] += mat[i][j]*vec[j];
		}
	}
}

void mat_plus(double** result, double**X, double**Y, int size)
{
	for(int i=0; i<size; i++)
		for(int j=0; j<size; j++)
		{
			result[i][j] = X[i][j] + Y[i][j];
		}
}

void vec_plus(double*v3, double*v1, double*v2)
{
	for(int i=0; i<DIM; i++)
		v3[i] = v1[i] + v2[i];
}

void mat_inverse(double** result, double**X, int size)
{
	mat_copyval(result, X, size);
	cholesky_decomp(result, size);
	cholesky_invert(size, result);
}


//Density function of invWishart Distribution 
double dinvWishart(double** Sigma, double** S, int size, int df)
{
	double t0 = pow(2.0,df*size/2.0)*pow(3.1415926,size*(size-1.0)/4.0);
	double t1 = 1.0;
	double y = t0;
	for(int i=1; i<= size; i++)
	{
		t1*= gamma((df+1-i)/2.0);
	}
	y *= t1;
	y = 1/y;
	
	double t2 = pow(mat_det(S,size),df/2.0);
	y *= t2;
	
	double t3 =  pow(mat_det(Sigma, size),-(size+df+1)/2.0);
	y *= t3;
	
	double**W = mat_inv(Sigma, size);
	double**temp = mat_multiply(S, W,size);
	double t4 = exp(-mat_trace(temp, size)/2.0);
	
	y *= t4;
	
	mat_free(W, size);
	mat_free(temp, size);
	
	return y;
}

void update_dnormlist(points &pp, pars &p)
{
	//double** Sigma = mat_alloc(DIM);
	
	for(int j=0; j<pp.m; j++)
	{
		pp.lambda_list[j] = 0;
		for(int i=0; i<p.n; i++)
		{
			//mat_copyval(Sigma, p.SigmaInv[i], DIM);
			//mat_times_k(Sigma, DIM, pp.W[j]);
			pp.dnorm_list[j][i] = dmvnorm1(pp.Y[j], p.SigmaInv[i], DIM, p.X[i]);
			pp.lambda_list[j] += pp.dnorm_list[j][i];
		}
		pp.lambda_list[j] = p.eps + pp.lambda_list[j]*p.theta;
	}
	
	//mat_free(Sigma, DIM);
}

void add_dnormlist(points &pp, pars &p)
{
	//double** Sigma = mat_alloc(DIM);
	
	for(int j=0; j<pp.m; j++)
	{
		//mat_copyval(Sigma, p.SigmaInv[p.n], DIM);
		//mat_times_k(Sigma, DIM, pp.W[j]);
		pp.dnorm_list[j][p.n] = dmvnorm1(pp.Y[j], p.SigmaInv[p.n], DIM, p.X[p.n]);			
		pp.lambda_list[j] += p.theta*pp.dnorm_list[j][p.n];
	}
	//mat_free(Sigma, DIM);
}

void rm_dnormlist(int idx, points &pp, pars &p)
{
	for(int j=0; j<pp.m; j++)
	{
		pp.lambda_list[j] -= pp.dnorm_list[j][idx]*p.theta;
		pp.dnorm_list[j][idx] = pp.dnorm_list[j][p.n-1];
	}
}

double death_rate_T(double* prob, points &pp, pars &p,unsigned long* seed)
{
	double part1 = 0, part2 = 0, part3 = 0;
	double* templist = vec_alloc(pp.m);
	double temp;
	//double** Sigma = mat_alloc(DIM);
	
	
	p.totalDeathRate = 0.0;
	
	/*	for(int j=0; j<pp.m; j++)
	 {
	 for(int i=0; i<p.n; i++)
	 {
	 mat_copyval(Sigma, p.SigmaInv[i], DIM);
	 mat_times_k(Sigma, DIM, pp.W[j]);
	 dnorm_list[j][i] = dmvnorm1(pp.Y[j], Sigma, DIM, p.X[i]);
	 lambda_list[j] += dnorm_list[j][i];
	 }
	 lambda_list[j] = p.eps + lambda_list[j]*p.theta;
	 }*/
	
	for(int i=0; i<p.n; i++)
	{
		part1 = 0.0;
		for(int k=0; k<p.V_n; k++)
		{
			//mat_copyval(Sigma, p.Sigma[i], DIM);
			//mat_times_k(Sigma, DIM, 1.0/p.V[k]);
			part1 += p.phi[k]*pmvnorm(pp.mask, pp.dim,p.Sigma[i], DIM, p.X[i], SIMUL, seed);
		}
		part1 *= p.theta;
		
		//printf("part1 =  %lf\n", part1);
		
		
		//mat_exchange(SigmaList[i], SigmaList[p.n-1], DIM);
		//vec_exchange(X[i], X[p.n-1], DIM);
		
		part2 = 1.0;
		//int k = 0;
		for(int j=0; j<pp.m; j++)
		{
			//mat_copyval(Sigma, p.Sigma[i], DIM);
			//mat_times_k(Sigma, DIM, 1.0/pp.W[j]);
			templist[j] = p.theta*pp.dnorm_list[j][i];
			temp = templist[j]/(pp.lambda_list[j]-templist[j]);
			part2 += log1p(temp);
		}
		
		
		/* printf("part2 =  %lf\n", part2);
		 */		
		//mat_exchange(SigmaList[i], SigmaList[p.n-1], DIM);
		//vec_exchange(X[i], X[p.n-1], DIM);
		
		part3 = 0.0;
		for(int j=0; j<pp.m; j++)
		{
			part3 += templist[j]*p.phi[pp.W_id[j]];
		}
		part3 /= p.eps;
		part3 = log1p(part3);
        //part3 += log(dinvWishart(p.Sigma[i], p.S, DIM, p.df_S));
		
		//printf("part3 =  %lf\n", part3);
		
		
		
		prob[i] = part1-part2+part3;
		
		/*if (p.BorD == 1)
		 {
		 fprintf(p.temp_fid,"%9d      Birth %15d %10d %17lf %17lf %17lf %17lf %30lf\n", 
		 p.iters, p.n, i, part1, part2, part3, prob[i], exp(prob[i]));
		 }
		 else if(p.BorD==2)
		 {
		 fprintf(p.temp_fid,"%9d      Death %15d %10d %17lf %17lf %17lf %17lf %30lf\n", 
		 p.iters, p.n, i, part1, part2, part3, prob[i], exp(prob[i]));
		 }
		 fflush(p.temp_fid);*/
		
		//printf("log(death) = %lf \n", prob[i]);
	}
	
	
	for(int i=0; i<p.n; i++)
	{
		p.totalDeathRate +=  exp(prob[i]);
	}
	
	
	double max_log_prob = prob[0];
	for(int i=1; i<p.n; i++)
	{
		if(max_log_prob < prob[i])
		{
			max_log_prob = prob[i];
		}
	}
	
	for(int i=0; i<p.n; i++)
	{
		prob[i] = exp(prob[i] - max_log_prob);
	}
	
	for(int i=1; i<p.n; i++)
		prob[i] += prob[i-1];
	
	
	for(int i=0; i<p.n; i++)
		prob[i] /= prob[p.n-1];
	
	//mat_list_free(SigmaList, DIM, p.n);
	//mat_free(Sigma, DIM);
	//vec_list_free(X, p.n);
	free(templist);
	
	
	//fprintf(p.temp_fid, "%10d %110lf (total)\n", p.iters, totalDeathRate);
	return p.totalDeathRate;
}

void rinverse_wishart(double** results, double** S, int df,unsigned long* seed)
{
	double** S0 = mat_alloc(DIM);
	double** temp = mat_alloc(DIM);
	
	mat_inverse(S0, S, DIM);
	//printf("S: \n"); mat_print(S, DIM, " %4.2f");
	//printf("S0: \n"); mat_print(S0, DIM, " %4.2f");
	
	rwishart(temp, S0, DIM, df, seed);
	//mat_print(temp, DIM, " %4.2f");
    
	mat_inverse(results, temp, DIM);
	//mat_print(results,DIM," %4.2f");
	
	mat_free(S0, DIM);
	mat_free(temp, DIM);
	
}


int give_a_birth(double *prob, points &pp, pars &p,unsigned long* seed)
{
	int i = (int) rmultinomial(prob, pp.m+1, seed);
	//double** Sigma = mat_alloc(DIM);
	double** tmpmat = mat_alloc(DIM);
	
	mat_inverse(tmpmat, p.S,DIM);
	rwishart(p.SigmaInv[p.n], tmpmat,DIM, p.df_S, seed);
	mat_inverse(p.Sigma[p.n], p.SigmaInv[p.n], DIM);
	
	//rinverse_wishart(p.Sigma[p.n], p.S, p.df_S, seed);
	//mat_inverse(p.SigmaInv[p.n], p.Sigma[p.n], DIM);
	
	if (i==0)
	{
		for(int k=0; k<DIM; k++)
			p.X[p.n][k] = kiss(seed)*pp.dim[k];
	}
	else
	{
		//mat_copyval(Sigma, p.Sigma[p.n], DIM);
		//mat_times_k(Sigma, DIM, 1/pp.W[i-1]);
		rmvnorm(p.X[p.n], p.Sigma[p.n], DIM, pp.Y[i-1], seed, 0);
	}
	
	//mat_free(Sigma, DIM);
	mat_free(tmpmat,DIM);
	
	double temp;
	for(int i=0; i<p.n; i++)
	{
		temp = 0.0;
		for(int k=0; k<3; k++)
			temp += (p.X[p.n][k]-p.X[i][k])*(p.X[p.n][k]-p.X[i][k]);
		if(temp<p.radius2)
			return 0;
	}
	
	if(inRange(p.X[p.n], DIM, pp.mask, pp.dim))
	{
		//printf("birth\n");
		pp.numOfBirth ++;
		return 1;
		
	}
	
	return 0;
}



double birth_rate(double *prob, double**Sigma,points &pp, pars &p, unsigned long *seed,int iters)
{
	int j;
	double totalBirthRate;
	double ** Sigma0 = mat_copy(Sigma,DIM);
	
	prob[0] = pp.vol;
	
	for(j=0;j<pp.m;j++)
	{
		mat_times_k(Sigma0,DIM,1.0/pp.W[j]);
		prob[j+1] =  prob[j] + p.theta/p.eps*p.phi[pp.W_id[j]]*pmvnorm(pp.mask,pp.dim,Sigma0,DIM,pp.Y[j],iters,seed);
		mat_copyval(Sigma0,Sigma,DIM);
	}
	
	totalBirthRate = prob[pp.m]*p.beta;
	for(j=0;j<pp.m+1;j++)
		prob[j] /= prob[pp.m]; 
	
	mat_free(Sigma0,DIM);
	
	return totalBirthRate;
}


void rm_centers(int idx, pars &p, points &pp)
{
	if(idx<p.n-1)
	{
	/*	for(int i=0; i<pp.m; i++)
		{
			if(pp.kappa[i]==idx)
			{
				pp.kappa[i] = -1;
			}
			else if (pp.kappa[i]==p.n-1)
			{
				pp.kappa[i] = idx;
			}
		}*/
		mat_copyval(p.SigmaInv[idx], p.SigmaInv[p.n-1], DIM);
		mat_copyval(p.Sigma[idx], p.Sigma[p.n-1], DIM);
		vec_copyval(p.X[idx], p.X[p.n-1], DIM);
		//p.Num[idx] = p.Num[p.n-1];
		p.update_indicator[p.n-1] = 0;
		rm_dnormlist(idx, pp, p);
	}
	p.n--;	
}

void spatial_birth_death(double *tp, points &pp, pars &p, int steps, unsigned long* seed)
{
	double r,t;
	
	double bd_time = 100.0;
	
	double* bprob = vec_alloc(pp.m+1);
	double* dprob = vec_alloc(MAX_N+1);
	int idx, i;
	
	if (p.totalBirthRate>0)
	{
		bd_time = 1.0/p.totalBirthRate;
	}
	
	
	birth_rate_T(bprob, pp, p, tp);
	
	i = 0;
	//death_rate_T(dprob, pp, p, seed);
	t = 0;
	//printf("bd_time : %lf\n", bd_time);
	//printf("t: %lf\n", t);
	//printf("tbr: %lf\n", p.totalBirthRate);
	//printf("tdr: %lf\n", p.totalDeathRate);
	
	update_dnormlist(pp, p);
	
	while(i<steps && t< bd_time)
	{
		death_rate_T(dprob, pp, p, seed);
		//printf("birthRate = %g, deathrate = %g \n",p.totalBirthRate, p.totalDeathRate);
		r = kiss(seed);
		if(r<p.totalBirthRate/(p.totalBirthRate+p.totalDeathRate) && p.n<MAX_N-1)
		{
			p.BorD = 1;
			if(give_a_birth(bprob, pp, p, seed))
			{
				add_dnormlist(pp, p);
				p.n++;
				p.update_indicator[p.n-1] = 1;
			}
			
		}
		else 
		{
			p.BorD = 2;
			idx = rmultinomial(dprob, p.n, seed);
			rm_centers(idx, p, pp);
			/*mat_copyval(p.Sigma[idx], p.Sigma[p.n-1], DIM);
			 vec_copyval(p.X[idx], p.X[p.n-1], DIM);
			 p.update_indicator[p.n-1] = 0;
			 p.n--;*/			
			pp.numOfDeath++;
			//printf("death\n");
		}
		i++;
		
		/*if(p.BorD ==1)
		 printf("BD process %d(%d): birth \n", i, steps);
		 else
		 printf("BD process %d(%d): death \n", i, steps);*/
		
		
		t += rexp(p.totalBirthRate+p.totalDeathRate, seed);
	}
	
	free(bprob);
	free(dprob);
}




void spatial_birth_death_1(double *tp, points &pp, pars &p, int steps, unsigned long* seed)
{
	double r;
	
	double* bprob = vec_alloc(pp.m+1);
	double* dprob = vec_alloc(p.n+1);
	int idx;
	
	birth_rate_T(bprob, pp, p, tp);
	steps = rpois(steps, seed);
	
	for(int i=0; i<steps; i++)
	{
		death_rate_T(dprob, pp, p, seed);
		r = kiss(seed);
		if(r<p.totalBirthRate/(p.totalBirthRate+p.totalDeathRate))
		{
			p.BorD = 1;
			if(give_a_birth(bprob, pp, p, seed))
			{
				p.n++;
				p.update_indicator[p.n-1] = 1;
			}
			
		}
		else 
		{
			p.BorD = 2;
			idx = rmultinomial(dprob, p.n, seed);
			mat_copyval(p.Sigma[idx], p.Sigma[p.n-1], DIM);
			mat_copyval(p.SigmaInv[idx], p.SigmaInv[p.n-1], DIM);
			vec_copyval(p.X[idx], p.X[p.n-1], DIM);
			p.update_indicator[p.n-1] = 0;
			
			p.n--;			
		}
	}
	
	free(bprob);
	free(dprob);
}


int birth_death(double* tp, points &pp, pars &p, unsigned long* seed)
{
	double r = kiss(seed);
	double r1;
	double* bprob = vec_alloc(pp.m+1);
	double* dprob = vec_alloc(p.n+1);
	int idx;
	
	birth_rate_T(bprob, pp, p, tp);
	if(r<0.5)
	{
		//Birth
		//printf("-------Birth Step-------\n");
		p.BorD = 1;
		if(give_a_birth(bprob, pp, p, seed))
		{
			p.n++;
			death_rate_T(dprob, pp, p, seed);
			
			free(bprob);
			free(dprob);
			if (p.totalDeathRate==0)
				return 1;
			r1 = kiss(seed);
			if (r1<p.totalBirthRate/p.totalDeathRate)
			{
				p.update_indicator[p.n-1] = 1;
				return 1;
			}
			p.n--; 
		}
		else
		{
			p.totalDeathRate = -1.0;
		}
	}
	else
	{
		//printf("-------Death Step-------\n");
		p.BorD = 2;
		if(p.n==0)
		{
			free(bprob);
			free(dprob);
			return 0;
		}
		//Death
		death_rate_T(dprob, pp, p, seed);
		idx = rmultinomial(dprob, p.n, seed);
		free(bprob);
		free(dprob);
		r1 = kiss(seed);
		if (r1 < p.totalDeathRate/p.totalBirthRate)
		{
			//mat_exchange(p.Sigma[idx], p.Sigma[p.n-1], DIM);
			//vec_exchange(p.X[idx], p.X[p.n-1], DIM);
			mat_copyval(p.Sigma[idx], p.Sigma[p.n-1], DIM);
			mat_copyval(p.SigmaInv[idx], p.SigmaInv[p.n-1], DIM);
			vec_copyval(p.X[idx], p.X[p.n-1], DIM);
			p.update_indicator[p.n-1] = 0;
			p.n--;
			return -1;
		}
		
	}
	return 0;
}



int update_kappa(points &pp, pars &p, unsigned long *seed)
{
	double* prob = vec_alloc(p.n+1);
	double** Sigma = mat_alloc(DIM);
	
	
	
	for(int i=0; i<p.n; i++)
	{
		p.Num[i] = 0;
		p.studyNum[i] = 0;
		p.contrastNum[i] = 0;
		for(int k=0; k<pp.n_study; k++)
			pp.id_study[i][k] = 0;
		for(int k=0; k<pp.n_contrast; k++)
			pp.id_contrast[i][k] = 0;
	}
	
	p.N0 = 0;
	
	for(int j=0; j<pp.m; j++)
	{
		
		//	if(j==170)
		//	{
		//		int st = 1;
		//	}
		prob[0] = p.eps; 
		for(int i=0; i<p.n; i++)
		{
			//		mat_copyval(Sigma, p.SigmaInv[i], DIM);
			//		mat_times_k(Sigma, DIM, pp.W[j]);
			prob[i+1] = prob[i] + p.theta*pp.dnorm_list[j][i];
		}
		for(int i=0; i<p.n+1; i++)
		{
			prob[i] /= prob[p.n];
		}
		pp.kappa[j] = rmultinomial(prob, p.n+1, seed)-1;
		if (pp.kappa[j] > -1 && (pp.kappa[j]<p.n))
		{
			p.Num[pp.kappa[j]]++;
			//pp.id_study[pp.kappa[j]][pp.study[j]-1]++;
			//pp.id_contrast[pp.kappa[j]][pp.contrast[j]-1]++;
		}
		else
		{
			p.N0 ++;
		}
	}
	
	
	for(int i=0; i<p.n; i++)
	{
		for(int j=0; j<pp.n_study; j++)
			if (pp.id_study[i][j]>0)
				p.studyNum[i]++;
		
		for(int j=0; j<pp.n_contrast; j++)
			if (pp.id_contrast[i][j]>0)
				p.contrastNum[i]++;
		
	}
	
	
	free(prob);
	mat_free(Sigma, DIM);
	return 1;
}


void rec_Amygdala(FILE* fid, pars &p, points &pp)
{
	int Ltab[2][3], Rtab[2][3], Ltot, Rtot, LPop,RPop, LCon, RCon;
	int* Lcontrast = (int*)calloc(pp.n_contrast+pp.m1,sizeof(int));
	int* Rcontrast = (int*)calloc(pp.n_contrast+pp.m1,sizeof(int));
	
	
	for(int i=0; i<2; i++)
		for(int j=0; j<3; j++)
		{
			Ltab[i][j] = 0;
			Rtab[i][j] = 0;
		}
	
	Ltot = 0;
	Rtot = 0;
	LPop = 0;
	RPop = 0;
	
	for(int i=0; i<p.n; i++)
	{
		if(inRange(p.X[i],DIM,pp.Lamygdala,pp.dim)==1)
			LPop++;
		
		if(inRange(p.X[i],DIM,pp.Ramygdala,pp.dim)==1)
			RPop++;
	}
	
	for(int i=0; i<pp.m; i++)
	{
		if(inRange(pp.Y[i], DIM, pp.Lamygdala, pp.dim)==1)
		{
			if(pp.kappa[i]>-1)
			{
				if(inRange(p.X[pp.kappa[i]],DIM,pp.Lamygdala,pp.dim)==1)
					Ltab[0][0]++;
				else
					Ltab[0][1]++;
			}
			else
			{
				Ltab[0][2]++;
			}
			Ltot++;
			Lcontrast[pp.contrast[i]] = 1;
            //fprintf(fid,"%d %lf %lf %lf \n",i+1, pp.Y[i][0],pp.Y[i][1],pp.Y[i][2]);
		}
		else
		{
			if(pp.kappa[i]>-1)
			{
				if(inRange(p.X[pp.kappa[i]],DIM,pp.Lamygdala,pp.dim)==1)
					Ltab[1][0]++;
				else
					Ltab[1][1]++;
			}
			else
			{
				Ltab[1][2]++;
			}
		}
		
		if(inRange(pp.Y[i], DIM, pp.Ramygdala, pp.dim)==1)
		{
			if(pp.kappa[i]>-1)
			{
				if(inRange(p.X[pp.kappa[i]],DIM,pp.Ramygdala,pp.dim)==1)
					Rtab[0][0]++;
				else
					Rtab[0][1]++;
			}
			else
			{
				Rtab[0][2]++;
			}
			Rtot++;
			Rcontrast[pp.contrast[i]] = 1;
		}
		else
		{
			if(pp.kappa[i]>-1)
			{
				if(inRange(p.X[pp.kappa[i]],DIM,pp.Ramygdala,pp.dim)==1)
					Rtab[1][0]++;
				else
					Rtab[1][1]++;
			}
			else
			{
				Rtab[1][2]++;
			}
		}
		
	}
	
	LCon = 0;
	RCon = 0;
	for(int i=0; i< pp.n_contrast+pp.m1; i++)
	{
		LCon += Lcontrast[i]; 
		RCon += Rcontrast[i]; 
	}
	
	
	fprintf(fid, "%10d",p.iters);
	for(int i=0; i<2; i++)
		for(int j=0; j<3; j++)
			fprintf(fid, "%10d", Ltab[i][j]);
    fprintf(fid,"%10d", Ltot);
	for(int i=0; i<2; i++)
		for(int j=0; j<3; j++)
			fprintf(fid, "%10d", Rtab[i][j]);
    fprintf(fid,"%10d%10d%10d%10d%10d\n", Rtot,LPop, RPop, LCon, RCon);
	//	fprintf(fid,"%10d", LPop);
	//	fprintf(fid,"%10d", RPop);
	//	fprintf(fid, "\n");
	fflush(fid);
	free(Lcontrast);
	free(Rcontrast);
}

void nporb_cal(points &pp, pars &p, unsigned long* seed)
{
	//double** Sigma = mat_alloc(DIM);
	
	for(int i=0; i<p.n; i++)
		if(p.update_indicator[i]==1)
			for(int k=0; k<p.V_n; k++)
			{
				//mat_copyval(Sigma, p.Sigma[i], DIM);
				//mat_times_k(Sigma, DIM, 1.0/p.V[k]);
				if(k==0)
				p.norm_prob[i][k] = pmvnorm(pp.mask,pp.dim,p.Sigma[i], DIM, p.X[i], SIMUL, seed); 
				else {
					p.norm_prob[i][k] = p.norm_prob[i][0];
				}

			}
	
	//mat_free(Sigma, DIM);
}

void update_nprob(int i, points &pp, pars &p, unsigned long* seed)
{
	//double** Sigma = mat_alloc(DIM);
	for(int k=0; k<p.V_n; k++)
	{
		//mat_copyval(Sigma, p.Sigma[i], DIM);
		//mat_times_k(Sigma, DIM, 1.0/p.V[k]);
		if(k==0)
		p.norm_prob[i][k] = pmvnorm(pp.mask,pp.dim,p.Sigma[i], DIM, p.X[i], SIMUL, seed); 
		else {
			p.norm_prob[i][k] = p.norm_prob[i][0];
		}

	}
	//mat_free(Sigma, DIM);
}

void mu_cal(points &pp, pars &p, unsigned long* seed)
{
	double mu = 0;
	double temp = 0;
	
	for(int k=0; k<p.V_n; k++)
	{
		temp = 0;
		for(int i=0; i<p.n; i++)
		{
			//mat_copyval(Sigma, p.Sigma[i], DIM);
			//mat_times_k(Sigma, DIM, 1.0/p.V[k]);
			//temp += pmvnorm(pp.mask, pp.dim, Sigma, DIM, p.X[i], SIMUL, seed);
			temp += p.norm_prob[i][k];
			//printf("norm_prob = %lf\n", p.norm_prob[i][k]);
		}
		temp*= p.phi[k];
		mu += temp;
	}
	
    mu*=p.theta;
	p.mu = mu + (p.eps*pp.vol);
}


void update_Sigma(points &pp, pars &p, unsigned long* seed)
{
	double** Sigma = mat_alloc(DIM);
	double** SigmaInv = mat_alloc(DIM);
	double*** S0list = mat_list_alloc(DIM, p.n);
	double** S0 = mat_alloc(DIM);
	double** temp = mat_alloc(DIM);
	double* tempprob = vec_alloc(p.V_n);
	double muOld = p.mu;
	
	for(int i=0; i<p.n; i++)
	{
		mat_copyval(S0list[i], p.S, DIM);
	}
	
	
	for(int j=0; j<pp.m; j++)
	{
		if(pp.kappa[j]>-1)
		{
			//	if(j==339)
			//		int st = 1;
			
			for(int a=0; a<DIM; a++)
				for(int b=0; b<DIM; b++)
					S0list[pp.kappa[j]][a][b] += pp.W[j]*(pp.Y[j][a]-p.X[pp.kappa[j]][a])*(pp.Y[j][b]-p.X[pp.kappa[j]][b]);
		}
		
	}
	
	
	
	for(int i=0; i<p.n; i++)
	{
		
		mat_copyval(SigmaInv, p.SigmaInv[i], DIM);
		mat_inverse(temp, S0list[i],DIM);
		rwishart(p.SigmaInv[i], temp, DIM, p.df_S+p.Num[i], seed);
		mat_inverse(p.Sigma[i], p.SigmaInv[i], DIM);
		mat_copyval(Sigma, p.Sigma[i], DIM);
		
		//mat_copyval(Sigma, p.Sigma[i], DIM);
		//rinverse_wishart(p.Sigma[i], S0list[i], p.df_S+p.Num[i], seed);
		
		vec_copyval(tempprob, p.norm_prob[i], p.V_n);
		update_nprob(i, pp, p, seed);
		mu_cal(pp, p, seed);
		if (log(kiss(seed))>pp.m*log(muOld/p.mu))
		{
			mat_copyval(p.SigmaInv[i], SigmaInv, DIM);
			mat_copyval(p.Sigma[i], Sigma, DIM);
			p.mu = muOld;
			vec_copyval(p.norm_prob[i], tempprob, p.V_n);
		}
		else
		{
			muOld = p.mu;
		}
	}
	
	free(tempprob);
	mat_free(temp, DIM);
	mat_free(Sigma,DIM);
	mat_free(SigmaInv,DIM);
	mat_free(S0, DIM);
	mat_list_free(S0list, DIM, p.n);
} 

void update_X(points &pp, pars &p, unsigned long* seed)
{
	double* sumW = vec_alloc(p.n);
	double** sumWY = vec_list_alloc(DIM, p.n);
	double** Sigma = mat_alloc(DIM);
	double* x = vec_alloc(DIM);
	double* tempprob = vec_alloc(p.V_n);
	double muOld = p.mu;
	
	for(int j=0; j<pp.m; j++)
	{
		if(pp.kappa[j]>-1)
		{
			sumW[pp.kappa[j]] += pp.W[j];
			for(int a=0; a<DIM; a++)
				sumWY[pp.kappa[j]][a] += pp.Y[j][a] * pp.W[j];
		}
	}
	
	for(int i=0; i<p.n; i++)
	{
		if (sumW[i]==0) continue;
		for(int a=0; a<DIM; a++)
			sumWY[i][a] /= sumW[i];
		mat_copyval(Sigma, p.Sigma[i], DIM);
		mat_times_k(Sigma, DIM, 1.0/sumW[i]);
		vec_copyval(x, p.X[i], DIM);
		rmvnorm(p.X[i], Sigma, DIM, sumWY[i], seed, 0);
		
		if(inRange(p.X[i], DIM, pp.mask, pp.dim))
		{
			
			//vec_exchange(p.X[i], x, DIM);
			vec_copyval(tempprob, p.norm_prob[i], p.V_n);
			update_nprob(i, pp, p, seed);
			mu_cal(pp, p, seed);
			
			double temp;
			int flag = 0;
			for(int j=0;j<p.n; j++)
			{
				if(j!=i)
				{
					temp = 0.0;
					for(int k=0; k<3; k++)
						temp += (p.X[i][k]-p.X[j][k])*(p.X[i][k]-p.X[j][k]);
					if(temp<p.radius2)
					{
						flag = 1;
						break;
					}
				}
			}
			
			if(log(kiss(seed)) > pp.m*log(muOld/p.mu) || flag == 1)
			{
				vec_copyval(p.X[i], x, DIM);
				p.mu = muOld;
				vec_copyval(p.norm_prob[i], tempprob, p.V_n);
			}
			else
			{
				for(int k = 0; k<DIM; k++)
					p.X[i][k] = p.X[i][k] + 0.001-0.002*kiss(seed);
				muOld = p.mu;
			}
		}
		else
		{
			for(int k = 0; k<DIM; k++)
				p.X[i][k] = p.X[i][k] + 0.001-0.002*kiss(seed);
			vec_copyval(p.X[i],x,DIM);
		}
	}
	
	mat_free(Sigma,DIM);
	free(sumW);
	vec_list_free(sumWY,p.n);
	free(tempprob);
	free(x);
}

void adjust_acceptance(double accept,double &sgm) 
{
	double y;
	double target = .35;
	
	y = 1. + 1000.*(accept-target)*(accept-target)*(accept-target);
	if (y < .9)
		y = .9;
	if (y > 1.1)
		y = 1.1;
	sgm *= y;
}

int update_eps1(points &pp, pars &p, unsigned long* seed)
{
	
	p.eps = rgamma(p.alpha0+p.N0, p.beta0+pp.vol, seed);
	
	return 1;
}



int update_eps(points &pp, pars &p, unsigned long* seed)
{
	double eps = p.eps; 
	double muOld = p.mu;
	p.eps= eps + snorm(seed)*p.sgm0;
	if (p.eps <= 0)
	{
		p.eps = eps;
		//p.acpt0 = p.iters*p.acpt0/(p.iters+1);
		return 0;
	}
	
	mu_cal(pp, p, seed);
	if(log(kiss(seed))> pp.m*log(muOld/p.mu) + (p.alpha0+p.N0-1)*log(p.eps/eps) - p.beta0*(p.eps - eps))
	{
		p.eps = eps;
		p.mu = muOld;
		//p.acpt0 = p.iters*p.acpt0/(p.iters+1);
		return 0;
	}
	
	p.acpt0++;
	
	return 1;
}


int update_theta1(points &pp, pars &p, unsigned long* seed)
{
	double pnorm = 0;
	double temp = 0;
	
	for(int k=0; k<p.V_n; k++)
	{
		temp = 0;
		for(int i=0; i<p.n; i++)
		{
			temp += p.norm_prob[i][k];
		}
		temp*= p.phi[k];
		pnorm += temp;
	}
	
	p.theta = rgamma(p.alpha1+pp.m-p.N0, p.beta1+pnorm, seed);
	
	return 1;
}


int update_theta(points &pp, pars &p, unsigned long* seed)
{
	double theta = p.theta; 
	double muOld = p.mu;
	p.theta= theta + snorm(seed)*p.sgm1;
	
	
	if(p.theta<=0)
	{
		p.theta = theta;
        //p.acpt1 = p.acpt1*p.iters/(p.iters+1);
		return 0;
	}
	
	mu_cal(pp, p, seed);
	/*printf("Old theta: %lf\n", theta);
	 printf("New theta: %lf\n", p.theta);
	 printf("Old mu: %lf\n", muOld);
	 printf("New mu: %lf\n", p.mu);*/
	
	//Gamma Prior
	double p_ratio = pp.m*log(muOld/p.mu)+(p.alpha1+pp.m-p.N0-1)*log(p.theta/theta)-p.beta1*(p.theta - theta);
	
	//log Normal Prior
	//double p_ratio = pp.m*log(muOld/p.mu)+(pp.m-p.N0)*log(p.theta/theta)-(log(p.theta)-p.alpha1)*(log(p.theta)+p.alpha1-2*p.alpha1)/(2*p.beta1);
	if (log(kiss(seed))>p_ratio)
	{
		p.theta = theta;
		p.mu = muOld;
		return 0;
		
	}
	
	
	p.acpt1 ++;
	
	return 1;
}


void update_phi(points &pp, pars &p, unsigned long* seed)
{
	double* alpha = vec_alloc(p.V_n);
	for(int k=0; k<p.V_n; k++)
	{
		alpha[k] = 1.0/p.V_n + pp.WM[k];
	}
	
	double* phi = vec_copy(p.phi,p.V_n);
	p.phi = rdirichlet(alpha, p.V_n, seed);
	double muOld = p.mu;
	
	mu_cal(pp, p, seed);
	if (log(kiss(seed))> pp.m*log(muOld/p.mu))
	{
		vec_copyval(p.phi, phi, p.V_n);
		p.mu = muOld;
	}
	
	free(alpha);
	free(phi);
}

void update_S(pars &p, unsigned long* seed)
{
	double** S0 = mat_copy(p.invT,DIM);
	double** Sigma0 = mat_alloc(DIM);
	
	
	
	for(int i=0; i<p.n; i++)
	{
		//mat_inverse(Sigma0, p.Sigma[i], DIM);
		mat_plus(S0, S0, p.SigmaInv[i], DIM);
	}
	
	//printf("invT0 = \n");
	//mat_print(S0, DIM, "%.4f ");
	double** Tn = mat_alloc(DIM);
	
	mat_inverse(Tn, S0, DIM);
	
	
	rwishart(p.S, Tn, DIM, p.df_T+p.n*p.df_S, seed);
	mat_inverse(p.invS, p.S, DIM);
	
	//printf("S = \n");
	//mat_print(p.S, DIM,"%.4f ");
	
	mat_free(S0,DIM);
	mat_free(Sigma0, DIM);
	mat_free(Tn, DIM);
}

void update_beta(pars &p, points &pp, unsigned long* seed)
{
    //p.beta = rgamma(p.n+p.a,p.b+pp.vol, seed);
	double beta0 = p.beta+snorm(seed)/pp.vol;
	if(beta0>p.a && beta0<p.b)
	{
		if(log(kiss(seed))< p.n*(log(beta0)-log(p.beta))+(p.beta-beta0)*pp.vol)
		{
			p.beta = beta0;
		}
	}
	
}

void update_beta1(pars &p, points &pp, unsigned long* seed)
{
    //p.beta = rgamma(p.n+p.a,p.b+pp.vol, seed);
	double beta0 = p.beta+snorm(seed)/pp.vol;
	if(log(kiss(seed))< (p.n+p.a-1.0)*(log(beta0)-log(p.beta))+(p.beta-beta0)*(pp.vol+p.b))
	{
		p.beta = beta0;
	}
	
	
}

void update_beta2(pars &p, points &pp, unsigned long* seed)
{
	double betaB = rgamma(p.n+p.a, p.b+1.0, seed);
	p.beta = betaB/pp.vol;
}


void cut_centers(pars &p, int cut_num)
{
	double** X = vec_list_copy(p.X, DIM, p.n);
	double*** Sigmalist = mat_list_copy(p.Sigma, DIM, p.n);
	int*Num = (int*)calloc(p.n, sizeof(int));
	int n = p.n;
	for(int i=0; i<n; i++)
	{
		Num[i] = p.Num[i];
	}
	
	
	p.n = 0;
	for(int i=0; i<n; i++)
	{
		if(Num[i]>=cut_num)
		{
			vec_copyval(p.X[p.n], X[i], DIM);
			mat_copyval(p.Sigma[p.n], Sigmalist[i], DIM);
			p.Num[p.n] = Num[i];
			p.n++;
		}
	}
	
	mat_list_free(Sigmalist, DIM, n);
	vec_list_free(X, n);
	free(Num);
}


void cut_centers1(points &pp,pars &p)
{
	int i = p.n - 1;	
	while(i>=0)
	{
		if(p.Num[i]<p.cutnumber)
		{
			rm_centers(i, p, pp);
		}
		i--;
	}
	
}




int move_step(points &pp, pars &p, unsigned long* seed)
{
	if (p.n==0)
	{
		if(p.iters<p.burn_in)
		{
			//p.theta = rgamma(p.alpha1, p.beta1, seed);
			p.theta = p.alpha1/p.beta1;
			//p.eps = rgamma(p.alpha0, p.beta0, seed);
			p.eps = p.alpha0/p.beta0;
		}
		return 0;
	}
	update_kappa(pp, p, seed);
	//cut_centers1(pp,p);
	nporb_cal(pp, p, seed);
	mu_cal(pp, p, seed);
	update_Sigma(pp, p, seed);
	update_X(pp,p, seed);
	//update_eps(pp, p, seed);
	//update_theta(pp, p, seed);
	//update_phi(pp, p, seed);
	//update_beta(p,pp,seed);
	//update_beta1(p,pp,seed);
	update_beta2(p,pp,seed);
	
	
	
	
	/*if((p.iters*1.0)/p.adj_acpt==p.iters/p.adj_acpt)
	{
		if (p.iters<=p.burn_in)
		{
			adjust_acceptance(p.acpt0/p.adj_acpt, p.sgm0);
			adjust_acceptance(p.acpt1/p.adj_acpt, p.sgm1);
		}
		p.acpt0 = 0;
		p.acpt1 = 0;
	}*/
	
	return 1;
}

//Do not update theta
int move_step1(points &pp, pars &p, unsigned long* seed)
{
	if (p.n==0)
		return 0;
	
	update_kappa(pp, p, seed);
	
	mu_cal(pp, p, seed);
	update_Sigma(pp, p, seed);
	update_X(pp,p, seed);
	update_eps(pp, p, seed);
	//update_theta(pp, p, seed);
	update_phi(pp, p, seed);
	
	if((p.iters*1.0)/p.adj_acpt==p.iters/p.adj_acpt)
	{
		adjust_acceptance(p.acpt0, p.sgm0);
		//adjust_acceptance(p.acpt1, p.sgm1);
	}
	
	return 1;
}

//The intensity function of the cox process (integrate out weights)
double cox_lambda(double *y, pars &p)
{
	int i,k;
	double lbt;
	double** Sigma = mat_alloc(DIM);
	lbt = 0;
	for (k=0; k<p.V_n; k++)
	{
		for (i=0;i<p.n;i++)
		{
			mat_copyval(Sigma, p.SigmaInv[i], DIM);
			mat_times_k(Sigma, DIM, p.V[k]);
			lbt += dmvnorm1(y,Sigma,DIM,p.X[i])*p.phi[k];
		}
		
	}
	lbt = p.eps + lbt*p.theta;
	mat_free(Sigma,DIM);
	return lbt;
	
}


int rec_intensity(points &pp, pars &p)
{
	double *y = vec_alloc(DIM);
	
	pp.num_intense++;
	
	for(int a = 0; a<pp.dim[0]; a+=pp.intval_intense)
		for(int b=0; b<pp.dim[1]; b+=pp.intval_intense)
			for(int c=0; c<pp.dim[2]; c+=pp.intval_intense)
			{
				y[0] = a;
				y[1] = b;
				y[2] = c;
				if (inRange(y, DIM, pp.mask,pp.dim))
				{
					pp.curint[a][b][c] = cox_lambda(y, p);
					pp.intensity[a][b][c] = ((pp.num_intense-1)*pp.intensity[a][b][c] + pp.curint[a][b][c])/pp.num_intense;
				}
			}
	
	free(y);
	
	return 1;
}


void compute_regionIntensity(points &pp, pars &p)
{
    double *y = vec_alloc(DIM);
    
    for (int a=0; a<pp.dim[0]; a++) {
        y[0] = a;
        for (int b=0; b<pp.dim[1]; b++) {
            y[1] = b;
            for (int c=0; c<pp.dim[2]; c++) {
                y[2] = c;
                if (inRange(y, DIM, pp.mask, pp.dim)) {
                    for (int i=0; i<pp.numOfregion; i++) {
                        if (pp.regionmask[a][b][c]==i+1) {
                            pp.regionIntensity[pp.numOfIntensity][i] += cox_lambda(y,p);
                        }
                        
                    }
                }
            }
        }
    }
    
    for (int i=0; i<pp.numOfregion; i++) {
        pp.regionIntensity[pp.numOfIntensity][i]/= pp.regionCount[i];
    }

    int xx, yy, zz;
    
    for (int i=0; i<pp.numOfregion; i++) {
        pp.popCtrRegionCount[pp.numOfIntensity][i] = 0;
        for (int j=0; j<p.n; j++) {
            if (inRange(p.X[j], DIM, pp.mask, pp.dim)) {
                xx = (int)p.X[j][0];
                yy = (int)p.X[j][1];
                zz = (int)p.X[j][2];
                
                if (pp.regionmask[xx][yy][zz]==i+1) {
                    pp.popCtrRegionCount[pp.numOfIntensity][i]++;
                }
                
                
            }
        }
    }

    
    
    pp.numOfIntensity++;
    
}




void write_regionIntensity(const char* data_file, points &pp)
{
    FILE * fid = fopen(data_file,"wt");
    
    for (int i=0; i<pp.numOfIntensity; i++) {
        fprintf(fid, "%d ", i+1);
        for (int j=0; j<pp.numOfregion; j++) {
            fprintf(fid,"%lf ", pp.regionIntensity[i][j]);
        }
        fprintf(fid, "\n");
    }
    fclose(fid);

}


void write_regionPopCtr(const char* data_file, points &pp)
{
    FILE * fid = fopen(data_file,"wt");
    
    for (int i=0; i<pp.numOfIntensity; i++) {
        fprintf(fid, "%d ", i+1);
        for (int j=0; j<pp.numOfregion; j++) {
            fprintf(fid,"%d ", pp.popCtrRegionCount[i][j]);
        }
        fprintf(fid, "\n");
    }
    fclose(fid);
    
}



void initial_regionMask(points &pp,const char* regionmaskfile)
{
   pp.regionmask = read_mask_img(regionmaskfile, pp.dim);

}



void initial_regionIntensity(points &pp)
{
    pp.numOfregion = 0;
    for (int i=0; i<pp.dim[0]; i++) {
        for (int j=0; j<pp.dim[1]; j++) {
            for (int k=0; k<pp.dim[2]; k++)
            {
                if (pp.numOfregion<(int)pp.regionmask[i][j][k]) {
                    pp.numOfregion = (int)pp.regionmask[i][j][k];
                }
            }
        }
    }
    
    pp.regionCount = (int*)malloc(sizeof(int)*pp.numOfregion);
    for (int i=0; i<pp.dim[0]; i++) {
        for (int j=0; j<pp.dim[1]; j++) {
            for (int k=0; k<pp.dim[2]; k++)
            {
                for (int a=0; a<pp.numOfregion; a++) {
                    if (pp.regionmask[i][j][k]==a+1) {
                        pp.regionCount[a]++;
                    }
                }

            }
        }
    }

    
    
    pp.regionIntensity = (double**)malloc(sizeof(double*)*pp.numOfIntensity);
    for (int i=0; i<pp.numOfIntensity; i++) {
        pp.regionIntensity[i] = (double*)malloc(sizeof(double)*pp.numOfregion);
        for (int j=0; j<pp.numOfregion; j++) {
            pp.regionIntensity[i][j] = 0;
        }
    }
    
    pp.popCtrRegionCount = (int**)malloc(sizeof(int*)*pp.numOfIntensity);
    for (int i=0; i<pp.numOfIntensity; i++) {
        pp.popCtrRegionCount[i] = (int*)malloc(sizeof(int)*pp.numOfregion);
        for (int j=0; j<pp.numOfregion; j++) {
            pp.popCtrRegionCount[i][j] = 0;
        }
    }
    
    
    
}

void free_regionMask(points &pp)
{
    free_mask_img(pp.regionmask, pp.dim);
}



void free_regionIntensity(points &pp)
{
    for (int i=0; i<pp.numOfIntensity; i++) {
        free(pp.regionIntensity[i]);
        free(pp.popCtrRegionCount[i]);
    }
    free(pp.popCtrRegionCount);
    free(pp.regionIntensity);
    free(pp.regionCount);
}




//Save intensity function
void write_vol(const char* filename, points &pp, pars &p)
{
	FILE * fvol;
	fvol = fopen(filename,"w");
	for(int a=0; a<pp.dim[2]; a++)
	{
		for(int b=0; b<pp.dim[1]; b++)
		{
			for(int c=0; c<pp.dim[0]; c++)
				fprintf(fvol, "%g ", pp.intensity[c][b][a]);
			fprintf(fvol,"\n");
		}
		fprintf(fvol,"\n");
	}
	
	
	fclose(fvol);
}


//Save predictive intensity function
void write_pred_vol(const char* filename, points &pp, pars &p)
{
	FILE * fvol;
	fvol = fopen(filename,"w"); 
	for(int a=0; a<pp.dim[2]; a++)
	{
		for(int b=0; b<pp.dim[1]; b++)
		{
			for(int c=0; c<pp.dim[0]; c++)
				fprintf(fvol, "%g ", pp.pred_intensity[c][b][a]);
			fprintf(fvol,"\n");
		}
		fprintf(fvol,"\n");
	}
	
	
	fclose(fvol);
}




void write_curvol(const char* filename, points &pp, pars &p)
{
	FILE * fvol;
	fvol = fopen(filename,"w");
	for(int a=0; a<pp.dim[2]; a++)
	{
		for(int b=0; b<pp.dim[1]; b++)
		{
			for(int c=0; c<pp.dim[0]; c++)
				fprintf(fvol, "%g ", pp.curint[c][b][a]);
			fprintf(fvol,"\n");
		}
		fprintf(fvol,"\n");
	}
	
	
	fclose(fvol);
}



void write_margin(const char* filename, points &pp, pars &p)
{
	char file_xy[80];
	char file_yz[80];
	char file_xz[80];
	FILE* fvol;
	double temp;
	int flag;
	
	strcpy(file_xy, filename);
	strcat(file_xy, "_xy.txt");
	fvol=  fopen(file_xy,"wt");
	for(int i=0; i<pp.dim[0]; i++)
	{
		for(int j=0; j<pp.dim[1]; j++)
		{
			temp = 0;
			flag = 1;
			for(int k=0; k<pp.dim[2]; k++)
			{
				if(pp.intensity[i][j][k]!= -1)
				{
					temp += pp.intensity[i][j][k];
					flag = 0;
				}
			}
			if (flag==1)
			{
				fprintf(fvol,"%lf ", -1.0); 
			}
			else
			{
				fprintf(fvol,"%lf ", temp);
			}
		}
		fprintf(fvol,"\n");
	}
	fclose(fvol);
	
	strcpy(file_yz, filename);
	strcat(file_yz, "_yz.txt");
	fvol=  fopen(file_yz,"wt");
	for(int j=0; j<pp.dim[1]; j++)
	{
		for(int k=0; k<pp.dim[2]; k++)
		{
			temp = 0;
			flag = 1;
			for(int i=0; i<pp.dim[0]; i++)
			{
				if(pp.intensity[i][j][k]!= -1)
				{
					temp += pp.intensity[i][j][k];
					flag = 0;
				}
			}
			if(flag==1)
			{
				fprintf(fvol,"%lf ", -1.0);
			}
			else
			{
				fprintf(fvol,"%lf ", temp); 
			}
		}
		fprintf(fvol,"\n");
	}
	fclose(fvol);
	
	strcpy(file_xz, filename);
	strcat(file_xz, "_xz.txt");
	fvol=  fopen(file_xz,"wt");
	for(int i=0; i<pp.dim[0]; i++)
	{
		for(int k=0; k<pp.dim[2]; k++)
		{
			temp = 0;
			flag = 1;
			for(int j=0; j<pp.dim[1]; j++)
			{
				if(pp.intensity[i][j][k]!= -1)
				{
					temp += pp.intensity[i][j][k];
					flag = 0;
				}
			}
			if(flag == 1)
			{
				fprintf(fvol, "%lf ", -1.0);
			}
			else
			{
				fprintf(fvol,"%lf ", temp); 
			}
		}
		fprintf(fvol,"\n");
	}
	fclose(fvol);
	
}

void bd_accept(int acptidx, pars &p)
{
	if (p.BorD == 1)
	{
		p.numOfBirth++;
		if (acptidx==1)
		{
			p.birth_acpt++;
		}
	}
	else if(p.BorD == 2)
	{
		p.numOfDeath++;
		if (acptidx==-1)
		{
			p.death_acpt++;
		}
	}
	
}

//record the parameters
void rec_pars(FILE* fvol, pars &p, points &pp)
{
	//fprintf(fpar,"iteration Birth/Death numOfCluster    m    mp       npacs       theta          eps     tho  totalBirthRate                 totalDeathRate acceptRatio\n");
    double acp =  0.0;
	if (p.totalDeathRate<=0)
	{
		acp = 1.0;
	}
	else
	{
		acp = p.totalBirthRate/p.totalDeathRate;
	}
	
	if(p.BorD == 1)
		fprintf(fvol, "%9d       Birth %12d %12d %12d %12d %12lf  %12lf %13.10lf %12.4lf %20lf %30.20lf %30.20lf %30.20lf %30.20lf %d %d\n",p.iters, p.n, pp.m, pp.m_p, p.N0, pp.npacs, p.theta, 
				p.eps, p.rho,p.totalBirthRate, p.totalDeathRate, acp, p.phi[0], p.phi[1], pp.numOfBirth,pp.numOfDeath);
	else
		fprintf(fvol, "%9d       Death %12d %12d %12d %12d %12lf  %12lf %13.10lf %12.4lf %20lf %30.20lf %30.20lf %30.20lf %30.20lf %d %d\n",p.iters, p.n, pp.m, pp.m_p, p.N0, pp.npacs, p.theta, 
				p.eps, p.rho,p.totalBirthRate, p.totalDeathRate, 1.0/acp, p.phi[0], p.phi[1], pp.numOfBirth,pp.numOfDeath);
	
	fflush(fvol);
}

void rec_Z(FILE* fvol, points &pp, pars &p)
{
	for(int j=0; j<pp.m; j++)
	{
		if (pp.contrast[j]<=5 || pp.contrast[j] == 42 
			|| pp.contrast[j] ==115 || pp.contrast[j] ==347 || pp.contrast[j] == 351
			|| pp.contrast[j] ==415)
		{
			fprintf(fvol, "%d %d %d %d", p.iters, pp.Y_n[j], pp.contrast[j], pp.study[j]);
			for(int k=0; k<DIM; k++)
				fprintf(fvol, " %.4f", pp.Y[j][k]);
			fprintf(fvol, "\n");
		}
	}
	fflush(fvol);
}



void rec_numZ(FILE *fvol, points &pp, pars &p)
{
	for(int t=0; t<pp.n_contrast; t++)
	{
		if (pp.contrast1[pp.c_id[t]]<=5 || pp.contrast1[pp.c_id[t]] == 42 
			|| pp.contrast1[pp.c_id[t]] ==115 || pp.contrast1[pp.c_id[t]] ==347 || pp.contrast1[pp.c_id[t]] == 351
			|| pp.contrast1[pp.c_id[t]] ==415)
		{
			fprintf(fvol, "%d %d %d %d %d %e %e\n", p.iters,pp.contrast1[pp.c_id[t]],
					pp.Z0_n[t]-pp.Zg_n[t],pp.Zg_n[t],pp.c_num[t]-pp.Z0_n[t],pp.xi[t],pp.rho_all[t]);
		}
	}
	fflush(fvol);
}

//record the number of foci that do not cluster about study centers
void rec_num_Z0(FILE *fvol, points &pp, pars &p)
{
	fprintf(fvol, " %d",p.iters);
	for(int t=0; t<pp.n_contrast; t++)
		fprintf(fvol," %d",pp.Z0_n[t]);
	fprintf(fvol, "\n");
	fflush(fvol);
}

//record the number of foci that cluster about study centers
void rec_num_Z1(FILE *fvol, points&pp, pars &p)
{
	fprintf(fvol, "%d",p.iters);
	for(int t=0; t<pp.n_contrast; t++)
		fprintf(fvol," %d",pp.c_num[t]-pp.Z0_n[t]);
	fprintf(fvol, "\n");
	fflush(fvol);
}

//record the number of foci that do not cluster with any other centers
void rec_num_Z00(FILE *fvol, points&pp, pars &p)
{
	fprintf(fvol, "%d",p.iters);
	for(int t=0; t<pp.n_contrast; t++)
		fprintf(fvol," %d",pp.Z0_n[t]-pp.Zg_n[t]);
	fprintf(fvol, "\n");
	fflush(fvol);
}

//record the number of foci that do cluster about populaton centers
void rec_num_Z01(FILE *fvol, points&pp, pars &p)
{
	fprintf(fvol, "%d",p.iters);
	for(int t=0; t<pp.n_contrast; t++)
		fprintf(fvol," %d",pp.Zg_n[t]);
	fprintf(fvol, "\n");
	fflush(fvol);
}




void rec_PAC_in_LA(FILE *fid, points &pp, pars &p)
{
	int pi, zi, zj;
	for(int i=0; i<pp.n_la; i++)
	{
		pi = pp.la_id[i];
		zi = pp.Zi[pi];
		zj = pp.Zj[pi];
		
        fprintf(fid,"%d",p.iters);
		
		//print constrast id
		fprintf(fid," %d", zi);
		//print PACs
		for(int k=0; k<DIM; k++)
			fprintf(fid," %lf", pp.dat[pi][k]);
		//print study centers
		if(pp.Z_kappa[zi][zj]==-1)
		{
			fprintf(fid," 0");
			for(int k=0; k<DIM; k++)
				fprintf(fid, " 0");
			fprintf(fid," 0");
			
		}
		else
		{
			fprintf(fid," 1");
			for (int k=0; k<DIM; k++) {
				fprintf(fid," %lf", pp.Y[pp.idx_Y[zi][zj]][k]);
			}
			fprintf(fid," %d", inRange(pp.Y[pp.idx_Y[zi][zj]], DIM, pp.Lamygdala, pp.dim));
			
		}
		
		//print population centers
		
		if(pp.kappa[pp.idx_Y[zi][zj]] == -1)
		{
			fprintf(fid," 0");
			for(int k=0; k<DIM; k++)
				fprintf(fid, " 0");
			fprintf(fid," 0");
			
		}
		else
		{
			fprintf(fid," 1");
			for (int k=0; k<DIM; k++) {
				fprintf(fid," %lf", p.X[pp.kappa[pp.idx_Y[zi][zj]]][k]);
			}
			fprintf(fid," %d", inRange(p.X[pp.kappa[pp.idx_Y[zi][zj]]], DIM, pp.Lamygdala, pp.dim));
			
		}
		
		fprintf(fid,"\n");
	}
	
	
	fflush(fid);
	
}

void rec_PAC_in_RA(FILE *fid, points &pp, pars &p)
{
	int pi, zi, zj;
	for(int i=0; i<pp.n_ra; i++)
	{
		pi = pp.ra_id[i];
		zi = pp.Zi[pi];
		zj = pp.Zj[pi];
		
		fprintf(fid,"%d",p.iters);
		
		//print constrast id
		fprintf(fid," %d", zi);
		//print PACs
		for(int k=0; k<DIM; k++)
			fprintf(fid," %lf", pp.dat[pi][k]);
		//print study centers
		if(pp.Z_kappa[zi][zj]==-1)
		{
			fprintf(fid," 0");
			for(int k=0; k<DIM; k++)
				fprintf(fid, " 0");
			fprintf(fid," 0");
			
		}
		else
		{
			fprintf(fid," 1");
			for (int k=0; k<DIM; k++) {
				fprintf(fid," %lf", pp.Y[pp.idx_Y[zi][zj]][k]);
			}
			fprintf(fid," %d", inRange(pp.Y[pp.idx_Y[zi][zj]], DIM, pp.Ramygdala, pp.dim));
			
		}
		
		//print population centers
		
		if(pp.kappa[pp.idx_Y[zi][zj]] == -1)
		{
			fprintf(fid," 0");
			for(int k=0; k<DIM; k++)
				fprintf(fid, " 0");
			fprintf(fid," 0");
			
		}
		else
		{
			fprintf(fid," 1");
			for (int k=0; k<DIM; k++) {
				fprintf(fid," %lf", p.X[pp.kappa[pp.idx_Y[zi][zj]]][k]);
			}
			fprintf(fid," %d", inRange(p.X[pp.kappa[pp.idx_Y[zi][zj]]], DIM, pp.Ramygdala, pp.dim));
			
		}
		fprintf(fid, "\n");
	}
	
	fflush(fid);
}


void rec_id_study(FILE* fvol,points &pp, pars &p)
{
	for(int i=0; i<p.n; i++)
	{
		fprintf(fvol, "%d %d %d %d ", p.iters, p.n, i, p.Num[i]);
		for(int j=0; j<pp.n_study; j++)
			fprintf(fvol,"%d ", pp.id_study[i][j]);
		fprintf(fvol, "\n");
	}
	fflush(fvol);
}

void rec_id_contrast(FILE* fvol, points &pp, pars &p)
{
	for(int i=0; i<p.n; i++)
	{
		fprintf(fvol, "%d %d %d %d ", p.iters, p.n, i, p.Num[i]);
		for(int j=0; j<pp.n_contrast; j++)
			fprintf(fvol,"%d ", pp.id_contrast[i][j]);
		fprintf(fvol, "\n");
	}
	fflush(fvol);
}


void rec_centers(FILE* fvol, pars &p, int &idx)
{
	for(int i=0; i< p.n; i++)
	{
		idx++;
		fprintf(fvol, "%d %lf %lf %lf\n", idx, p.X[i][0],p.X[i][1],p.X[i][2]);		
	}
	fflush(fvol);
}

void rec_centers1(FILE* fvol, pars &p)
{
	for(int i=0; i< p.n; i++)
	{
		fprintf(fvol, "%d %d %d %lf %lf %lf\n", p.iters, i, p.n, p.X[i][0],p.X[i][1],p.X[i][2]);		
	}
	fflush(fvol);
}

void rec_Sigma(FILE* fvol, pars &p)
{
	for(int i=0; i<p.n; i++)
		fprintf(fvol, "%d %d %d %lf %lf %lf %lf %lf %lf\n", p.iters, i, p.n,
				p.Sigma[i][0][0], p.Sigma[i][0][1],p.Sigma[i][0][2],p.Sigma[i][1][1],p.Sigma[i][1][2],p.Sigma[i][2][2]);
	fflush(fvol);
}

void rec_S(FILE* fvol, pars &p)
{
	fprintf(fvol, "%d %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf\n", p.iters,
			p.S[0][0], p.S[0][1],p.S[0][2],p.S[1][1],p.S[1][2],p.S[2][2],p.S0[0][0], p.S0[0][1],p.S0[0][2],p.S0[1][1],p.S0[1][2],p.S0[2][2]);
	fflush(fvol);
	
}

void rec_num(FILE* fvol, pars &p)
{
	for(int i=0; i<p.n; i++)
		fprintf(fvol, "%d %d %d %d %d %d\n", p.iters, i, p.n,
				p.Num[i],p.studyNum[i],p.contrastNum[i]);
	fflush(fvol);
}


//record proportional ratios 
void rec_xi(FILE* fvol, points &pp, pars &p)
{
	fprintf(fvol, "%d",p.iters);
	for(int t=0; t<pp.n_contrast+1; t++)
		fprintf(fvol," %lf",pp.xi[t]);
	fprintf(fvol, "\n");
	fflush(fvol);
}

//record the intensity of the foci that cluster about latent study centers
void rec_rho(FILE* fvol,  points &pp, pars &p)
{
	fprintf(fvol, "%d",p.iters);
	for(int t=0; t<pp.n_contrast; t++)
		fprintf(fvol," %lf",pp.rho_all[t]);
	fprintf(fvol, "\n");
	fflush(fvol);
}

//record beta
void rec_beta(FILE* fvol, points &pp, pars&p)
{
	fprintf(fvol, "%d %lf\n",p.iters,p.beta);
	fflush(fvol);
}

//save parameters
void save_pars(FILE* fid, pars &p, points &pp)
{
	fprintf(fid, "-------------Image Information------------------\n");
	
	fprintf(fid, "Dimension = [%d, %d, %d]\n", pp.dim[0], pp.dim[1], pp.dim[2]);
	fprintf(fid, "|Brain Region| = %.0lf\n",pp.vol);
	fprintf(fid, "The number of Points = %d\n", pp.m1);
	
	fprintf(fid, "--------------Model Information-----------------\n");
	fprintf(fid, " X ~ Poisson(Brain,beta)\n" );
	fprintf(fid, " beta ~ Unif(%.10lf, %.10lf)\n", p.a, p.b);
	fprintf(fid, " E(N(X)) = %.10lf\n\n", (p.a+p.b)*pp.vol/2.0);
	fprintf(fid, " Z|X ~ Poisson(Brain, epsilon+theta*sum of phi(X))\n");
	fprintf(fid, " epsilon ~ Gamma(%.10lf , %.10lf)\n", p.alpha0, p.beta0);
	fprintf(fid, "         c.v.(epsilon) = %.10lf\n", sqrt(1.0/p.alpha0));
	fprintf(fid, "         Var(epsilon) = %.10lf\n", p.alpha0/(p.beta0*p.beta0));
	fprintf(fid, "         E(epsilon) = %.10lf\n", p.alpha0/p.beta0);
	fprintf(fid, " theta ~ Gamma(%.10lf, %.10lf)\n", p.alpha1, p.beta1);
	fprintf(fid, "         c.v.(theta) = %.10lf\n", sqrt(1.0/p.alpha1));
	fprintf(fid, "         Var(theta) = %.10lf\n", p.alpha1/(p.beta1*p.beta1));
	fprintf(fid, "         E(theta) = %.10lf\n", p.alpha1/p.beta1);
	fprintf(fid, " Sigma ~ Inv-Wishart(S, %d)\n", p.df_S);
	fprintf(fid, " S ~ Wishart(%.4lf*I, %d)\n", 1.0/p.invT[0][0], p.df_T);
	fprintf(fid, "     E(Sigma) = %.4lf*I\n", p.df_T/(p.invT[0][0]*(p.df_S-DIM-1)));
	fprintf(fid, " The radius = %lf\n", sqrt(p.radius2));
	
	fprintf(fid, " Y|Z ~ Poisson(Brain, xi*(eps+theta*sum of phi(X))+rho*sum of phi(Z)))\n");
	fprintf(fid, " xi ~ Gamma(%e, %e)\n", p.xi_alpha,p.xi_beta);
	fprintf(fid, "         c.v.(xi) = %e\n", sqrt(1.0/p.xi_alpha));
	fprintf(fid, "         E(xi) = %e\n", p.xi_alpha/p.xi_beta);
	fprintf(fid, "         Var(xi) = %e\n", p.xi_alpha/(p.xi_beta*p.xi_beta));
	fprintf(fid, " rho ~ Gamma(%.10lf, %.10lf)\n", p.alpha_rho, p.beta_rho);
	fprintf(fid, "         c.v.(rho) = %.10lf\n", sqrt(1.0/p.alpha_rho));
	fprintf(fid, "         Var(rho) = %.10lf\n", p.alpha_rho/(p.beta_rho*p.beta_rho));
	fprintf(fid, "         E(rho) = %.10lf\n", p.alpha_rho/p.beta_rho);
	fprintf(fid, " Lambda ~ Inv-Wishart(S0, %d)\n", p.df_S0);
	fprintf(fid, " S0 ~ Wishart(%.4lf*I, %d)\n", 1.0/p.invT0[0][0], p.df_T0);
	fprintf(fid, "     E(Lambda) = %.4lf*I\n", p.df_T0/(p.invT0[0][0]*(p.df_S0-DIM-1)));
	
	
	
	
	
	fprintf(fid, " Number of weights =  %d\n", p.V_n);
	for(int i=0; i<p.V_n; i++)
	{
		fprintf(fid, "     Weight[%d] =  %.10lf\n", i, p.V[i]);
	}
	
	fprintf(fid, " The percentage of noise points = %.0lf/100\n",
			p.alpha0/p.beta0*pp.vol/pp.m1*100);
	
	fprintf(fid, "-------------Simulation Information--------------\n");
	fprintf(fid, "  Total Iterations: %d\n", p.total_iters);
	fprintf(fid, "Burn in iterations: %d\n", p.burn_in);
	
	fflush(fid);
	
}


