/*
 *  MatVec.cpp
 *  NewHWCox04
 *
 *  Created by Jian Kang on 4/6/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */
#include "MatVec.h"


//Matrix allocation (default is I)
double **mat_alloc(int size_A)
{
	int i;
	double ** A;
	
	A = (double **)calloc(size_A, sizeof(double *));
	for (i = 0; i<size_A;i++)
	{
		A[i] = (double *)calloc(size_A,sizeof(double));
		A[i][i] = 1;
	}
	return A;
}

//Matrix List alloction
double ***mat_list_alloc(int size_A,const int M)
{
	int i;
	double ***A;
	
	A = (double***)calloc(M,sizeof(double**));
	for (i=0; i<M; i++)
	{
		A[i] = mat_alloc(size_A);
	}
	
	return A;
}

//Matrix mat allocation M*
double ****mat_mat_alloc(int size_A, const int M, const int L)
{
	int i;
	double ****A;
	
	A= (double****)calloc(L,sizeof(double***));
	for(i=0; i<L; i++)
	{
		A[i] = mat_list_alloc(size_A, M);
	}
	return A;
}


//Array allocation
double ***Array_alloc(int size,int M,int N)
{
	int i;
	double ***A;
	double **vec_list_alloc(int,const int);
	
	A = (double***)calloc(N,sizeof(double**));
	for (i=0; i<N; i++)
	{
		A[i] = vec_list_alloc(size,M);
	}
	
	return A;
	
}

//Array free
void Array_free(double ***A,int size,int M, int N)
{
	int i;
	void vec_list_free(double **,int);
	for (i=0; i<N;i++)
	{
		vec_list_free(A[i],M);
	}
	free(A);
}

// matrix list destruction
void mat_list_free(double ***A,int size_A,const int M)
{
	int i;
	void mat_free(double **,int);
	for (i = 0; i<M; i++)
	{
		mat_free(A[i],size_A);
	}
	free(A);
}


double **mat_copy(double ** A, int size_A)
{
	int i,j;
	double ** B;
	double ** mat_alloc(int);
	
	B = mat_alloc(size_A);
	for (i=0; i<size_A; i++)
		for (j=0; j<size_A; j++)
			B[i][j] = A[i][j];
	
	return B;
}

void mat_copyval(double **A, double **B,int size)
{
	for(int i=0; i<size; i++)
		for(int j=0; j<size; j++)
			A[i][j] = B[i][j];
}

//matrix times a number
void mat_times_k(double **A, int size,double k)
{
	int i,j;
	for (i=0;i<size;i++)
		for(j=0;j<size;j++)
			A[i][j] *= k;
}

//vector allocation (default with all zero)
double *vec_alloc(int size_x)
{
	double *x;
	x = (double *)calloc(size_x,sizeof(double));
	return x;
}


//vector copy 
double *vec_copy(double *x, int size_x)
{
	double *y;
	double *vec_alloc(int);
	int i;
	
	y = vec_alloc(size_x);
	for (i=0; i<size_x; i++)
	{
		y[i] = x[i];
	}
	
	return y;
}



//vector List allocation
double **vec_list_alloc(int size_x,const int M)
{
	int i;
	double **X;
	X = (double **)calloc(M, sizeof(double*));
	for (i = 0; i<M; i++)
	{
		X[i] = vec_alloc(size_x);
	}
	return X;
}


//vector List allocation
double **vec_list_alloc_long(int size_x,const long M)
{
	int i;
	double **X;
	X = (double **)calloc(M, sizeof(double*));
	for (i = 0; i<M; i++)
	{
		X[i] = vec_alloc(size_x);
	}
	return X;
}


//vector list copy
double **vec_list_copy(double **X,int size,int n)
{
	double **Y;
	double **vec_list_alloc(int,const int);
	int i,k;
	Y  = vec_list_alloc(size,n);
	for (i=0;i<n;i++)
	{
		for(k=0;k<size;k++)
		{
			Y[i][k] = X[i][k];
		}
	}
	return Y;
	
}

void vec_copyval(double*v1, double* v2, int size)
{
	for(int i=0; i<size; i++)
	{
		v1[i] = v2[i];
	}
	
}

void vec_exchange(double* v1, double *v2, int size)
{
	double *temp = vec_copy(v1, size);
	vec_copyval(v1,v2,size);
	vec_copyval(v2, temp, size);
	free(temp);
}

//Matrix destruction
void mat_free(double **A,int size_A)
{
	int i;
	for(i=0;i<size_A;i++)
	{
		free(A[i]);
	}
	free(A);
}

//Matrix Matrix destruction
void mat_mat_free(double ****A, int size_A, int M, int L)
{
	int i;
	for(i=0; i<L; i++)
	{
		mat_list_free(A[i], size_A, M);
	}
}


void mat_exchange(double ** m1, double ** m2, int size)
{
	double** temp = mat_copy(m1,size);
	mat_copyval(m1, m2, size);
	mat_copyval(m2, temp, size);
	mat_free(temp, size);
}

//Matrix list copy
double ***mat_list_copy(double*** SigmaList,int size,int n)
{
	double ***Y;
	double ***mat_list_alloc(int,const int);
	int i,j,k;
	Y = mat_list_alloc(size,n);
	for(i=0;i<n;i++)
		for(j=0;j<size;j++)
			for(k=0;k<size;k++)
				Y[i][j][k] = SigmaList[i][j][k];
	return Y;
}

//vector list add one
void vec_list_add(double **X,int size,int n,double *xi)
{
	int k;
	for(k=0;k<size;k++)
	{
		X[n][k] = xi[k];
	}
}

//vector List delete one
void vec_list_delete_i(double **X,int size,int n, int i)
{
	int k;
	if (i<=n-1)
	{
		for(k=0;k<size;k++)
		{
			X[i][k] = X[n-1][k];
			X[n-1][k] = -99999;
		}
	}
}

//Matrix List delete one
void mat_list_delete_i(double ***SigmaList,int size,int n, int i)
{
	int k,j;
	if (i<=n-1)
	{
		for(k=0;k<size;k++)
		{
			for(j=0;j<size;j++)
			{
				SigmaList[i][k][j] = SigmaList[n-1][k][j];
				SigmaList[n-1][k][j] = -99999;
			}
		}
	}
}

//Matrix List Add One
void mat_list_add(double ***SigmaList,int size, int n, double **S)
{
	int k,j;
	for(k=0;k<size;k++)
		for(j=0;j<size;j++)
			SigmaList[n][k][j] = S[k][j];
}


//vector List free
void vec_list_free(double **A, int M)
{
	int i;
	for (i=0; i<M; i++)
	{
		free(A[i]);
	}
	free(A);
}

void vec_list_free(int **A, int M)
{
	int i;
	for (i=0; i<M; i++)
	{
		free(A[i]);
	}
	free(A);
}

//vector List free
void vec_list_free_long(double **A, long M)
{
	int i;
	for (i=0; i<M; i++)
	{
		free(A[i]);
	}
	free(A);
}



//vector print
void vec_print(double *x,int size_x,const char* _format)
{
	int i;
	for (i=0; i<size_x;i++)
	{
		printf(_format,x[i]);
	}
	printf("\n");
}


void vec_print(int *x,int size_x,const char* _format)
{
	int i;
	for (i=0; i<size_x;i++)
	{
		printf(_format,x[i]);
	}
	printf("\n");
}



//Matrix print
void mat_print(double **S,int size_S, const char * _format)
{
	int i,j;
	for (i=0;i<size_S;i++)
	{
		for(j=0;j<size_S;j++)
		{
			printf(_format,S[i][j]);
		}
		printf("\n");
	}
}

//Matrix assign
void mat_assign(double **S, int size_S)
{
	int i,j;
	float row;
	
	printf("Please input a %d by %d matrix\n",size_S,size_S);
	
	for (i=0; i<size_S; i++)
	{
		for (j=0; j<size_S; j++)
		{
			scanf("%f",&row);
			S[i][j] = row;
		}
	}
}

//Vector statistiscs
//Updated mean Vector
//M_n = ((n-1) M_(n-1) + X_n)/n
int vec_upd_mean(double *mean, double *x, const int size, int n)
{
	for(int i=0; i<size; i++)
	{
		mean[i] = ((n-1)*mean[i]+x[i])/n;
	}
	return 1;
}

void exchange(double &a, double &b)
{
	double temp;
	temp = a;
	a = b;
	b = temp;
}

//Vector Distance
double vec_dist(double* v1, double* v2, int size)
{
	double d = 0;
	for(int i=0; i<size; i++)
		d += (v1[i] - v2[i])*(v1[i] - v2[i]);
	
	return d;
}

void vec_add(double* result, double* v1, double* v2, int size)
{
	for(int i=0; i<size; i++)
		result[i] = v1[i] + v2[i];
}


void vec_substract(double* result, double* v1, double* v2, int size)
{
	for(int i=0; i<size; i++)
		result[i] = v1[i] - v2[i];
}

