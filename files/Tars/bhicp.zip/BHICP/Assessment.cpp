/*
 *  Assessment.cpp
 *  NewHWCox04
 *
 *  Created by Jian Kang on 4/6/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#include "Assessment.h"

void simStudyPACs(double** PACs, int* numOfPoints, double** studyCenters, double*** studyCov, int numOfStudyCenters, 
			  double** popCenters, double***popCov, int numOfPopCenters, 
			  double eta, double eps, double theta, double vol, double W,
			  unsigned char*** brain_mask, int* dim, unsigned long* seed)
{
	double* prob = vec_alloc(1+numOfStudyCenters+numOfPopCenters);
	int sim_iters = 500;
	int idx;
	double** Sigma = mat_alloc(DIM);
	
	prob[0] = eps*vol;	
	for (int i=0; i<numOfStudyCenters; i++) {
		prob[i+1] = eta*pmvnorm(brain_mask, dim, studyCov[i], DIM, studyCenters[i], sim_iters, seed);
	}
	for (int i=0; i<numOfPopCenters; i++) {
		mat_copyval(Sigma, popCov[i], DIM);
		for (int k=0; k<DIM; k++) {
			for (int j=0; j<DIM; j++) {
				Sigma[k][j] = Sigma[k][j]/W;
			}
		}
		prob[i+numOfStudyCenters+1] = theta*pmvnorm(brain_mask, dim, Sigma, DIM, popCenters[i], sim_iters, seed);
	}
	
	for (int i=1; i<numOfPopCenters+numOfStudyCenters+1; i++) {
		prob[i] += prob[i-1];
	}
	
	*numOfPoints = rpois(prob[numOfPopCenters+numOfStudyCenters], seed);
	
	for (int i=0; i<numOfPopCenters+numOfStudyCenters+1; i++) {
		prob[i] /= prob[numOfPopCenters+numOfStudyCenters];
	}
	
	for (int i=0; i<*numOfPoints; i++) {
		idx = rmultinomial(prob, numOfPopCenters+numOfStudyCenters+1, seed);
		if (idx==0) {
			for (int k=0; k<DIM; k++) {
				PACs[i][k] = dim[k]*kiss(seed);
			}
			
			while (!inRange(PACs[i], DIM, brain_mask, dim)) {
				for (int k=0; k<DIM; k++) {
					PACs[i][k] = dim[k]*kiss(seed);
				}
			}
	
		}
		else if(idx<numOfStudyCenters+1)
		{
			mat_copyval(Sigma, studyCov[idx-1], DIM);
			rmvnorm(PACs[i], Sigma, DIM, studyCenters[idx-1], seed, 0);
			while (!inRange(PACs[i], DIM, brain_mask, dim)) {
				rmvnorm(PACs[i], Sigma, DIM, studyCenters[idx-1], seed, 1);
			}
		}
		else {
			mat_copyval(Sigma, popCov[idx-1-numOfStudyCenters], DIM);
			for (int k=0; k<DIM; k++) {
				for (int j=0; j<DIM; j++) {
					Sigma[k][j] = Sigma[k][j]/W;
				}
			}
			rmvnorm(PACs[i], Sigma, DIM, popCenters[idx-1-numOfStudyCenters], seed, 0);
			while (!inRange(PACs[i], DIM, brain_mask, dim)) {
				rmvnorm(PACs[i], Sigma, DIM, popCenters[idx-1-numOfStudyCenters], seed, 1);
			}
		}
		
	}

	mat_free(Sigma, DIM);
	
	free(prob);
}


void simAllPACs(points &pp, pars &p,unsigned long* seed)
{
	for (int i=0; i<pp.n_contrast; i++) {
		pp.sWid[i] = rmultinomial(p.phi, p.V_n, seed);
		pp.sW[i] = p.V[pp.sWid[i]];
		simStudyPACs(pp.sPACs[i], &(pp.numsPACs[i]), pp.matZ[i], pp.Lambda[i], pp.numZ[i], p.X, p.Sigma, p.n, pp.rho_all[i],
					 p.eps*pp.xi[i], p.theta*pp.xi[i], pp.vol, pp.sW[i], pp.mask, pp.dim, seed);
		
	}
	
}

void rec_pred_intensity(points &pp, pars &p, unsigned long* seed)
{
	int simiter = 100;
	int i,wid,numsPACs,x,y,z;
	double**sPACs = vec_list_alloc(DIM, SIM_MAX);
	double***temp_int = Array_alloc(pp.dim[2], pp.dim[1], pp.dim[0]);
	pp.num_pred_int++;

	
	for(int iter=0; iter<simiter; iter++)
	{
		i = floor(kiss(seed)*pp.n_contrast);
		wid = rmultinomial(p.phi, p.V_n, seed);
		simStudyPACs(sPACs, &(numsPACs), pp.matZ[i], pp.Lambda[i], pp.numZ[i], p.X, p.Sigma, p.n, pp.rho_all[i],
				 p.eps*pp.xi[i], p.theta*pp.xi[i], pp.vol, p.V[wid], pp.mask, pp.dim, seed);
		
		for (int j=0; j<numsPACs; j++) {
			x = (int)floor(sPACs[j][0]);
			y = (int)floor(sPACs[j][1]);
			z = (int)floor(sPACs[j][2]);
			temp_int[x][y][z] = (iter*temp_int[x][y][z]+1.0)/(iter+1.0);
		}
		//printf("%d\n",iter);
	}
	
	for (int a=0; a<pp.dim[0]; a++) {
		for (int b=0; b<pp.dim[1]; b++) {
			for (int c=0; c<pp.dim[2]; c++) {
				pp.pred_intensity[a][b][c] = ((pp.num_pred_int-1.0)*pp.pred_intensity[a][b][c]+temp_int[a][b][c])/pp.num_pred_int;
			}
		}
	}
	
	vec_list_free(sPACs, SIM_MAX);
	Array_free(temp_int, pp.dim[2], pp.dim[1], pp.dim[0]);
	printf("predictive intensity\n");
}

void write_sPACs(const char* filename, points &pp, pars &p)
{
	FILE* fid = fopen(filename, "wt");
	for (int i=0; i<pp.n_contrast; i++) {
		for (int j=0; j<pp.numsPACs[i]; j++) {
			fprintf(fid, "1 %d %lf %lf %lf %d %lf\n", i+1, pp.sPACs[i][j][0],pp.sPACs[i][j][1],pp.sPACs[i][j][2],pp.sWid[i],pp.sW[i]);
		}
	}
	fclose(fid);
}


double distance2(double* p1, double* p2, int dim)
{
	double temp, d = 0.0;
	for (int i=0; i<dim; i++) {
		temp = p1[i]-p2[i];
		d += temp*temp;
	}
	return d;
}


double compute_PACs_intensity(double* xi, double** studyCenters, double*** studyCov, int numOfStudyCenters, 
							double** popCenters, double***popCov, int numOfPopCenters, 
							double eta, double eps, double theta, double W)
{
	double intense = eps;
	double** Sigma = mat_alloc(DIM);
	
	for (int i=0; i<numOfStudyCenters; i++) {
		intense += eta*dmvnorm(xi, studyCov[i], DIM, studyCenters[i]);
	}
	
	for (int i=0; i<numOfPopCenters; i++) {
		mat_copyval(Sigma, popCov[i], DIM);
		mat_times_k(Sigma, DIM, 1.0/W);
		intense += theta*dmvnorm(xi, popCov[i], DIM, popCenters[i]);
	}
	
	
	mat_free(Sigma, DIM);
	
	return intense;
}

double compute_Lfun(double r, double** PACs, double W, int Wid, int numOfPoints, double* phi, double** studyCenters, double*** studyCov, int numOfStudyCenters, 
				  double** popCenters, double***popCov, int numOfPopCenters, unsigned char*** brain_mask, int* dim, double vol,  
				  double eta, double eps, double theta, unsigned long* seed)
{
	double r2 = r*r;
	double dist = 0.0;
	double Kfun = 0.0;
	double Lfun = 0.0;
	double lambda1, lambda2;
	double edge_factor;
	double mm_unit = 2.0;
	
	for (int i=0; i<numOfPoints-1; i++) {
		for (int j=i+1; j<numOfPoints; j++) {
			//vec_print(PACs[i], DIM, "%4.2lf ");
			//vec_print(PACs[j], DIM, "%4.2lf ");
			
				dist = mm_unit*distance2(PACs[i], PACs[j], DIM);
				//printf("dist2 = %lf, r2 = %lf \n", dist,r2);
				if (dist<r2) {
					lambda1 = compute_PACs_intensity(PACs[i], studyCenters, studyCov, numOfStudyCenters, popCenters, popCov, numOfPopCenters, eta, eps, theta, W);
					lambda2 = compute_PACs_intensity(PACs[j], studyCenters, studyCov, numOfStudyCenters, popCenters, popCov, numOfPopCenters, eta, eps, theta, W);
					edge_factor = compute_edge_factor(PACs[i], PACs[j], brain_mask, dim, vol, seed);
					Kfun += edge_factor/(lambda1*lambda2*phi[Wid]*phi[Wid])/mm_unit;
					
			
					//printf("lambda1 = %lf, lambda2 = %lf\n", lambda1, lambda2);
					
				}
		}
	}
	Kfun = 2.0*(Kfun);
	Lfun = pow(Kfun/(4.0*PI), 0.3333333333333);
	
	return Lfun;
	
}

void voxel2mm(double* voxel_p, double* mm_p, double* orgin)
{
	//orgin[0] = 45;
	//orgin[1] = 63;
	//orgin[2] = 36;
	mm_p[0] = 2.0*(orgin[0] - voxel_p[0]);
	mm_p[1] = 2.0*(voxel_p[1] - orgin[1]);
	mm_p[2] = 2.0*(voxel_p[2] - orgin[2]);
}


double compute_edge_factor(double* p1, double* p2, unsigned char*** brain_mask, int* dim, double vol, unsigned long* seed)
{
	double edge_factor = 0.0;
	double* diffp=  vec_alloc(DIM);
	double* p = vec_alloc(DIM);
	double* plusp = vec_alloc(DIM);
	int max_iter = 1000;
	int region_count = 0;
	
	vec_substract(diffp, p1, p2, DIM);
	
	for(int i = 0; i<max_iter; i++)
	{
		sample_unif_region(p, brain_mask, dim, seed);
		vec_add(plusp, p, diffp, DIM);
		if (inRange(plusp, DIM, brain_mask, dim)) {
			region_count++;
		}
		
	}

	edge_factor = (max_iter + 0.5)/(vol*(region_count+0.5));
	
	free(diffp);
	free(p);
	free(plusp);
	
	return edge_factor;
	
}


void sample_unif_region(double*p, unsigned char*** brain_mask, int
						* dim,unsigned long* seed)
{
	for(int i=0; i<DIM; i++)
	{
		p[i] = kiss(seed)*dim[i];
	}
	
	while(inRange(p, DIM, brain_mask, dim)==0)
	{
		for(int i=0; i<DIM; i++)
		{
			p[i] = kiss(seed)*dim[i];
		}
	}
	
}

void compute_diff_Lfun(double rstart, double rend, int rnum,  points &pp, pars &p, unsigned long* seed)
{
	if (rnum>R_MAX) {
		rnum = R_MAX;
	}
	
	double r;
	double rdiff = (rend - rstart)/(rnum-1);
	printf("rdiff  = %lf, rstart = %lf, rend = %lf, rnum = %d\n", rdiff, rstart, rend, rnum);
	for (int k=0; k<rnum; k++) {
		for (int i=0; i<pp.n_contrast; i++) {
			r = rstart + k*rdiff;
			pp.diffLfun[i][k] = compute_Lfun(r, &(pp.dat[pp.c_id[i]]), pp.W[pp.c_id[i]], pp.W_id[pp.c_id[i]], 
										  pp.c_num[i], p.phi, pp.matZ[i], pp.Lambda[i], pp.numZ[i], p.X, p.Sigma, p.n, pp.mask, pp.dim, pp.vol,
											 pp.rho_all[i], pp.xi[i]*p.eps, pp.xi[i]*p.theta, seed);
			pp.diffLfun[i][k] -= compute_Lfun(r, pp.sPACs[i], pp.sW[i], pp.sWid[i], 
										   pp.numsPACs[i], p.phi, pp.matZ[i], pp.Lambda[i], pp.numZ[i], p.X, p.Sigma, p.n,pp.mask, pp.dim, pp.vol,
											  pp.rho_all[i], pp.xi[i]*p.eps, pp.xi[i]*p.theta,seed); 
			
		}
		printf("r = %lf\n",r);
	}
}

void write_diff_Lfun(const char* filename, points &pp, int rnum)
{
	FILE* fid = fopen(filename, "wt");
	for (int k=0; k<rnum; k++) {
		for (int i=0; i<pp.n_contrast; i++) {
			fprintf(fid, "%lf ", pp.diffLfun[i][k]);
		}
		fprintf(fid, "\n");
	}
	
	fclose(fid);
}
