#ifndef _TIMER_H_
#define _TIMER_H_

#include<ctime>
class Timer
{
public: 
    void restart() { start=clock();} ;
    double elapsed() 
    { 
      finish=clock(); 
      return ((double)(finish-start)/CLOCKS_PER_SEC);
    };
private:
    clock_t start;
    clock_t finish;
};

#endif //_TIMER_H_

