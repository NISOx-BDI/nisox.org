/*
 *  test.h
 *  WeightCox
 *
 *  Created by Jian Kang on 1/6/09.
 *  Copyright 2009 University of Michigan. All rights reserved.
 *
 */

#include <stdio.h>

void print_hello()
{ 
	printf("Hello test!\n");
}