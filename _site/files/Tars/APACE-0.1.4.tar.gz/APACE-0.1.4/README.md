APACE
=====

Accelerated Permutation inference for the ACE model

Please see http://warwick.ac.uk/tenichols/APACE

