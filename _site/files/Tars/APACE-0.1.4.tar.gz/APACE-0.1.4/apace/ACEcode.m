function x = ACEcode(ACE)
%
% Maps active (non-zero) ACE parameters to a integer code
%
%_______________________________________________________________________
% Version: http://github.com/nicholst/APACE/tree/7655112
%          2017-04-17 15:29:51 -0400

Code = [1 2 3];
x    = sum( Code(abs(ACE)>0) );

return

