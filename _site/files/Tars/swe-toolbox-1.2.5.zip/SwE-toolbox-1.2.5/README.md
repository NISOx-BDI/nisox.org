SwE
===

Sandwich Estimator for SPM.
How to correctly analyse neuroimaging data from a longitudinal study.

Work done by Bryan Guillaume and Tom Nichols, Department of Statistics, Warwick University, UK.

Supervisors:
- Tom Nichols, Department of Statistics, Warwick University, UK.
- Christophe Phillips, Cyclotron Research Centre, Universityof Liège, Begium
